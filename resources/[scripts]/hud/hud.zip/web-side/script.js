! function() {
    "use strict";

    function e(e) {
        const t = Object.create(null);
        for (const n of e.split(",")) t[n] = 1;
        return e => e in t
    }
    const t = {},
        n = [],
        l = () => {},
        o = () => !1,
        r = e => 111 === e.charCodeAt(0) && 110 === e.charCodeAt(1) && (e.charCodeAt(2) > 122 || e.charCodeAt(2) < 97),
        s = e => e.startsWith("onUpdate:"),
        i = Object.assign,
        a = (e, t) => {
            const n = e.indexOf(t);
            n > -1 && e.splice(n, 1)
        },
        c = Object.prototype.hasOwnProperty,
        u = (e, t) => c.call(e, t),
        d = Array.isArray,
        h = e => "[object Map]" === x(e),
        f = e => "[object Set]" === x(e),
        p = e => "function" == typeof e,
        m = e => "string" == typeof e,
        v = e => "symbol" == typeof e,
        g = e => null !== e && "object" == typeof e,
        C = e => (g(e) || p(e)) && p(e.then) && p(e.catch),
        w = Object.prototype.toString,
        x = e => w.call(e),
        y = e => "[object Object]" === x(e),
        b = e => m(e) && "NaN" !== e && "-" !== e[0] && "" + parseInt(e, 10) === e,
        k = e(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),
        _ = e => {
            const t = Object.create(null);
            return n => t[n] || (t[n] = e(n))
        },
        M = /-\w/g,
        L = _(e => e.replace(M, e => e.slice(1).toUpperCase())),
        S = /\B([A-Z])/g,
        V = _(e => e.replace(S, "-$1").toLowerCase()),
        z = _(e => e.charAt(0).toUpperCase() + e.slice(1)),
        Z = _(e => e ? `on${z(e)}` : ""),
        j = (e, t) => !Object.is(e, t),
        $ = (e, ...t) => {
            for (let n = 0; n < e.length; n++) e[n](...t)
        },
        B = (e, t, n, l = !1) => {
            Object.defineProperty(e, t, {
                configurable: !0,
                enumerable: !1,
                writable: l,
                value: n
            })
        },
        E = e => {
            const t = parseFloat(e);
            return isNaN(t) ? e : t
        };
    let P;
    const T = () => P || (P = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : "undefined" != typeof window ? window : "undefined" != typeof global ? global : {});

    function F(e) {
        if (d(e)) {
            const t = {};
            for (let n = 0; n < e.length; n++) {
                const l = e[n],
                    o = m(l) ? I(l) : F(l);
                if (o)
                    for (const e in o) t[e] = o[e]
            }
            return t
        }
        if (m(e) || g(e)) return e
    }
    const A = /;(?![^(]*\))/g,
        O = /:([^]+)/,
        H = /\/\*[^]*?\*\//g;

    function I(e) {
        const t = {};
        return e.replace(H, "").split(A).forEach(e => {
            if (e) {
                const n = e.split(O);
                n.length > 1 && (t[n[0].trim()] = n[1].trim())
            }
        }), t
    }

    function R(e) {
        let t = "";
        if (m(e)) t = e;
        else if (d(e))
            for (let n = 0; n < e.length; n++) {
                const l = R(e[n]);
                l && (t += l + " ")
            } else if (g(e))
                for (const n in e) e[n] && (t += n + " ");
        return t.trim()
    }
    const N = e("itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly");

    function D(e) {
        return !!e || "" === e
    }
    const U = e => !(!e || !0 !== e.__v_isRef),
        W = e => m(e) ? e : null == e ? "" : d(e) || g(e) && (e.toString === w || !p(e.toString)) ? U(e) ? W(e.value) : JSON.stringify(e, G, 2) : String(e),
        G = (e, t) => U(t) ? G(e, t.value) : h(t) ? {
            [`Map(${t.size})`]: [...t.entries()].reduce((e, [t, n], l) => (e[q(t, l) + " =>"] = n, e), {})
        } : f(t) ? {
            [`Set(${t.size})`]: [...t.values()].map(e => q(e))
        } : v(t) ? q(t) : !g(t) || d(t) || y(t) ? t : String(t),
        q = (e, t = "") => {
            var n;
            return v(e) ? `Symbol(${null!=(n=e.description)?n:t})` : e
        };
    let K, J;
    class X {
        constructor(e = !1) {
            this.detached = e, this._active = !0, this._on = 0, this.effects = [], this.cleanups = [], this._isPaused = !1, this.parent = K, !e && K && (this.index = (K.scopes || (K.scopes = [])).push(this) - 1)
        }
        get active() {
            return this._active
        }
        pause() {
            if (this._active) {
                let e, t;
                if (this._isPaused = !0, this.scopes)
                    for (e = 0, t = this.scopes.length; e < t; e++) this.scopes[e].pause();
                for (e = 0, t = this.effects.length; e < t; e++) this.effects[e].pause()
            }
        }
        resume() {
            if (this._active && this._isPaused) {
                let e, t;
                if (this._isPaused = !1, this.scopes)
                    for (e = 0, t = this.scopes.length; e < t; e++) this.scopes[e].resume();
                for (e = 0, t = this.effects.length; e < t; e++) this.effects[e].resume()
            }
        }
        run(e) {
            if (this._active) {
                const t = K;
                try {
                    return K = this, e()
                } finally {
                    K = t
                }
            }
        }
        on() {
            1 === ++this._on && (this.prevScope = K, K = this)
        }
        off() {
            this._on > 0 && 0 === --this._on && (K = this.prevScope, this.prevScope = void 0)
        }
        stop(e) {
            if (this._active) {
                let t, n;
                for (this._active = !1, t = 0, n = this.effects.length; t < n; t++) this.effects[t].stop();
                for (this.effects.length = 0, t = 0, n = this.cleanups.length; t < n; t++) this.cleanups[t]();
                if (this.cleanups.length = 0, this.scopes) {
                    for (t = 0, n = this.scopes.length; t < n; t++) this.scopes[t].stop(!0);
                    this.scopes.length = 0
                }
                if (!this.detached && this.parent && !e) {
                    const e = this.parent.scopes.pop();
                    e && e !== this && (this.parent.scopes[this.index] = e, e.index = this.index)
                }
                this.parent = void 0
            }
        }
    }

    function Q(e) {
        return new X(e)
    }

    function Y() {
        return K
    }
    const ee = new WeakSet;
    class te {
        constructor(e) {
            this.fn = e, this.deps = void 0, this.depsTail = void 0, this.flags = 5, this.next = void 0, this.cleanup = void 0, this.scheduler = void 0, K && K.active && K.effects.push(this)
        }
        pause() {
            this.flags |= 64
        }
        resume() {
            64 & this.flags && (this.flags &= -65, ee.has(this) && (ee.delete(this), this.trigger()))
        }
        notify() {
            2 & this.flags && !(32 & this.flags) || 8 & this.flags || re(this)
        }
        run() {
            if (!(1 & this.flags)) return this.fn();
            this.flags |= 2, Ce(this), ae(this);
            const e = J,
                t = pe;
            J = this, pe = !0;
            try {
                return this.fn()
            } finally {
                ce(this), J = e, pe = t, this.flags &= -3
            }
        }
        stop() {
            if (1 & this.flags) {
                for (let e = this.deps; e; e = e.nextDep) he(e);
                this.deps = this.depsTail = void 0, Ce(this), this.onStop && this.onStop(), this.flags &= -2
            }
        }
        trigger() {
            64 & this.flags ? ee.add(this) : this.scheduler ? this.scheduler() : this.runIfDirty()
        }
        runIfDirty() {
            ue(this) && this.run()
        }
        get dirty() {
            return ue(this)
        }
    }
    let ne, le, oe = 0;

    function re(e, t = !1) {
        if (e.flags |= 8, t) return e.next = le, void(le = e);
        e.next = ne, ne = e
    }

    function se() {
        oe++
    }

    function ie() {
        if (--oe > 0) return;
        if (le) {
            let e = le;
            for (le = void 0; e;) {
                const t = e.next;
                e.next = void 0, e.flags &= -9, e = t
            }
        }
        let e;
        for (; ne;) {
            let n = ne;
            for (ne = void 0; n;) {
                const l = n.next;
                if (n.next = void 0, n.flags &= -9, 1 & n.flags) try {
                    n.trigger()
                } catch (t) {
                    e || (e = t)
                }
                n = l
            }
        }
        if (e) throw e
    }

    function ae(e) {
        for (let t = e.deps; t; t = t.nextDep) t.version = -1, t.prevActiveLink = t.dep.activeLink, t.dep.activeLink = t
    }

    function ce(e) {
        let t, n = e.depsTail,
            l = n;
        for (; l;) {
            const e = l.prevDep; - 1 === l.version ? (l === n && (n = e), he(l), fe(l)) : t = l, l.dep.activeLink = l.prevActiveLink, l.prevActiveLink = void 0, l = e
        }
        e.deps = t, e.depsTail = n
    }

    function ue(e) {
        for (let t = e.deps; t; t = t.nextDep)
            if (t.dep.version !== t.version || t.dep.computed && (de(t.dep.computed) || t.dep.version !== t.version)) return !0;
        return !!e._dirty
    }

    function de(e) {
        if (4 & e.flags && !(16 & e.flags)) return;
        if (e.flags &= -17, e.globalVersion === we) return;
        if (e.globalVersion = we, !e.isSSR && 128 & e.flags && (!e.deps && !e._dirty || !ue(e))) return;
        e.flags |= 2;
        const t = e.dep,
            n = J,
            l = pe;
        J = e, pe = !0;
        try {
            ae(e);
            const n = e.fn(e._value);
            (0 === t.version || j(n, e._value)) && (e.flags |= 128, e._value = n, t.version++)
        } catch (o) {
            throw t.version++, o
        } finally {
            J = n, pe = l, ce(e), e.flags &= -3
        }
    }

    function he(e, t = !1) {
        const {
            dep: n,
            prevSub: l,
            nextSub: o
        } = e;
        if (l && (l.nextSub = o, e.prevSub = void 0), o && (o.prevSub = l, e.nextSub = void 0), n.subs === e && (n.subs = l, !l && n.computed)) {
            n.computed.flags &= -5;
            for (let e = n.computed.deps; e; e = e.nextDep) he(e, !0)
        }
        t || --n.sc || !n.map || n.map.delete(n.key)
    }

    function fe(e) {
        const {
            prevDep: t,
            nextDep: n
        } = e;
        t && (t.nextDep = n, e.prevDep = void 0), n && (n.prevDep = t, e.nextDep = void 0)
    }
    let pe = !0;
    const me = [];

    function ve() {
        me.push(pe), pe = !1
    }

    function ge() {
        const e = me.pop();
        pe = void 0 === e || e
    }

    function Ce(e) {
        const {
            cleanup: t
        } = e;
        if (e.cleanup = void 0, t) {
            const e = J;
            J = void 0;
            try {
                t()
            } finally {
                J = e
            }
        }
    }
    let we = 0;
    class xe {
        constructor(e, t) {
            this.sub = e, this.dep = t, this.version = t.version, this.nextDep = this.prevDep = this.nextSub = this.prevSub = this.prevActiveLink = void 0
        }
    }
    class ye {
        constructor(e) {
            this.computed = e, this.version = 0, this.activeLink = void 0, this.subs = void 0, this.map = void 0, this.key = void 0, this.sc = 0, this.__v_skip = !0
        }
        track(e) {
            if (!J || !pe || J === this.computed) return;
            let t = this.activeLink;
            if (void 0 === t || t.sub !== J) t = this.activeLink = new xe(J, this), J.deps ? (t.prevDep = J.depsTail, J.depsTail.nextDep = t, J.depsTail = t) : J.deps = J.depsTail = t, be(t);
            else if (-1 === t.version && (t.version = this.version, t.nextDep)) {
                const e = t.nextDep;
                e.prevDep = t.prevDep, t.prevDep && (t.prevDep.nextDep = e), t.prevDep = J.depsTail, t.nextDep = void 0, J.depsTail.nextDep = t, J.depsTail = t, J.deps === t && (J.deps = e)
            }
            return t
        }
        trigger(e) {
            this.version++, we++, this.notify(e)
        }
        notify(e) {
            se();
            try {
                0;
                for (let e = this.subs; e; e = e.prevSub) e.sub.notify() && e.sub.dep.notify()
            } finally {
                ie()
            }
        }
    }

    function be(e) {
        if (e.dep.sc++, 4 & e.sub.flags) {
            const t = e.dep.computed;
            if (t && !e.dep.subs) {
                t.flags |= 20;
                for (let e = t.deps; e; e = e.nextDep) be(e)
            }
            const n = e.dep.subs;
            n !== e && (e.prevSub = n, n && (n.nextSub = e)), e.dep.subs = e
        }
    }
    const ke = new WeakMap,
        _e = Symbol(""),
        Me = Symbol(""),
        Le = Symbol("");

    function Se(e, t, n) {
        if (pe && J) {
            let t = ke.get(e);
            t || ke.set(e, t = new Map);
            let l = t.get(n);
            l || (t.set(n, l = new ye), l.map = t, l.key = n), l.track()
        }
    }

    function Ve(e, t, n, l, o, r) {
        const s = ke.get(e);
        if (!s) return void we++;
        const i = e => {
            e && e.trigger()
        };
        if (se(), "clear" === t) s.forEach(i);
        else {
            const o = d(e),
                r = o && b(n);
            if (o && "length" === n) {
                const e = Number(l);
                s.forEach((t, n) => {
                    ("length" === n || n === Le || !v(n) && n >= e) && i(t)
                })
            } else switch ((void 0 !== n || s.has(void 0)) && i(s.get(n)), r && i(s.get(Le)), t) {
                case "add":
                    o ? r && i(s.get("length")) : (i(s.get(_e)), h(e) && i(s.get(Me)));
                    break;
                case "delete":
                    o || (i(s.get(_e)), h(e) && i(s.get(Me)));
                    break;
                case "set":
                    h(e) && i(s.get(_e))
            }
        }
        ie()
    }

    function ze(e) {
        const t = ft(e);
        return t === e ? t : (Se(t, 0, Le), dt(e) ? t : t.map(mt))
    }

    function Ze(e) {
        return Se(e = ft(e), 0, Le), e
    }
    const je = {
        __proto__: null,
        [Symbol.iterator]() {
            return $e(this, Symbol.iterator, mt)
        },
        concat(...e) {
            return ze(this).concat(...e.map(e => d(e) ? ze(e) : e))
        },
        entries() {
            return $e(this, "entries", e => (e[1] = mt(e[1]), e))
        },
        every(e, t) {
            return Ee(this, "every", e, t, void 0, arguments)
        },
        filter(e, t) {
            return Ee(this, "filter", e, t, e => e.map(mt), arguments)
        },
        find(e, t) {
            return Ee(this, "find", e, t, mt, arguments)
        },
        findIndex(e, t) {
            return Ee(this, "findIndex", e, t, void 0, arguments)
        },
        findLast(e, t) {
            return Ee(this, "findLast", e, t, mt, arguments)
        },
        findLastIndex(e, t) {
            return Ee(this, "findLastIndex", e, t, void 0, arguments)
        },
        forEach(e, t) {
            return Ee(this, "forEach", e, t, void 0, arguments)
        },
        includes(...e) {
            return Te(this, "includes", e)
        },
        indexOf(...e) {
            return Te(this, "indexOf", e)
        },
        join(e) {
            return ze(this).join(e)
        },
        lastIndexOf(...e) {
            return Te(this, "lastIndexOf", e)
        },
        map(e, t) {
            return Ee(this, "map", e, t, void 0, arguments)
        },
        pop() {
            return Fe(this, "pop")
        },
        push(...e) {
            return Fe(this, "push", e)
        },
        reduce(e, ...t) {
            return Pe(this, "reduce", e, t)
        },
        reduceRight(e, ...t) {
            return Pe(this, "reduceRight", e, t)
        },
        shift() {
            return Fe(this, "shift")
        },
        some(e, t) {
            return Ee(this, "some", e, t, void 0, arguments)
        },
        splice(...e) {
            return Fe(this, "splice", e)
        },
        toReversed() {
            return ze(this).toReversed()
        },
        toSorted(e) {
            return ze(this).toSorted(e)
        },
        toSpliced(...e) {
            return ze(this).toSpliced(...e)
        },
        unshift(...e) {
            return Fe(this, "unshift", e)
        },
        values() {
            return $e(this, "values", mt)
        }
    };

    function $e(e, t, n) {
        const l = Ze(e),
            o = l[t]();
        return l === e || dt(e) || (o._next = o.next, o.next = () => {
            const e = o._next();
            return e.done || (e.value = n(e.value)), e
        }), o
    }
    const Be = Array.prototype;

    function Ee(e, t, n, l, o, r) {
        const s = Ze(e),
            i = s !== e && !dt(e),
            a = s[t];
        if (a !== Be[t]) {
            const t = a.apply(e, r);
            return i ? mt(t) : t
        }
        let c = n;
        s !== e && (i ? c = function(t, l) {
            return n.call(this, mt(t), l, e)
        } : n.length > 2 && (c = function(t, l) {
            return n.call(this, t, l, e)
        }));
        const u = a.call(s, c, l);
        return i && o ? o(u) : u
    }

    function Pe(e, t, n, l) {
        const o = Ze(e);
        let r = n;
        return o !== e && (dt(e) ? n.length > 3 && (r = function(t, l, o) {
            return n.call(this, t, l, o, e)
        }) : r = function(t, l, o) {
            return n.call(this, t, mt(l), o, e)
        }), o[t](r, ...l)
    }

    function Te(e, t, n) {
        const l = ft(e);
        Se(l, 0, Le);
        const o = l[t](...n);
        return -1 !== o && !1 !== o || !ht(n[0]) ? o : (n[0] = ft(n[0]), l[t](...n))
    }

    function Fe(e, t, n = []) {
        ve(), se();
        const l = ft(e)[t].apply(e, n);
        return ie(), ge(), l
    }
    const Ae = e("__proto__,__v_isRef,__isVue"),
        Oe = new Set(Object.getOwnPropertyNames(Symbol).filter(e => "arguments" !== e && "caller" !== e).map(e => Symbol[e]).filter(v));

    function He(e) {
        v(e) || (e = String(e));
        const t = ft(this);
        return Se(t, 0, e), t.hasOwnProperty(e)
    }
    class Ie {
        constructor(e = !1, t = !1) {
            this._isReadonly = e, this._isShallow = t
        }
        get(e, t, n) {
            if ("__v_skip" === t) return e.__v_skip;
            const l = this._isReadonly,
                o = this._isShallow;
            if ("__v_isReactive" === t) return !l;
            if ("__v_isReadonly" === t) return l;
            if ("__v_isShallow" === t) return o;
            if ("__v_raw" === t) return n === (l ? o ? ot : lt : o ? nt : tt).get(e) || Object.getPrototypeOf(e) === Object.getPrototypeOf(n) ? e : void 0;
            const r = d(e);
            if (!l) {
                let e;
                if (r && (e = je[t])) return e;
                if ("hasOwnProperty" === t) return He
            }
            const s = Reflect.get(e, t, gt(e) ? e : n);
            if (v(t) ? Oe.has(t) : Ae(t)) return s;
            if (l || Se(e, 0, t), o) return s;
            if (gt(s)) {
                const e = r && b(t) ? s : s.value;
                return l && g(e) ? it(e) : e
            }
            return g(s) ? l ? it(s) : st(s) : s
        }
    }
    class Re extends Ie {
        constructor(e = !1) {
            super(!1, e)
        }
        set(e, t, n, l) {
            let o = e[t];
            if (!this._isShallow) {
                const t = ut(o);
                if (dt(n) || ut(n) || (o = ft(o), n = ft(n)), !d(e) && gt(o) && !gt(n)) return t || (o.value = n), !0
            }
            const r = d(e) && b(t) ? Number(t) < e.length : u(e, t),
                s = Reflect.set(e, t, n, gt(e) ? e : l);
            return e === ft(l) && (r ? j(n, o) && Ve(e, "set", t, n) : Ve(e, "add", t, n)), s
        }
        deleteProperty(e, t) {
            const n = u(e, t);
            e[t];
            const l = Reflect.deleteProperty(e, t);
            return l && n && Ve(e, "delete", t, void 0), l
        }
        has(e, t) {
            const n = Reflect.has(e, t);
            return v(t) && Oe.has(t) || Se(e, 0, t), n
        }
        ownKeys(e) {
            return Se(e, 0, d(e) ? "length" : _e), Reflect.ownKeys(e)
        }
    }
    class Ne extends Ie {
        constructor(e = !1) {
            super(!0, e)
        }
        set(e, t) {
            return !0
        }
        deleteProperty(e, t) {
            return !0
        }
    }
    const De = new Re,
        Ue = new Ne,
        We = new Re(!0),
        Ge = e => e,
        qe = e => Reflect.getPrototypeOf(e);

    function Ke(e) {
        return function(...t) {
            return "delete" !== e && ("clear" === e ? void 0 : this)
        }
    }

    function Je(e, t) {
        const n = {
            get(n) {
                const l = this.__v_raw,
                    o = ft(l),
                    r = ft(n);
                e || (j(n, r) && Se(o, 0, n), Se(o, 0, r));
                const {
                    has: s
                } = qe(o), i = t ? Ge : e ? vt : mt;
                return s.call(o, n) ? i(l.get(n)) : s.call(o, r) ? i(l.get(r)) : void(l !== o && l.get(n))
            },
            get size() {
                const t = this.__v_raw;
                return !e && Se(ft(t), 0, _e), t.size
            },
            has(t) {
                const n = this.__v_raw,
                    l = ft(n),
                    o = ft(t);
                return e || (j(t, o) && Se(l, 0, t), Se(l, 0, o)), t === o ? n.has(t) : n.has(t) || n.has(o)
            },
            forEach(n, l) {
                const o = this,
                    r = o.__v_raw,
                    s = ft(r),
                    i = t ? Ge : e ? vt : mt;
                return !e && Se(s, 0, _e), r.forEach((e, t) => n.call(l, i(e), i(t), o))
            }
        };
        i(n, e ? {
            add: Ke("add"),
            set: Ke("set"),
            delete: Ke("delete"),
            clear: Ke("clear")
        } : {
            add(e) {
                t || dt(e) || ut(e) || (e = ft(e));
                const n = ft(this);
                return qe(n).has.call(n, e) || (n.add(e), Ve(n, "add", e, e)), this
            },
            set(e, n) {
                t || dt(n) || ut(n) || (n = ft(n));
                const l = ft(this),
                    {
                        has: o,
                        get: r
                    } = qe(l);
                let s = o.call(l, e);
                s || (e = ft(e), s = o.call(l, e));
                const i = r.call(l, e);
                return l.set(e, n), s ? j(n, i) && Ve(l, "set", e, n) : Ve(l, "add", e, n), this
            },
            delete(e) {
                const t = ft(this),
                    {
                        has: n,
                        get: l
                    } = qe(t);
                let o = n.call(t, e);
                o || (e = ft(e), o = n.call(t, e)), l && l.call(t, e);
                const r = t.delete(e);
                return o && Ve(t, "delete", e, void 0), r
            },
            clear() {
                const e = ft(this),
                    t = 0 !== e.size,
                    n = e.clear();
                return t && Ve(e, "clear", void 0, void 0), n
            }
        });
        return ["keys", "values", "entries", Symbol.iterator].forEach(l => {
            n[l] = function(e, t, n) {
                return function(...l) {
                    const o = this.__v_raw,
                        r = ft(o),
                        s = h(r),
                        i = "entries" === e || e === Symbol.iterator && s,
                        a = "keys" === e && s,
                        c = o[e](...l),
                        u = n ? Ge : t ? vt : mt;
                    return !t && Se(r, 0, a ? Me : _e), {
                        next() {
                            const {
                                value: e,
                                done: t
                            } = c.next();
                            return t ? {
                                value: e,
                                done: t
                            } : {
                                value: i ? [u(e[0]), u(e[1])] : u(e),
                                done: t
                            }
                        },
                        [Symbol.iterator]() {
                            return this
                        }
                    }
                }
            }(l, e, t)
        }), n
    }

    function Xe(e, t) {
        const n = Je(e, t);
        return (t, l, o) => "__v_isReactive" === l ? !e : "__v_isReadonly" === l ? e : "__v_raw" === l ? t : Reflect.get(u(n, l) && l in t ? n : t, l, o)
    }
    const Qe = {
            get: Xe(!1, !1)
        },
        Ye = {
            get: Xe(!1, !0)
        },
        et = {
            get: Xe(!0, !1)
        },
        tt = new WeakMap,
        nt = new WeakMap,
        lt = new WeakMap,
        ot = new WeakMap;

    function rt(e) {
        return e.__v_skip || !Object.isExtensible(e) ? 0 : function(e) {
            switch (e) {
                case "Object":
                case "Array":
                    return 1;
                case "Map":
                case "Set":
                case "WeakMap":
                case "WeakSet":
                    return 2;
                default:
                    return 0
            }
        }((e => x(e).slice(8, -1))(e))
    }

    function st(e) {
        return ut(e) ? e : at(e, !1, De, Qe, tt)
    }

    function it(e) {
        return at(e, !0, Ue, et, lt)
    }

    function at(e, t, n, l, o) {
        if (!g(e)) return e;
        if (e.__v_raw && (!t || !e.__v_isReactive)) return e;
        const r = rt(e);
        if (0 === r) return e;
        const s = o.get(e);
        if (s) return s;
        const i = new Proxy(e, 2 === r ? l : n);
        return o.set(e, i), i
    }

    function ct(e) {
        return ut(e) ? ct(e.__v_raw) : !(!e || !e.__v_isReactive)
    }

    function ut(e) {
        return !(!e || !e.__v_isReadonly)
    }

    function dt(e) {
        return !(!e || !e.__v_isShallow)
    }

    function ht(e) {
        return !!e && !!e.__v_raw
    }

    function ft(e) {
        const t = e && e.__v_raw;
        return t ? ft(t) : e
    }

    function pt(e) {
        return !u(e, "__v_skip") && Object.isExtensible(e) && B(e, "__v_skip", !0), e
    }
    const mt = e => g(e) ? st(e) : e,
        vt = e => g(e) ? it(e) : e;

    function gt(e) {
        return !!e && !0 === e.__v_isRef
    }

    function Ct(e) {
        return function(e, t) {
            if (gt(e)) return e;
            return new wt(e, t)
        }(e, !1)
    }
    class wt {
        constructor(e, t) {
            this.dep = new ye, this.__v_isRef = !0, this.__v_isShallow = !1, this._rawValue = t ? e : ft(e), this._value = t ? e : mt(e), this.__v_isShallow = t
        }
        get value() {
            return this.dep.track(), this._value
        }
        set value(e) {
            const t = this._rawValue,
                n = this.__v_isShallow || dt(e) || ut(e);
            e = n ? e : ft(e), j(e, t) && (this._rawValue = e, this._value = n ? e : mt(e), this.dep.trigger())
        }
    }

    function xt(e) {
        return gt(e) ? e.value : e
    }
    const yt = {
        get: (e, t, n) => "__v_raw" === t ? e : xt(Reflect.get(e, t, n)),
        set: (e, t, n, l) => {
            const o = e[t];
            return gt(o) && !gt(n) ? (o.value = n, !0) : Reflect.set(e, t, n, l)
        }
    };

    function bt(e) {
        return ct(e) ? e : new Proxy(e, yt)
    }
    class kt {
        constructor(e, t, n) {
            this._object = e, this._key = t, this._defaultValue = n, this.__v_isRef = !0, this._value = void 0
        }
        get value() {
            const e = this._object[this._key];
            return this._value = void 0 === e ? this._defaultValue : e
        }
        set value(e) {
            this._object[this._key] = e
        }
        get dep() {
            return function(e, t) {
                const n = ke.get(e);
                return n && n.get(t)
            }(ft(this._object), this._key)
        }
    }

    function _t(e, t, n) {
        const l = e[t];
        return gt(l) ? l : new kt(e, t, n)
    }
    class Mt {
        constructor(e, t, n) {
            this.fn = e, this.setter = t, this._value = void 0, this.dep = new ye(this), this.__v_isRef = !0, this.deps = void 0, this.depsTail = void 0, this.flags = 16, this.globalVersion = we - 1, this.next = void 0, this.effect = this, this.__v_isReadonly = !t, this.isSSR = n
        }
        notify() {
            if (this.flags |= 16, !(8 & this.flags) && J !== this) return re(this, !0), !0
        }
        get value() {
            const e = this.dep.track();
            return de(this), e && (e.version = this.dep.version), this._value
        }
        set value(e) {
            this.setter && this.setter(e)
        }
    }
    const Lt = {},
        St = new WeakMap;
    let Vt;

    function zt(e, n, o = t) {
        const {
            immediate: r,
            deep: s,
            once: i,
            scheduler: c,
            augmentJob: u,
            call: h
        } = o, f = e => s ? e : dt(e) || !1 === s || 0 === s ? Zt(e, 1) : Zt(e);
        let m, v, g, C, w = !1,
            x = !1;
        if (gt(e) ? (v = () => e.value, w = dt(e)) : ct(e) ? (v = () => f(e), w = !0) : d(e) ? (x = !0, w = e.some(e => ct(e) || dt(e)), v = () => e.map(e => gt(e) ? e.value : ct(e) ? f(e) : p(e) ? h ? h(e, 2) : e() : void 0)) : v = p(e) ? n ? h ? () => h(e, 2) : e : () => {
                if (g) {
                    ve();
                    try {
                        g()
                    } finally {
                        ge()
                    }
                }
                const t = Vt;
                Vt = m;
                try {
                    return h ? h(e, 3, [C]) : e(C)
                } finally {
                    Vt = t
                }
            } : l, n && s) {
            const e = v,
                t = !0 === s ? 1 / 0 : s;
            v = () => Zt(e(), t)
        }
        const y = Y(),
            b = () => {
                m.stop(), y && y.active && a(y.effects, m)
            };
        if (i && n) {
            const e = n;
            n = (...t) => {
                e(...t), b()
            }
        }
        let k = x ? new Array(e.length).fill(Lt) : Lt;
        const _ = e => {
            if (1 & m.flags && (m.dirty || e))
                if (n) {
                    const e = m.run();
                    if (s || w || (x ? e.some((e, t) => j(e, k[t])) : j(e, k))) {
                        g && g();
                        const t = Vt;
                        Vt = m;
                        try {
                            const t = [e, k === Lt ? void 0 : x && k[0] === Lt ? [] : k, C];
                            k = e, h ? h(n, 3, t) : n(...t)
                        } finally {
                            Vt = t
                        }
                    }
                } else m.run()
        };
        return u && u(_), m = new te(v), m.scheduler = c ? () => c(_, !1) : _, C = e => function(e, t = !1, n = Vt) {
            if (n) {
                let t = St.get(n);
                t || St.set(n, t = []), t.push(e)
            }
        }(e, !1, m), g = m.onStop = () => {
            const e = St.get(m);
            if (e) {
                if (h) h(e, 4);
                else
                    for (const t of e) t();
                St.delete(m)
            }
        }, n ? r ? _(!0) : k = m.run() : c ? c(_.bind(null, !0), !0) : m.run(), b.pause = m.pause.bind(m), b.resume = m.resume.bind(m), b.stop = b, b
    }

    function Zt(e, t = 1 / 0, n) {
        if (t <= 0 || !g(e) || e.__v_skip) return e;
        if (((n = n || new Map).get(e) || 0) >= t) return e;
        if (n.set(e, t), t--, gt(e)) Zt(e.value, t, n);
        else if (d(e))
            for (let l = 0; l < e.length; l++) Zt(e[l], t, n);
        else if (f(e) || h(e)) e.forEach(e => {
            Zt(e, t, n)
        });
        else if (y(e)) {
            for (const l in e) Zt(e[l], t, n);
            for (const l of Object.getOwnPropertySymbols(e)) Object.prototype.propertyIsEnumerable.call(e, l) && Zt(e[l], t, n)
        }
        return e
    }

    function jt(e, t, n, l) {
        try {
            return l ? e(...l) : e()
        } catch (o) {
            Bt(o, t, n)
        }
    }

    function $t(e, t, n, l) {
        if (p(e)) {
            const o = jt(e, t, n, l);
            return o && C(o) && o.catch(e => {
                Bt(e, t, n)
            }), o
        }
        if (d(e)) {
            const o = [];
            for (let r = 0; r < e.length; r++) o.push($t(e[r], t, n, l));
            return o
        }
    }

    function Bt(e, n, l, o = !0) {
        n && n.vnode;
        const {
            errorHandler: r,
            throwUnhandledErrorInProduction: s
        } = n && n.appContext.config || t;
        if (n) {
            let t = n.parent;
            const o = n.proxy,
                s = `https://vuejs.org/error-reference/#runtime-${l}`;
            for (; t;) {
                const n = t.ec;
                if (n)
                    for (let t = 0; t < n.length; t++)
                        if (!1 === n[t](e, o, s)) return;
                t = t.parent
            }
            if (r) return ve(), jt(r, null, 10, [e, o, s]), void ge()
        }! function(e, t, n, l = !0, o = !1) {
            if (o) throw e
        }(e, 0, 0, o, s)
    }
    const Et = [];
    let Pt = -1;
    const Tt = [];
    let Ft = null,
        At = 0;
    const Ot = Promise.resolve();
    let Ht = null;

    function It(e) {
        const t = Ht || Ot;
        return e ? t.then(this ? e.bind(this) : e) : t
    }

    function Rt(e) {
        if (!(1 & e.flags)) {
            const t = Wt(e),
                n = Et[Et.length - 1];
            !n || !(2 & e.flags) && t >= Wt(n) ? Et.push(e) : Et.splice(function(e) {
                let t = Pt + 1,
                    n = Et.length;
                for (; t < n;) {
                    const l = t + n >>> 1,
                        o = Et[l],
                        r = Wt(o);
                    r < e || r === e && 2 & o.flags ? t = l + 1 : n = l
                }
                return t
            }(t), 0, e), e.flags |= 1, Nt()
        }
    }

    function Nt() {
        Ht || (Ht = Ot.then(Gt))
    }

    function Dt(e, t, n = Pt + 1) {
        for (; n < Et.length; n++) {
            const t = Et[n];
            if (t && 2 & t.flags) {
                if (e && t.id !== e.uid) continue;
                Et.splice(n, 1), n--, 4 & t.flags && (t.flags &= -2), t(), 4 & t.flags || (t.flags &= -2)
            }
        }
    }

    function Ut(e) {
        if (Tt.length) {
            const e = [...new Set(Tt)].sort((e, t) => Wt(e) - Wt(t));
            if (Tt.length = 0, Ft) return void Ft.push(...e);
            for (Ft = e, At = 0; At < Ft.length; At++) {
                const e = Ft[At];
                4 & e.flags && (e.flags &= -2), 8 & e.flags || e(), e.flags &= -2
            }
            Ft = null, At = 0
        }
    }
    const Wt = e => null == e.id ? 2 & e.flags ? -1 : 1 / 0 : e.id;

    function Gt(e) {
        try {
            for (Pt = 0; Pt < Et.length; Pt++) {
                const e = Et[Pt];
                !e || 8 & e.flags || (4 & e.flags && (e.flags &= -2), jt(e, e.i, e.i ? 15 : 14), 4 & e.flags || (e.flags &= -2))
            }
        } finally {
            for (; Pt < Et.length; Pt++) {
                const e = Et[Pt];
                e && (e.flags &= -2)
            }
            Pt = -1, Et.length = 0, Ut(), Ht = null, (Et.length || Tt.length) && Gt()
        }
    }
    let qt = null,
        Kt = null;

    function Jt(e) {
        const t = qt;
        return qt = e, Kt = e && e.type.__scopeId || null, t
    }

    function Xt(e, t = qt, n) {
        if (!t) return e;
        if (e._n) return e;
        const l = (...n) => {
            l._d && ro(-1);
            const o = Jt(t);
            let r;
            try {
                r = e(...n)
            } finally {
                Jt(o), l._d && ro(1)
            }
            return r
        };
        return l._n = !0, l._c = !0, l._d = !0, l
    }

    function Qt(e, t, n, l) {
        const o = e.dirs,
            r = t && t.dirs;
        for (let s = 0; s < o.length; s++) {
            const i = o[s];
            r && (i.oldValue = r[s].value);
            let a = i.dir[l];
            a && (ve(), $t(a, n, 8, [e.el, i, e, t]), ge())
        }
    }
    const Yt = Symbol("_vte"),
        en = e => e.__isTeleport,
        tn = Symbol("_leaveCb"),
        nn = Symbol("_enterCb");

    function ln() {
        const e = {
            isMounted: !1,
            isLeaving: !1,
            isUnmounting: !1,
            leavingVNodes: new Map
        };
        return Zn(() => {
            e.isMounted = !0
        }), Bn(() => {
            e.isUnmounting = !0
        }), e
    }
    const on = [Function, Array],
        rn = {
            mode: String,
            appear: Boolean,
            persisted: Boolean,
            onBeforeEnter: on,
            onEnter: on,
            onAfterEnter: on,
            onEnterCancelled: on,
            onBeforeLeave: on,
            onLeave: on,
            onAfterLeave: on,
            onLeaveCancelled: on,
            onBeforeAppear: on,
            onAppear: on,
            onAfterAppear: on,
            onAppearCancelled: on
        },
        sn = e => {
            const t = e.subTree;
            return t.component ? sn(t.component) : t
        };

    function an(e) {
        let t = e[0];
        if (e.length > 1)
            for (const n of e)
                if (n.type !== Yl) {
                    t = n;
                    break
                } return t
    }
    const cn = {
        name: "BaseTransition",
        props: rn,
        setup(e, {
            slots: t
        }) {
            const n = So(),
                l = ln();
            return () => {
                const o = t.default && mn(t.default(), !0);
                if (!o || !o.length) return;
                const r = an(o),
                    s = ft(e),
                    {
                        mode: i
                    } = s;
                if (l.isLeaving) return hn(r);
                const a = fn(r);
                if (!a) return hn(r);
                let c = dn(a, s, l, n, e => c = e);
                a.type !== Yl && pn(a, c);
                let u = n.subTree && fn(n.subTree);
                if (u && u.type !== Yl && !uo(u, a) && sn(n).type !== Yl) {
                    let e = dn(u, s, l, n);
                    if (pn(u, e), "out-in" === i && a.type !== Yl) return l.isLeaving = !0, e.afterLeave = () => {
                        l.isLeaving = !1, 8 & n.job.flags || n.update(), delete e.afterLeave, u = void 0
                    }, hn(r);
                    "in-out" === i && a.type !== Yl ? e.delayLeave = (e, t, n) => {
                        un(l, u)[String(u.key)] = u, e[tn] = () => {
                            t(), e[tn] = void 0, delete c.delayedLeave, u = void 0
                        }, c.delayedLeave = () => {
                            n(), delete c.delayedLeave, u = void 0
                        }
                    } : u = void 0
                } else u && (u = void 0);
                return r
            }
        }
    };

    function un(e, t) {
        const {
            leavingVNodes: n
        } = e;
        let l = n.get(t.type);
        return l || (l = Object.create(null), n.set(t.type, l)), l
    }

    function dn(e, t, n, l, o) {
        const {
            appear: r,
            mode: s,
            persisted: i = !1,
            onBeforeEnter: a,
            onEnter: c,
            onAfterEnter: u,
            onEnterCancelled: h,
            onBeforeLeave: f,
            onLeave: p,
            onAfterLeave: m,
            onLeaveCancelled: v,
            onBeforeAppear: g,
            onAppear: C,
            onAfterAppear: w,
            onAppearCancelled: x
        } = t, y = String(e.key), b = un(n, e), k = (e, t) => {
            e && $t(e, l, 9, t)
        }, _ = (e, t) => {
            const n = t[1];
            k(e, t), d(e) ? e.every(e => e.length <= 1) && n() : e.length <= 1 && n()
        }, M = {
            mode: s,
            persisted: i,
            beforeEnter(t) {
                let l = a;
                if (!n.isMounted) {
                    if (!r) return;
                    l = g || a
                }
                t[tn] && t[tn](!0);
                const o = b[y];
                o && uo(e, o) && o.el[tn] && o.el[tn](), k(l, [t])
            },
            enter(e) {
                let t = c,
                    l = u,
                    o = h;
                if (!n.isMounted) {
                    if (!r) return;
                    t = C || c, l = w || u, o = x || h
                }
                let s = !1;
                const i = e[nn] = t => {
                    s || (s = !0, k(t ? o : l, [e]), M.delayedLeave && M.delayedLeave(), e[nn] = void 0)
                };
                t ? _(t, [e, i]) : i()
            },
            leave(t, l) {
                const o = String(e.key);
                if (t[nn] && t[nn](!0), n.isUnmounting) return l();
                k(f, [t]);
                let r = !1;
                const s = t[tn] = n => {
                    r || (r = !0, l(), k(n ? v : m, [t]), t[tn] = void 0, b[o] === e && delete b[o])
                };
                b[o] = e, p ? _(p, [t, s]) : s()
            },
            clone(e) {
                const r = dn(e, t, n, l, o);
                return o && o(r), r
            }
        };
        return M
    }

    function hn(e) {
        if (bn(e)) return (e = vo(e)).children = null, e
    }

    function fn(e) {
        if (!bn(e)) return en(e.type) && e.children ? an(e.children) : e;
        if (e.component) return e.component.subTree;
        const {
            shapeFlag: t,
            children: n
        } = e;
        if (n) {
            if (16 & t) return n[0];
            if (32 & t && p(n.default)) return n.default()
        }
    }

    function pn(e, t) {
        6 & e.shapeFlag && e.component ? (e.transition = t, pn(e.component.subTree, t)) : 128 & e.shapeFlag ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t
    }

    function mn(e, t = !1, n) {
        let l = [],
            o = 0;
        for (let r = 0; r < e.length; r++) {
            let s = e[r];
            const i = null == n ? s.key : String(n) + String(null != s.key ? s.key : r);
            s.type === Xl ? (128 & s.patchFlag && o++, l = l.concat(mn(s.children, t, i))) : (t || s.type !== Yl) && l.push(null != i ? vo(s, {
                key: i
            }) : s)
        }
        if (o > 1)
            for (let r = 0; r < l.length; r++) l[r].patchFlag = -2;
        return l
    }

    function vn(e, t) {
        return p(e) ? (() => i({
            name: e.name
        }, t, {
            setup: e
        }))() : e
    }

    function gn(e) {
        e.ids = [e.ids[0] + e.ids[2]++ + "-", 0, 0]
    }
    const Cn = new WeakMap;

    function wn(e, n, l, r, s = !1) {
        if (d(e)) return void e.forEach((e, t) => wn(e, n && (d(n) ? n[t] : n), l, r, s));
        if (yn(r) && !s) return void(512 & r.shapeFlag && r.type.__asyncResolved && r.component.subTree.component && wn(e, n, l, r.component.subTree));
        const i = 4 & r.shapeFlag ? Fo(r.component) : r.el,
            c = s ? null : i,
            {
                i: h,
                r: f
            } = e,
            v = n && n.r,
            g = h.refs === t ? h.refs = {} : h.refs,
            C = h.setupState,
            w = ft(C),
            x = C === t ? o : e => u(w, e);
        if (null != v && v !== f)
            if (xn(n), m(v)) g[v] = null, x(v) && (C[v] = null);
            else if (gt(v)) {
            v.value = null;
            const e = n;
            e.k && (g[e.k] = null)
        }
        if (p(f)) jt(f, h, 12, [c, g]);
        else {
            const t = m(f),
                n = gt(f);
            if (t || n) {
                const o = () => {
                    if (e.f) {
                        const n = t ? x(f) ? C[f] : g[f] : f.value;
                        if (s) d(n) && a(n, i);
                        else if (d(n)) n.includes(i) || n.push(i);
                        else if (t) g[f] = [i], x(f) && (C[f] = g[f]);
                        else {
                            const t = [i];
                            f.value = t, e.k && (g[e.k] = t)
                        }
                    } else t ? (g[f] = c, x(f) && (C[f] = c)) : n && (f.value = c, e.k && (g[e.k] = c))
                };
                if (c) {
                    const t = () => {
                        o(), Cn.delete(e)
                    };
                    t.id = -1, Cn.set(e, t), Vl(t, l)
                } else xn(e), o()
            }
        }
    }

    function xn(e) {
        const t = Cn.get(e);
        t && (t.flags |= 8, Cn.delete(e))
    }
    T().requestIdleCallback, T().cancelIdleCallback;
    const yn = e => !!e.type.__asyncLoader,
        bn = e => e.type.__isKeepAlive;

    function kn(e, t) {
        Mn(e, "a", t)
    }

    function _n(e, t) {
        Mn(e, "da", t)
    }

    function Mn(e, t, n = Lo) {
        const l = e.__wdc || (e.__wdc = () => {
            let t = n;
            for (; t;) {
                if (t.isDeactivated) return;
                t = t.parent
            }
            return e()
        });
        if (Sn(t, l, n), n) {
            let e = n.parent;
            for (; e && e.parent;) bn(e.parent.vnode) && Ln(l, t, n, e), e = e.parent
        }
    }

    function Ln(e, t, n, l) {
        const o = Sn(t, e, l, !0);
        En(() => {
            a(l[t], o)
        }, n)
    }

    function Sn(e, t, n = Lo, l = !1) {
        if (n) {
            const o = n[e] || (n[e] = []),
                r = t.__weh || (t.__weh = (...l) => {
                    ve();
                    const o = Zo(n),
                        r = $t(t, n, e, l);
                    return o(), ge(), r
                });
            return l ? o.unshift(r) : o.push(r), r
        }
    }
    const Vn = e => (t, n = Lo) => {
            Bo && "sp" !== e || Sn(e, (...e) => t(...e), n)
        },
        zn = Vn("bm"),
        Zn = Vn("m"),
        jn = Vn("bu"),
        $n = Vn("u"),
        Bn = Vn("bum"),
        En = Vn("um"),
        Pn = Vn("sp"),
        Tn = Vn("rtg"),
        Fn = Vn("rtc");

    function An(e, t = Lo) {
        Sn("ec", e, t)
    }
    const On = Symbol.for("v-ndc");

    function Hn(e) {
        return m(e) ? function(e, t, n = !0, l = !1) {
            const o = qt || Lo;
            if (o) {
                const n = o.type;
                {
                    const e = Ao(n, !1);
                    if (e && (e === t || e === L(t) || e === z(L(t)))) return n
                }
                const r = In(o[e] || n[e], t) || In(o.appContext[e], t);
                return !r && l ? n : r
            }
        }("components", e, !1) || e : e || On
    }

    function In(e, t) {
        return e && (e[t] || e[L(t)] || e[z(L(t))])
    }

    function Rn(e, t, n, l) {
        let o;
        const r = n,
            s = d(e);
        if (s || m(e)) {
            let n = !1,
                l = !1;
            s && ct(e) && (n = !dt(e), l = ut(e), e = Ze(e)), o = new Array(e.length);
            for (let s = 0, i = e.length; s < i; s++) o[s] = t(n ? l ? vt(mt(e[s])) : mt(e[s]) : e[s], s, void 0, r)
        } else if ("number" == typeof e) {
            o = new Array(e);
            for (let n = 0; n < e; n++) o[n] = t(n + 1, n, void 0, r)
        } else if (g(e))
            if (e[Symbol.iterator]) o = Array.from(e, (e, n) => t(e, n, void 0, r));
            else {
                const n = Object.keys(e);
                o = new Array(n.length);
                for (let l = 0, s = n.length; l < s; l++) {
                    const s = n[l];
                    o[l] = t(e[s], s, l, r)
                }
            }
        else o = [];
        return o
    }

    function Nn(e, t, n = {}, l, o) {
        if (qt.ce || qt.parent && yn(qt.parent) && qt.parent.ce) {
            const e = Object.keys(n).length > 0;
            return lo(), ao(Xl, null, [mo("slot", n, l)], e ? -2 : 64)
        }
        let r = e[t];
        r && r._c && (r._d = !1), lo();
        const s = r && Dn(r(n)),
            i = n.key || s && s.key,
            a = ao(Xl, {
                key: (i && !v(i) ? i : `_${t}`) + (!s && l ? "_fb" : "")
            }, s || [], s && 1 === e._ ? 64 : -2);
        return a.scopeId && (a.slotScopeIds = [a.scopeId + "-s"]), r && r._c && (r._d = !0), a
    }

    function Dn(e) {
        return e.some(e => !co(e) || e.type !== Yl && !(e.type === Xl && !Dn(e.children))) ? e : null
    }
    const Un = e => e ? $o(e) ? Fo(e) : Un(e.parent) : null,
        Wn = i(Object.create(null), {
            $: e => e,
            $el: e => e.vnode.el,
            $data: e => e.data,
            $props: e => e.props,
            $attrs: e => e.attrs,
            $slots: e => e.slots,
            $refs: e => e.refs,
            $parent: e => Un(e.parent),
            $root: e => Un(e.root),
            $host: e => e.ce,
            $emit: e => e.emit,
            $options: e => el(e),
            $forceUpdate: e => e.f || (e.f = () => {
                Rt(e.update)
            }),
            $nextTick: e => e.n || (e.n = It.bind(e.proxy)),
            $watch: e => Ol.bind(e)
        }),
        Gn = (e, n) => e !== t && !e.__isScriptSetup && u(e, n),
        qn = {
            get({
                _: e
            }, n) {
                if ("__v_skip" === n) return !0;
                const {
                    ctx: l,
                    setupState: o,
                    data: r,
                    props: s,
                    accessCache: i,
                    type: a,
                    appContext: c
                } = e;
                let d;
                if ("$" !== n[0]) {
                    const a = i[n];
                    if (void 0 !== a) switch (a) {
                        case 1:
                            return o[n];
                        case 2:
                            return r[n];
                        case 4:
                            return l[n];
                        case 3:
                            return s[n]
                    } else {
                        if (Gn(o, n)) return i[n] = 1, o[n];
                        if (r !== t && u(r, n)) return i[n] = 2, r[n];
                        if ((d = e.propsOptions[0]) && u(d, n)) return i[n] = 3, s[n];
                        if (l !== t && u(l, n)) return i[n] = 4, l[n];
                        Jn && (i[n] = 0)
                    }
                }
                const h = Wn[n];
                let f, p;
                return h ? ("$attrs" === n && Se(e.attrs, 0, ""), h(e)) : (f = a.__cssModules) && (f = f[n]) ? f : l !== t && u(l, n) ? (i[n] = 4, l[n]) : (p = c.config.globalProperties, u(p, n) ? p[n] : void 0)
            },
            set({
                _: e
            }, n, l) {
                const {
                    data: o,
                    setupState: r,
                    ctx: s
                } = e;
                return Gn(r, n) ? (r[n] = l, !0) : o !== t && u(o, n) ? (o[n] = l, !0) : !u(e.props, n) && (("$" !== n[0] || !(n.slice(1) in e)) && (s[n] = l, !0))
            },
            has({
                _: {
                    data: e,
                    setupState: n,
                    accessCache: l,
                    ctx: o,
                    appContext: r,
                    propsOptions: s,
                    type: i
                }
            }, a) {
                let c, d;
                return !!(l[a] || e !== t && "$" !== a[0] && u(e, a) || Gn(n, a) || (c = s[0]) && u(c, a) || u(o, a) || u(Wn, a) || u(r.config.globalProperties, a) || (d = i.__cssModules) && d[a])
            },
            defineProperty(e, t, n) {
                return null != n.get ? e._.accessCache[t] = 0 : u(n, "value") && this.set(e, t, n.value, null), Reflect.defineProperty(e, t, n)
            }
        };

    function Kn(e) {
        return d(e) ? e.reduce((e, t) => (e[t] = null, e), {}) : e
    }
    let Jn = !0;

    function Xn(e) {
        const t = el(e),
            n = e.proxy,
            o = e.ctx;
        Jn = !1, t.beforeCreate && Qn(t.beforeCreate, e, "bc");
        const {
            data: r,
            computed: s,
            methods: i,
            watch: a,
            provide: c,
            inject: u,
            created: h,
            beforeMount: f,
            mounted: m,
            beforeUpdate: v,
            updated: C,
            activated: w,
            deactivated: x,
            beforeDestroy: y,
            beforeUnmount: b,
            destroyed: k,
            unmounted: _,
            render: M,
            renderTracked: L,
            renderTriggered: S,
            errorCaptured: V,
            serverPrefetch: z,
            expose: Z,
            inheritAttrs: j,
            components: $,
            directives: B,
            filters: E
        } = t;
        if (u && function(e, t) {
                d(e) && (e = ol(e));
                for (const n in e) {
                    const l = e[n];
                    let o;
                    o = g(l) ? "default" in l ? hl(l.from || n, l.default, !0) : hl(l.from || n) : hl(l), gt(o) ? Object.defineProperty(t, n, {
                        enumerable: !0,
                        configurable: !0,
                        get: () => o.value,
                        set: e => o.value = e
                    }) : t[n] = o
                }
            }(u, o, null), i)
            for (const l in i) {
                const e = i[l];
                p(e) && (o[l] = e.bind(n))
            }
        if (r) {
            const t = r.call(n, n);
            g(t) && (e.data = st(t))
        }
        if (Jn = !0, s)
            for (const d in s) {
                const e = s[d],
                    t = p(e) ? e.bind(n, n) : p(e.get) ? e.get.bind(n, n) : l,
                    r = !p(e) && p(e.set) ? e.set.bind(n) : l,
                    i = Oo({
                        get: t,
                        set: r
                    });
                Object.defineProperty(o, d, {
                    enumerable: !0,
                    configurable: !0,
                    get: () => i.value,
                    set: e => i.value = e
                })
            }
        if (a)
            for (const l in a) Yn(a[l], o, n, l);
        if (c) {
            const e = p(c) ? c.call(n) : c;
            Reflect.ownKeys(e).forEach(t => {
                ! function(e, t) {
                    if (Lo) {
                        let n = Lo.provides;
                        const l = Lo.parent && Lo.parent.provides;
                        l === n && (n = Lo.provides = Object.create(l)), n[e] = t
                    } else;
                }(t, e[t])
            })
        }

        function P(e, t) {
            d(t) ? t.forEach(t => e(t.bind(n))) : t && e(t.bind(n))
        }
        if (h && Qn(h, e, "c"), P(zn, f), P(Zn, m), P(jn, v), P($n, C), P(kn, w), P(_n, x), P(An, V), P(Fn, L), P(Tn, S), P(Bn, b), P(En, _), P(Pn, z), d(Z))
            if (Z.length) {
                const t = e.exposed || (e.exposed = {});
                Z.forEach(e => {
                    Object.defineProperty(t, e, {
                        get: () => n[e],
                        set: t => n[e] = t,
                        enumerable: !0
                    })
                })
            } else e.exposed || (e.exposed = {});
        M && e.render === l && (e.render = M), null != j && (e.inheritAttrs = j), $ && (e.components = $), B && (e.directives = B), z && gn(e)
    }

    function Qn(e, t, n) {
        $t(d(e) ? e.map(e => e.bind(t.proxy)) : e.bind(t.proxy), t, n)
    }

    function Yn(e, t, n, l) {
        let o = l.includes(".") ? Hl(n, l) : () => n[l];
        if (m(e)) {
            const n = t[e];
            p(n) && Fl(o, n)
        } else if (p(e)) Fl(o, e.bind(n));
        else if (g(e))
            if (d(e)) e.forEach(e => Yn(e, t, n, l));
            else {
                const l = p(e.handler) ? e.handler.bind(n) : t[e.handler];
                p(l) && Fl(o, l, e)
            }
    }

    function el(e) {
        const t = e.type,
            {
                mixins: n,
                extends: l
            } = t,
            {
                mixins: o,
                optionsCache: r,
                config: {
                    optionMergeStrategies: s
                }
            } = e.appContext,
            i = r.get(t);
        let a;
        return i ? a = i : o.length || n || l ? (a = {}, o.length && o.forEach(e => tl(a, e, s, !0)), tl(a, t, s)) : a = t, g(t) && r.set(t, a), a
    }

    function tl(e, t, n, l = !1) {
        const {
            mixins: o,
            extends: r
        } = t;
        r && tl(e, r, n, !0), o && o.forEach(t => tl(e, t, n, !0));
        for (const s in t)
            if (l && "expose" === s);
            else {
                const l = nl[s] || n && n[s];
                e[s] = l ? l(e[s], t[s]) : t[s]
            } return e
    }
    const nl = {
        data: ll,
        props: il,
        emits: il,
        methods: sl,
        computed: sl,
        beforeCreate: rl,
        created: rl,
        beforeMount: rl,
        mounted: rl,
        beforeUpdate: rl,
        updated: rl,
        beforeDestroy: rl,
        beforeUnmount: rl,
        destroyed: rl,
        unmounted: rl,
        activated: rl,
        deactivated: rl,
        errorCaptured: rl,
        serverPrefetch: rl,
        components: sl,
        directives: sl,
        watch: function(e, t) {
            if (!e) return t;
            if (!t) return e;
            const n = i(Object.create(null), e);
            for (const l in t) n[l] = rl(e[l], t[l]);
            return n
        },
        provide: ll,
        inject: function(e, t) {
            return sl(ol(e), ol(t))
        }
    };

    function ll(e, t) {
        return t ? e ? function() {
            return i(p(e) ? e.call(this, this) : e, p(t) ? t.call(this, this) : t)
        } : t : e
    }

    function ol(e) {
        if (d(e)) {
            const t = {};
            for (let n = 0; n < e.length; n++) t[e[n]] = e[n];
            return t
        }
        return e
    }

    function rl(e, t) {
        return e ? [...new Set([].concat(e, t))] : t
    }

    function sl(e, t) {
        return e ? i(Object.create(null), e, t) : t
    }

    function il(e, t) {
        return e ? d(e) && d(t) ? [...new Set([...e, ...t])] : i(Object.create(null), Kn(e), Kn(null != t ? t : {})) : t
    }

    function al() {
        return {
            app: null,
            config: {
                isNativeTag: o,
                performance: !1,
                globalProperties: {},
                optionMergeStrategies: {},
                errorHandler: void 0,
                warnHandler: void 0,
                compilerOptions: {}
            },
            mixins: [],
            components: {},
            directives: {},
            provides: Object.create(null),
            optionsCache: new WeakMap,
            propsCache: new WeakMap,
            emitsCache: new WeakMap
        }
    }
    let cl = 0;

    function ul(e, t) {
        return function(t, n = null) {
            p(t) || (t = i({}, t)), null == n || g(n) || (n = null);
            const l = al(),
                o = new WeakSet,
                r = [];
            let s = !1;
            const a = l.app = {
                _uid: cl++,
                _component: t,
                _props: n,
                _container: null,
                _context: l,
                _instance: null,
                version: Ho,
                get config() {
                    return l.config
                },
                set config(e) {},
                use: (e, ...t) => (o.has(e) || (e && p(e.install) ? (o.add(e), e.install(a, ...t)) : p(e) && (o.add(e), e(a, ...t))), a),
                mixin: e => (l.mixins.includes(e) || l.mixins.push(e), a),
                component: (e, t) => t ? (l.components[e] = t, a) : l.components[e],
                directive: (e, t) => t ? (l.directives[e] = t, a) : l.directives[e],
                mount(o, r, i) {
                    if (!s) {
                        const r = a._ceVNode || mo(t, n);
                        return r.appContext = l, !0 === i ? i = "svg" : !1 === i && (i = void 0), e(r, o, i), s = !0, a._container = o, o.__vue_app__ = a, Fo(r.component)
                    }
                },
                onUnmount(e) {
                    r.push(e)
                },
                unmount() {
                    s && ($t(r, a._instance, 16), e(null, a._container), delete a._container.__vue_app__)
                },
                provide: (e, t) => (l.provides[e] = t, a),
                runWithContext(e) {
                    const t = dl;
                    dl = a;
                    try {
                        return e()
                    } finally {
                        dl = t
                    }
                }
            };
            return a
        }
    }
    let dl = null;

    function hl(e, t, n = !1) {
        const l = So();
        if (l || dl) {
            let o = dl ? dl._context.provides : l ? null == l.parent || l.ce ? l.vnode.appContext && l.vnode.appContext.provides : l.parent.provides : void 0;
            if (o && e in o) return o[e];
            if (arguments.length > 1) return n && p(t) ? t.call(l && l.proxy) : t
        }
    }
    const fl = {},
        pl = () => Object.create(fl),
        ml = e => Object.getPrototypeOf(e) === fl;

    function vl(e, t, n, l = !1) {
        const o = {},
            r = pl();
        e.propsDefaults = Object.create(null), gl(e, t, o, r);
        for (const s in e.propsOptions[0]) s in o || (o[s] = void 0);
        n ? e.props = l ? o : at(o, !1, We, Ye, nt) : e.type.props ? e.props = o : e.props = r, e.attrs = r
    }

    function gl(e, n, l, o) {
        const [r, s] = e.propsOptions;
        let i, a = !1;
        if (n)
            for (let t in n) {
                if (k(t)) continue;
                const c = n[t];
                let d;
                r && u(r, d = L(t)) ? s && s.includes(d) ? (i || (i = {}))[d] = c : l[d] = c : Ul(e.emitsOptions, t) || t in o && c === o[t] || (o[t] = c, a = !0)
            }
        if (s) {
            const n = ft(l),
                o = i || t;
            for (let t = 0; t < s.length; t++) {
                const i = s[t];
                l[i] = Cl(r, n, i, o[i], e, !u(o, i))
            }
        }
        return a
    }

    function Cl(e, t, n, l, o, r) {
        const s = e[n];
        if (null != s) {
            const e = u(s, "default");
            if (e && void 0 === l) {
                const e = s.default;
                if (s.type !== Function && !s.skipFactory && p(e)) {
                    const {
                        propsDefaults: r
                    } = o;
                    if (n in r) l = r[n];
                    else {
                        const s = Zo(o);
                        l = r[n] = e.call(null, t), s()
                    }
                } else l = e;
                o.ce && o.ce._setProp(n, l)
            }
            s[0] && (r && !e ? l = !1 : !s[1] || "" !== l && l !== V(n) || (l = !0))
        }
        return l
    }
    const wl = new WeakMap;

    function xl(e, l, o = !1) {
        const r = o ? wl : l.propsCache,
            s = r.get(e);
        if (s) return s;
        const a = e.props,
            c = {},
            h = [];
        let f = !1;
        if (!p(e)) {
            const t = e => {
                f = !0;
                const [t, n] = xl(e, l, !0);
                i(c, t), n && h.push(...n)
            };
            !o && l.mixins.length && l.mixins.forEach(t), e.extends && t(e.extends), e.mixins && e.mixins.forEach(t)
        }
        if (!a && !f) return g(e) && r.set(e, n), n;
        if (d(a))
            for (let n = 0; n < a.length; n++) {
                const e = L(a[n]);
                yl(e) && (c[e] = t)
            } else if (a)
                for (const t in a) {
                    const e = L(t);
                    if (yl(e)) {
                        const n = a[t],
                            l = c[e] = d(n) || p(n) ? {
                                type: n
                            } : i({}, n),
                            o = l.type;
                        let r = !1,
                            s = !0;
                        if (d(o))
                            for (let e = 0; e < o.length; ++e) {
                                const t = o[e],
                                    n = p(t) && t.name;
                                if ("Boolean" === n) {
                                    r = !0;
                                    break
                                }
                                "String" === n && (s = !1)
                            } else r = p(o) && "Boolean" === o.name;
                        l[0] = r, l[1] = s, (r || u(l, "default")) && h.push(e)
                    }
                }
        const m = [c, h];
        return g(e) && r.set(e, m), m
    }

    function yl(e) {
        return "$" !== e[0] && !k(e)
    }
    const bl = e => "_" === e || "_ctx" === e || "$stable" === e,
        kl = e => d(e) ? e.map(xo) : [xo(e)],
        _l = (e, t, n) => {
            if (t._n) return t;
            const l = Xt((...e) => kl(t(...e)), n);
            return l._c = !1, l
        },
        Ml = (e, t, n) => {
            const l = e._ctx;
            for (const o in e) {
                if (bl(o)) continue;
                const n = e[o];
                if (p(n)) t[o] = _l(0, n, l);
                else if (null != n) {
                    const e = kl(n);
                    t[o] = () => e
                }
            }
        },
        Ll = (e, t) => {
            const n = kl(t);
            e.slots.default = () => n
        },
        Sl = (e, t, n) => {
            for (const l in t) !n && bl(l) || (e[l] = t[l])
        },
        Vl = function(e, t) {
            t && t.pendingBranch ? d(e) ? t.effects.push(...e) : t.effects.push(e) : (d(n = e) ? Tt.push(...n) : Ft && -1 === n.id ? Ft.splice(At + 1, 0, n) : 1 & n.flags || (Tt.push(n), n.flags |= 1), Nt());
            var n
        };

    function zl(e) {
        return function(e) {
            T().__VUE__ = !0;
            const {
                insert: o,
                remove: r,
                patchProp: s,
                createElement: i,
                createText: a,
                createComment: c,
                setText: d,
                setElementText: h,
                parentNode: f,
                nextSibling: p,
                setScopeId: m = l,
                insertStaticContent: v
            } = e, g = (e, t, n, l = null, o = null, r = null, s = void 0, i = null, a = !!t.dynamicChildren) => {
                if (e === t) return;
                e && !uo(e, t) && (l = Y(e), G(e, o, r, !0), e = null), -2 === t.patchFlag && (a = !1, t.dynamicChildren = null);
                const {
                    type: c,
                    ref: u,
                    shapeFlag: d
                } = t;
                switch (c) {
                    case Ql:
                        w(e, t, n, l);
                        break;
                    case Yl:
                        x(e, t, n, l);
                        break;
                    case eo:
                        null == e && y(t, n, l, s);
                        break;
                    case Xl:
                        F(e, t, n, l, o, r, s, i, a);
                        break;
                    default:
                        1 & d ? M(e, t, n, l, o, r, s, i, a) : 6 & d ? A(e, t, n, l, o, r, s, i, a) : (64 & d || 128 & d) && c.process(e, t, n, l, o, r, s, i, a, le)
                }
                null != u && o ? wn(u, e && e.ref, r, t || e, !t) : null == u && e && null != e.ref && wn(e.ref, null, r, e, !0)
            }, w = (e, t, n, l) => {
                if (null == e) o(t.el = a(t.children), n, l);
                else {
                    const n = t.el = e.el;
                    t.children !== e.children && d(n, t.children)
                }
            }, x = (e, t, n, l) => {
                null == e ? o(t.el = c(t.children || ""), n, l) : t.el = e.el
            }, y = (e, t, n, l) => {
                [e.el, e.anchor] = v(e.children, t, n, l, e.el, e.anchor)
            }, b = ({
                el: e,
                anchor: t
            }, n, l) => {
                let r;
                for (; e && e !== t;) r = p(e), o(e, n, l), e = r;
                o(t, n, l)
            }, _ = ({
                el: e,
                anchor: t
            }) => {
                let n;
                for (; e && e !== t;) n = p(e), r(e), e = n;
                r(t)
            }, M = (e, t, n, l, o, r, s, i, a) => {
                "svg" === t.type ? s = "svg" : "math" === t.type && (s = "mathml"), null == e ? S(t, n, l, o, r, s, i, a) : j(e, t, o, r, s, i, a)
            }, S = (e, t, n, l, r, a, c, u) => {
                let d, f;
                const {
                    props: p,
                    shapeFlag: m,
                    transition: v,
                    dirs: g
                } = e;
                if (d = e.el = i(e.type, a, p && p.is, p), 8 & m ? h(d, e.children) : 16 & m && Z(e.children, d, null, l, r, Zl(e, a), c, u), g && Qt(e, null, l, "created"), z(d, e, e.scopeId, c, l), p) {
                    for (const e in p) "value" === e || k(e) || s(d, e, null, p[e], a, l);
                    "value" in p && s(d, "value", null, p.value, a), (f = p.onVnodeBeforeMount) && ko(f, l, e)
                }
                g && Qt(e, null, l, "beforeMount");
                const C = function(e, t) {
                    return (!e || e && !e.pendingBranch) && t && !t.persisted
                }(r, v);
                C && v.beforeEnter(d), o(d, t, n), ((f = p && p.onVnodeMounted) || C || g) && Vl(() => {
                    f && ko(f, l, e), C && v.enter(d), g && Qt(e, null, l, "mounted")
                }, r)
            }, z = (e, t, n, l, o) => {
                if (n && m(e, n), l)
                    for (let r = 0; r < l.length; r++) m(e, l[r]);
                if (o) {
                    let n = o.subTree;
                    if (t === n || Jl(n.type) && (n.ssContent === t || n.ssFallback === t)) {
                        const t = o.vnode;
                        z(e, t, t.scopeId, t.slotScopeIds, o.parent)
                    }
                }
            }, Z = (e, t, n, l, o, r, s, i, a = 0) => {
                for (let c = a; c < e.length; c++) {
                    const a = e[c] = i ? yo(e[c]) : xo(e[c]);
                    g(null, a, t, n, l, o, r, s, i)
                }
            }, j = (e, n, l, o, r, i, a) => {
                const c = n.el = e.el;
                let {
                    patchFlag: u,
                    dynamicChildren: d,
                    dirs: f
                } = n;
                u |= 16 & e.patchFlag;
                const p = e.props || t,
                    m = n.props || t;
                let v;
                if (l && jl(l, !1), (v = m.onVnodeBeforeUpdate) && ko(v, l, n, e), f && Qt(n, e, l, "beforeUpdate"), l && jl(l, !0), (p.innerHTML && null == m.innerHTML || p.textContent && null == m.textContent) && h(c, ""), d ? E(e.dynamicChildren, d, c, l, o, Zl(n, r), i) : a || N(e, n, c, null, l, o, Zl(n, r), i, !1), u > 0) {
                    if (16 & u) P(c, p, m, l, r);
                    else if (2 & u && p.class !== m.class && s(c, "class", null, m.class, r), 4 & u && s(c, "style", p.style, m.style, r), 8 & u) {
                        const e = n.dynamicProps;
                        for (let t = 0; t < e.length; t++) {
                            const n = e[t],
                                o = p[n],
                                i = m[n];
                            i === o && "value" !== n || s(c, n, o, i, r, l)
                        }
                    }
                    1 & u && e.children !== n.children && h(c, n.children)
                } else a || null != d || P(c, p, m, l, r);
                ((v = m.onVnodeUpdated) || f) && Vl(() => {
                    v && ko(v, l, n, e), f && Qt(n, e, l, "updated")
                }, o)
            }, E = (e, t, n, l, o, r, s) => {
                for (let i = 0; i < t.length; i++) {
                    const a = e[i],
                        c = t[i],
                        u = a.el && (a.type === Xl || !uo(a, c) || 198 & a.shapeFlag) ? f(a.el) : n;
                    g(a, c, u, null, l, o, r, s, !0)
                }
            }, P = (e, n, l, o, r) => {
                if (n !== l) {
                    if (n !== t)
                        for (const t in n) k(t) || t in l || s(e, t, n[t], null, r, o);
                    for (const t in l) {
                        if (k(t)) continue;
                        const i = l[t],
                            a = n[t];
                        i !== a && "value" !== t && s(e, t, a, i, r, o)
                    }
                    "value" in l && s(e, "value", n.value, l.value, r)
                }
            }, F = (e, t, n, l, r, s, i, c, u) => {
                const d = t.el = e ? e.el : a(""),
                    h = t.anchor = e ? e.anchor : a("");
                let {
                    patchFlag: f,
                    dynamicChildren: p,
                    slotScopeIds: m
                } = t;
                m && (c = c ? c.concat(m) : m), null == e ? (o(d, n, l), o(h, n, l), Z(t.children || [], n, h, r, s, i, c, u)) : f > 0 && 64 & f && p && e.dynamicChildren ? (E(e.dynamicChildren, p, n, r, s, i, c), (null != t.key || r && t === r.subTree) && $l(e, t, !0)) : N(e, t, n, h, r, s, i, c, u)
            }, A = (e, t, n, l, o, r, s, i, a) => {
                t.slotScopeIds = i, null == e ? 512 & t.shapeFlag ? o.ctx.activate(t, n, l, s, a) : O(t, n, l, o, r, s, a) : H(e, t, a)
            }, O = (e, n, l, o, r, s, i) => {
                const a = e.component = function(e, n, l) {
                    const o = e.type,
                        r = (n ? n.appContext : e.appContext) || _o,
                        s = {
                            uid: Mo++,
                            vnode: e,
                            type: o,
                            parent: n,
                            appContext: r,
                            root: null,
                            next: null,
                            subTree: null,
                            effect: null,
                            update: null,
                            job: null,
                            scope: new X(!0),
                            render: null,
                            proxy: null,
                            exposed: null,
                            exposeProxy: null,
                            withProxy: null,
                            provides: n ? n.provides : Object.create(r.provides),
                            ids: n ? n.ids : ["", 0, 0],
                            accessCache: null,
                            renderCache: [],
                            components: null,
                            directives: null,
                            propsOptions: xl(o, r),
                            emitsOptions: Dl(o, r),
                            emit: null,
                            emitted: null,
                            propsDefaults: t,
                            inheritAttrs: o.inheritAttrs,
                            ctx: t,
                            data: t,
                            props: t,
                            attrs: t,
                            slots: t,
                            refs: t,
                            setupState: t,
                            setupContext: null,
                            suspense: l,
                            suspenseId: l ? l.pendingId : 0,
                            asyncDep: null,
                            asyncResolved: !1,
                            isMounted: !1,
                            isUnmounted: !1,
                            isDeactivated: !1,
                            bc: null,
                            c: null,
                            bm: null,
                            m: null,
                            bu: null,
                            u: null,
                            um: null,
                            bum: null,
                            da: null,
                            a: null,
                            rtg: null,
                            rtc: null,
                            ec: null,
                            sp: null
                        };
                    s.ctx = {
                        _: s
                    }, s.root = n ? n.root : s, s.emit = Rl.bind(null, s), e.ce && e.ce(s);
                    return s
                }(e, o, r);
                if (bn(e) && (a.ctx.renderer = le), function(e, t = !1, n = !1) {
                        t && zo(t);
                        const {
                            props: l,
                            children: o
                        } = e.vnode, r = $o(e);
                        vl(e, l, r, t), ((e, t, n) => {
                            const l = e.slots = pl();
                            if (32 & e.vnode.shapeFlag) {
                                const e = t._;
                                e ? (Sl(l, t, n), n && B(l, "_", e, !0)) : Ml(t, l)
                            } else t && Ll(e, t)
                        })(e, o, n || t);
                        const s = r ? function(e, t) {
                            const n = e.type;
                            e.accessCache = Object.create(null), e.proxy = new Proxy(e.ctx, qn);
                            const {
                                setup: l
                            } = n;
                            if (l) {
                                ve();
                                const n = e.setupContext = l.length > 1 ? function(e) {
                                        const t = t => {
                                            e.exposed = t || {}
                                        };
                                        return {
                                            attrs: new Proxy(e.attrs, To),
                                            slots: e.slots,
                                            emit: e.emit,
                                            expose: t
                                        }
                                    }(e) : null,
                                    o = Zo(e),
                                    r = jt(l, e, 0, [e.props, n]),
                                    s = C(r);
                                if (ge(), o(), !s && !e.sp || yn(e) || gn(e), s) {
                                    if (r.then(jo, jo), t) return r.then(t => {
                                        Eo(e, t)
                                    }).catch(t => {
                                        Bt(t, e, 0)
                                    });
                                    e.asyncDep = r
                                } else Eo(e, r)
                            } else Po(e)
                        }(e, t) : void 0;
                        t && zo(!1)
                    }(a, !1, i), a.asyncDep) {
                    if (r && r.registerDep(a, I, i), !e.el) {
                        const t = a.subTree = mo(Yl);
                        x(null, t, n, l), e.placeholder = t.el
                    }
                } else I(a, e, n, l, r, s, i)
            }, H = (e, t, n) => {
                const l = t.component = e.component;
                if (function(e, t, n) {
                        const {
                            props: l,
                            children: o,
                            component: r
                        } = e, {
                            props: s,
                            children: i,
                            patchFlag: a
                        } = t, c = r.emitsOptions;
                        if (t.dirs || t.transition) return !0;
                        if (!(n && a >= 0)) return !(!o && !i || i && i.$stable) || l !== s && (l ? !s || Kl(l, s, c) : !!s);
                        if (1024 & a) return !0;
                        if (16 & a) return l ? Kl(l, s, c) : !!s;
                        if (8 & a) {
                            const e = t.dynamicProps;
                            for (let t = 0; t < e.length; t++) {
                                const n = e[t];
                                if (s[n] !== l[n] && !Ul(c, n)) return !0
                            }
                        }
                        return !1
                    }(e, t, n)) {
                    if (l.asyncDep && !l.asyncResolved) return void R(l, t, n);
                    l.next = t, l.update()
                } else t.el = e.el, l.vnode = t
            }, I = (e, t, n, l, o, r, s) => {
                const i = () => {
                    if (e.isMounted) {
                        let {
                            next: t,
                            bu: n,
                            u: l,
                            parent: a,
                            vnode: c
                        } = e;
                        {
                            const n = Bl(e);
                            if (n) return t && (t.el = c.el, R(e, t, s)), void n.asyncDep.then(() => {
                                e.isUnmounted || i()
                            })
                        }
                        let u, d = t;
                        jl(e, !1), t ? (t.el = c.el, R(e, t, s)) : t = c, n && $(n), (u = t.props && t.props.onVnodeBeforeUpdate) && ko(u, a, t, c), jl(e, !0);
                        const h = Wl(e),
                            p = e.subTree;
                        e.subTree = h, g(p, h, f(p.el), Y(p), e, o, r), t.el = h.el, null === d && function({
                            vnode: e,
                            parent: t
                        }, n) {
                            for (; t;) {
                                const l = t.subTree;
                                if (l.suspense && l.suspense.activeBranch === e && (l.el = e.el), l !== e) break;
                                (e = t.vnode).el = n, t = t.parent
                            }
                        }(e, h.el), l && Vl(l, o), (u = t.props && t.props.onVnodeUpdated) && Vl(() => ko(u, a, t, c), o)
                    } else {
                        let s;
                        const {
                            el: i,
                            props: a
                        } = t, {
                            bm: c,
                            m: u,
                            parent: d,
                            root: h,
                            type: f
                        } = e, p = yn(t);
                        jl(e, !1), c && $(c), !p && (s = a && a.onVnodeBeforeMount) && ko(s, d, t), jl(e, !0);
                        {
                            h.ce && !1 !== h.ce._def.shadowRoot && h.ce._injectChildStyle(f);
                            const s = e.subTree = Wl(e);
                            g(null, s, n, l, e, o, r), t.el = s.el
                        }
                        if (u && Vl(u, o), !p && (s = a && a.onVnodeMounted)) {
                            const e = t;
                            Vl(() => ko(s, d, e), o)
                        }(256 & t.shapeFlag || d && yn(d.vnode) && 256 & d.vnode.shapeFlag) && e.a && Vl(e.a, o), e.isMounted = !0, t = n = l = null
                    }
                };
                e.scope.on();
                const a = e.effect = new te(i);
                e.scope.off();
                const c = e.update = a.run.bind(a),
                    u = e.job = a.runIfDirty.bind(a);
                u.i = e, u.id = e.uid, a.scheduler = () => Rt(u), jl(e, !0), c()
            }, R = (e, n, l) => {
                n.component = e;
                const o = e.vnode.props;
                e.vnode = n, e.next = null,
                    function(e, t, n, l) {
                        const {
                            props: o,
                            attrs: r,
                            vnode: {
                                patchFlag: s
                            }
                        } = e, i = ft(o), [a] = e.propsOptions;
                        let c = !1;
                        if (!(l || s > 0) || 16 & s) {
                            let l;
                            gl(e, t, o, r) && (c = !0);
                            for (const r in i) t && (u(t, r) || (l = V(r)) !== r && u(t, l)) || (a ? !n || void 0 === n[r] && void 0 === n[l] || (o[r] = Cl(a, i, r, void 0, e, !0)) : delete o[r]);
                            if (r !== i)
                                for (const e in r) t && u(t, e) || (delete r[e], c = !0)
                        } else if (8 & s) {
                            const n = e.vnode.dynamicProps;
                            for (let l = 0; l < n.length; l++) {
                                let s = n[l];
                                if (Ul(e.emitsOptions, s)) continue;
                                const d = t[s];
                                if (a)
                                    if (u(r, s)) d !== r[s] && (r[s] = d, c = !0);
                                    else {
                                        const t = L(s);
                                        o[t] = Cl(a, i, t, d, e, !1)
                                    }
                                else d !== r[s] && (r[s] = d, c = !0)
                            }
                        }
                        c && Ve(e.attrs, "set", "")
                    }(e, n.props, o, l), ((e, n, l) => {
                        const {
                            vnode: o,
                            slots: r
                        } = e;
                        let s = !0,
                            i = t;
                        if (32 & o.shapeFlag) {
                            const e = n._;
                            e ? l && 1 === e ? s = !1 : Sl(r, n, l) : (s = !n.$stable, Ml(n, r)), i = n
                        } else n && (Ll(e, n), i = {
                            default: 1
                        });
                        if (s)
                            for (const t in r) bl(t) || null != i[t] || delete r[t]
                    })(e, n.children, l), ve(), Dt(e), ge()
            }, N = (e, t, n, l, o, r, s, i, a = !1) => {
                const c = e && e.children,
                    u = e ? e.shapeFlag : 0,
                    d = t.children,
                    {
                        patchFlag: f,
                        shapeFlag: p
                    } = t;
                if (f > 0) {
                    if (128 & f) return void U(c, d, n, l, o, r, s, i, a);
                    if (256 & f) return void D(c, d, n, l, o, r, s, i, a)
                }
                8 & p ? (16 & u && Q(c, o, r), d !== c && h(n, d)) : 16 & u ? 16 & p ? U(c, d, n, l, o, r, s, i, a) : Q(c, o, r, !0) : (8 & u && h(n, ""), 16 & p && Z(d, n, l, o, r, s, i, a))
            }, D = (e, t, l, o, r, s, i, a, c) => {
                t = t || n;
                const u = (e = e || n).length,
                    d = t.length,
                    h = Math.min(u, d);
                let f;
                for (f = 0; f < h; f++) {
                    const n = t[f] = c ? yo(t[f]) : xo(t[f]);
                    g(e[f], n, l, null, r, s, i, a, c)
                }
                u > d ? Q(e, r, s, !0, !1, h) : Z(t, l, o, r, s, i, a, c, h)
            }, U = (e, t, l, o, r, s, i, a, c) => {
                let u = 0;
                const d = t.length;
                let h = e.length - 1,
                    f = d - 1;
                for (; u <= h && u <= f;) {
                    const n = e[u],
                        o = t[u] = c ? yo(t[u]) : xo(t[u]);
                    if (!uo(n, o)) break;
                    g(n, o, l, null, r, s, i, a, c), u++
                }
                for (; u <= h && u <= f;) {
                    const n = e[h],
                        o = t[f] = c ? yo(t[f]) : xo(t[f]);
                    if (!uo(n, o)) break;
                    g(n, o, l, null, r, s, i, a, c), h--, f--
                }
                if (u > h) {
                    if (u <= f) {
                        const e = f + 1,
                            n = e < d ? t[e].el : o;
                        for (; u <= f;) g(null, t[u] = c ? yo(t[u]) : xo(t[u]), l, n, r, s, i, a, c), u++
                    }
                } else if (u > f)
                    for (; u <= h;) G(e[u], r, s, !0), u++;
                else {
                    const p = u,
                        m = u,
                        v = new Map;
                    for (u = m; u <= f; u++) {
                        const e = t[u] = c ? yo(t[u]) : xo(t[u]);
                        null != e.key && v.set(e.key, u)
                    }
                    let C, w = 0;
                    const x = f - m + 1;
                    let y = !1,
                        b = 0;
                    const k = new Array(x);
                    for (u = 0; u < x; u++) k[u] = 0;
                    for (u = p; u <= h; u++) {
                        const n = e[u];
                        if (w >= x) {
                            G(n, r, s, !0);
                            continue
                        }
                        let o;
                        if (null != n.key) o = v.get(n.key);
                        else
                            for (C = m; C <= f; C++)
                                if (0 === k[C - m] && uo(n, t[C])) {
                                    o = C;
                                    break
                                } void 0 === o ? G(n, r, s, !0) : (k[o - m] = u + 1, o >= b ? b = o : y = !0, g(n, t[o], l, null, r, s, i, a, c), w++)
                    }
                    const _ = y ? function(e) {
                        const t = e.slice(),
                            n = [0];
                        let l, o, r, s, i;
                        const a = e.length;
                        for (l = 0; l < a; l++) {
                            const a = e[l];
                            if (0 !== a) {
                                if (o = n[n.length - 1], e[o] < a) {
                                    t[l] = o, n.push(l);
                                    continue
                                }
                                for (r = 0, s = n.length - 1; r < s;) i = r + s >> 1, e[n[i]] < a ? r = i + 1 : s = i;
                                a < e[n[r]] && (r > 0 && (t[l] = n[r - 1]), n[r] = l)
                            }
                        }
                        r = n.length, s = n[r - 1];
                        for (; r-- > 0;) n[r] = s, s = t[s];
                        return n
                    }(k) : n;
                    for (C = _.length - 1, u = x - 1; u >= 0; u--) {
                        const e = m + u,
                            n = t[e],
                            h = t[e + 1],
                            f = e + 1 < d ? h.el || h.placeholder : o;
                        0 === k[u] ? g(null, n, l, f, r, s, i, a, c) : y && (C < 0 || u !== _[C] ? W(n, l, f, 2) : C--)
                    }
                }
            }, W = (e, t, n, l, s = null) => {
                const {
                    el: i,
                    type: a,
                    transition: c,
                    children: u,
                    shapeFlag: d
                } = e;
                if (6 & d) return void W(e.component.subTree, t, n, l);
                if (128 & d) return void e.suspense.move(t, n, l);
                if (64 & d) return void a.move(e, t, n, le);
                if (a === Xl) {
                    o(i, t, n);
                    for (let e = 0; e < u.length; e++) W(u[e], t, n, l);
                    return void o(e.anchor, t, n)
                }
                if (a === eo) return void b(e, t, n);
                if (2 !== l && 1 & d && c)
                    if (0 === l) c.beforeEnter(i), o(i, t, n), Vl(() => c.enter(i), s);
                    else {
                        const {
                            leave: l,
                            delayLeave: s,
                            afterLeave: a
                        } = c, u = () => {
                            e.ctx.isUnmounted ? r(i) : o(i, t, n)
                        }, d = () => {
                            i._isLeaving && i[tn](!0), l(i, () => {
                                u(), a && a()
                            })
                        };
                        s ? s(i, u, d) : d()
                    }
                else o(i, t, n)
            }, G = (e, t, n, l = !1, o = !1) => {
                const {
                    type: r,
                    props: s,
                    ref: i,
                    children: a,
                    dynamicChildren: c,
                    shapeFlag: u,
                    patchFlag: d,
                    dirs: h,
                    cacheIndex: f
                } = e;
                if (-2 === d && (o = !1), null != i && (ve(), wn(i, null, n, e, !0), ge()), null != f && (t.renderCache[f] = void 0), 256 & u) return void t.ctx.deactivate(e);
                const p = 1 & u && h,
                    m = !yn(e);
                let v;
                if (m && (v = s && s.onVnodeBeforeUnmount) && ko(v, t, e), 6 & u) J(e.component, n, l);
                else {
                    if (128 & u) return void e.suspense.unmount(n, l);
                    p && Qt(e, null, t, "beforeUnmount"), 64 & u ? e.type.remove(e, t, n, le, l) : c && !c.hasOnce && (r !== Xl || d > 0 && 64 & d) ? Q(c, t, n, !1, !0) : (r === Xl && 384 & d || !o && 16 & u) && Q(a, t, n), l && q(e)
                }(m && (v = s && s.onVnodeUnmounted) || p) && Vl(() => {
                    v && ko(v, t, e), p && Qt(e, null, t, "unmounted")
                }, n)
            }, q = e => {
                const {
                    type: t,
                    el: n,
                    anchor: l,
                    transition: o
                } = e;
                if (t === Xl) return void K(n, l);
                if (t === eo) return void _(e);
                const s = () => {
                    r(n), o && !o.persisted && o.afterLeave && o.afterLeave()
                };
                if (1 & e.shapeFlag && o && !o.persisted) {
                    const {
                        leave: t,
                        delayLeave: l
                    } = o, r = () => t(n, s);
                    l ? l(e.el, s, r) : r()
                } else s()
            }, K = (e, t) => {
                let n;
                for (; e !== t;) n = p(e), r(e), e = n;
                r(t)
            }, J = (e, t, n) => {
                const {
                    bum: l,
                    scope: o,
                    job: r,
                    subTree: s,
                    um: i,
                    m: a,
                    a: c
                } = e;
                El(a), El(c), l && $(l), o.stop(), r && (r.flags |= 8, G(s, e, t, n)), i && Vl(i, t), Vl(() => {
                    e.isUnmounted = !0
                }, t)
            }, Q = (e, t, n, l = !1, o = !1, r = 0) => {
                for (let s = r; s < e.length; s++) G(e[s], t, n, l, o)
            }, Y = e => {
                if (6 & e.shapeFlag) return Y(e.component.subTree);
                if (128 & e.shapeFlag) return e.suspense.next();
                const t = p(e.anchor || e.el),
                    n = t && t[Yt];
                return n ? p(n) : t
            };
            let ee = !1;
            const ne = (e, t, n) => {
                    null == e ? t._vnode && G(t._vnode, null, null, !0) : g(t._vnode || null, e, t, null, null, null, n), t._vnode = e, ee || (ee = !0, Dt(), Ut(), ee = !1)
                },
                le = {
                    p: g,
                    um: G,
                    m: W,
                    r: q,
                    mt: O,
                    mc: Z,
                    pc: N,
                    pbc: E,
                    n: Y,
                    o: e
                };
            let oe;
            return {
                render: ne,
                hydrate: oe,
                createApp: ul(ne)
            }
        }(e)
    }

    function Zl({
        type: e,
        props: t
    }, n) {
        return "svg" === n && "foreignObject" === e || "mathml" === n && "annotation-xml" === e && t && t.encoding && t.encoding.includes("html") ? void 0 : n
    }

    function jl({
        effect: e,
        job: t
    }, n) {
        n ? (e.flags |= 32, t.flags |= 4) : (e.flags &= -33, t.flags &= -5)
    }

    function $l(e, t, n = !1) {
        const l = e.children,
            o = t.children;
        if (d(l) && d(o))
            for (let r = 0; r < l.length; r++) {
                const e = l[r];
                let t = o[r];
                1 & t.shapeFlag && !t.dynamicChildren && ((t.patchFlag <= 0 || 32 === t.patchFlag) && (t = o[r] = yo(o[r]), t.el = e.el), n || -2 === t.patchFlag || $l(e, t)), t.type === Ql && -1 !== t.patchFlag && (t.el = e.el), t.type !== Yl || t.el || (t.el = e.el)
            }
    }

    function Bl(e) {
        const t = e.subTree.component;
        if (t) return t.asyncDep && !t.asyncResolved ? t : Bl(t)
    }

    function El(e) {
        if (e)
            for (let t = 0; t < e.length; t++) e[t].flags |= 8
    }
    const Pl = Symbol.for("v-scx"),
        Tl = () => hl(Pl);

    function Fl(e, t, n) {
        return Al(e, t, n)
    }

    function Al(e, n, o = t) {
        const {
            immediate: r,
            deep: s,
            flush: a,
            once: c
        } = o, u = i({}, o), d = n && r || !n && "post" !== a;
        let h;
        if (Bo)
            if ("sync" === a) {
                const e = Tl();
                h = e.__watcherHandles || (e.__watcherHandles = [])
            } else if (!d) {
            const e = () => {};
            return e.stop = l, e.resume = l, e.pause = l, e
        }
        const f = Lo;
        u.call = (e, t, n) => $t(e, f, t, n);
        let p = !1;
        "post" === a ? u.scheduler = e => {
            Vl(e, f && f.suspense)
        } : "sync" !== a && (p = !0, u.scheduler = (e, t) => {
            t ? e() : Rt(e)
        }), u.augmentJob = e => {
            n && (e.flags |= 4), p && (e.flags |= 2, f && (e.id = f.uid, e.i = f))
        };
        const m = zt(e, n, u);
        return Bo && (h ? h.push(m) : d && m()), m
    }

    function Ol(e, t, n) {
        const l = this.proxy,
            o = m(e) ? e.includes(".") ? Hl(l, e) : () => l[e] : e.bind(l, l);
        let r;
        p(t) ? r = t : (r = t.handler, n = t);
        const s = Zo(this),
            i = Al(o, r.bind(l), n);
        return s(), i
    }

    function Hl(e, t) {
        const n = t.split(".");
        return () => {
            let t = e;
            for (let e = 0; e < n.length && t; e++) t = t[n[e]];
            return t
        }
    }
    const Il = (e, t) => "modelValue" === t || "model-value" === t ? e.modelModifiers : e[`${t}Modifiers`] || e[`${L(t)}Modifiers`] || e[`${V(t)}Modifiers`];

    function Rl(e, n, ...l) {
        if (e.isUnmounted) return;
        const o = e.vnode.props || t;
        let r = l;
        const s = n.startsWith("update:"),
            i = s && Il(o, n.slice(7));
        let a;
        i && (i.trim && (r = l.map(e => m(e) ? e.trim() : e)), i.number && (r = l.map(E)));
        let c = o[a = Z(n)] || o[a = Z(L(n))];
        !c && s && (c = o[a = Z(V(n))]), c && $t(c, e, 6, r);
        const u = o[a + "Once"];
        if (u) {
            if (e.emitted) {
                if (e.emitted[a]) return
            } else e.emitted = {};
            e.emitted[a] = !0, $t(u, e, 6, r)
        }
    }
    const Nl = new WeakMap;

    function Dl(e, t, n = !1) {
        const l = n ? Nl : t.emitsCache,
            o = l.get(e);
        if (void 0 !== o) return o;
        const r = e.emits;
        let s = {},
            a = !1;
        if (!p(e)) {
            const l = e => {
                const n = Dl(e, t, !0);
                n && (a = !0, i(s, n))
            };
            !n && t.mixins.length && t.mixins.forEach(l), e.extends && l(e.extends), e.mixins && e.mixins.forEach(l)
        }
        return r || a ? (d(r) ? r.forEach(e => s[e] = null) : i(s, r), g(e) && l.set(e, s), s) : (g(e) && l.set(e, null), null)
    }

    function Ul(e, t) {
        return !(!e || !r(t)) && (t = t.slice(2).replace(/Once$/, ""), u(e, t[0].toLowerCase() + t.slice(1)) || u(e, V(t)) || u(e, t))
    }

    function Wl(e) {
        const {
            type: t,
            vnode: n,
            proxy: l,
            withProxy: o,
            propsOptions: [r],
            slots: i,
            attrs: a,
            emit: c,
            render: u,
            renderCache: d,
            props: h,
            data: f,
            setupState: p,
            ctx: m,
            inheritAttrs: v
        } = e, g = Jt(e);
        let C, w;
        try {
            if (4 & n.shapeFlag) {
                const e = o || l,
                    t = e;
                C = xo(u.call(t, e, d, h, p, f, m)), w = a
            } else {
                const e = t;
                0, C = xo(e.length > 1 ? e(h, {
                    attrs: a,
                    slots: i,
                    emit: c
                }) : e(h, null)), w = t.props ? a : Gl(a)
            }
        } catch (y) {
            to.length = 0, Bt(y, e, 1), C = mo(Yl)
        }
        let x = C;
        if (w && !1 !== v) {
            const e = Object.keys(w),
                {
                    shapeFlag: t
                } = x;
            e.length && 7 & t && (r && e.some(s) && (w = ql(w, r)), x = vo(x, w, !1, !0))
        }
        return n.dirs && (x = vo(x, null, !1, !0), x.dirs = x.dirs ? x.dirs.concat(n.dirs) : n.dirs), n.transition && pn(x, n.transition), C = x, Jt(g), C
    }
    const Gl = e => {
            let t;
            for (const n in e)("class" === n || "style" === n || r(n)) && ((t || (t = {}))[n] = e[n]);
            return t
        },
        ql = (e, t) => {
            const n = {};
            for (const l in e) s(l) && l.slice(9) in t || (n[l] = e[l]);
            return n
        };

    function Kl(e, t, n) {
        const l = Object.keys(t);
        if (l.length !== Object.keys(e).length) return !0;
        for (let o = 0; o < l.length; o++) {
            const r = l[o];
            if (t[r] !== e[r] && !Ul(n, r)) return !0
        }
        return !1
    }
    const Jl = e => e.__isSuspense;
    const Xl = Symbol.for("v-fgt"),
        Ql = Symbol.for("v-txt"),
        Yl = Symbol.for("v-cmt"),
        eo = Symbol.for("v-stc"),
        to = [];
    let no = null;

    function lo(e = !1) {
        to.push(no = e ? null : [])
    }
    let oo = 1;

    function ro(e, t = !1) {
        oo += e, e < 0 && no && t && (no.hasOnce = !0)
    }

    function so(e) {
        return e.dynamicChildren = oo > 0 ? no || n : null, to.pop(), no = to[to.length - 1] || null, oo > 0 && no && no.push(e), e
    }

    function io(e, t, n, l, o, r) {
        return so(po(e, t, n, l, o, r, !0))
    }

    function ao(e, t, n, l, o) {
        return so(mo(e, t, n, l, o, !0))
    }

    function co(e) {
        return !!e && !0 === e.__v_isVNode
    }

    function uo(e, t) {
        return e.type === t.type && e.key === t.key
    }
    const ho = ({
            key: e
        }) => null != e ? e : null,
        fo = ({
            ref: e,
            ref_key: t,
            ref_for: n
        }) => ("number" == typeof e && (e = "" + e), null != e ? m(e) || gt(e) || p(e) ? {
            i: qt,
            r: e,
            k: t,
            f: !!n
        } : e : null);

    function po(e, t = null, n = null, l = 0, o = null, r = (e === Xl ? 0 : 1), s = !1, i = !1) {
        const a = {
            __v_isVNode: !0,
            __v_skip: !0,
            type: e,
            props: t,
            key: t && ho(t),
            ref: t && fo(t),
            scopeId: Kt,
            slotScopeIds: null,
            children: n,
            component: null,
            suspense: null,
            ssContent: null,
            ssFallback: null,
            dirs: null,
            transition: null,
            el: null,
            anchor: null,
            target: null,
            targetStart: null,
            targetAnchor: null,
            staticCount: 0,
            shapeFlag: r,
            patchFlag: l,
            dynamicProps: o,
            dynamicChildren: null,
            appContext: null,
            ctx: qt
        };
        return i ? (bo(a, n), 128 & r && e.normalize(a)) : n && (a.shapeFlag |= m(n) ? 8 : 16), oo > 0 && !s && no && (a.patchFlag > 0 || 6 & r) && 32 !== a.patchFlag && no.push(a), a
    }
    const mo = function(e, t = null, n = null, l = 0, o = null, r = !1) {
        e && e !== On || (e = Yl);
        if (co(e)) {
            const l = vo(e, t, !0);
            return n && bo(l, n), oo > 0 && !r && no && (6 & l.shapeFlag ? no[no.indexOf(e)] = l : no.push(l)), l.patchFlag = -2, l
        }
        s = e, p(s) && "__vccOpts" in s && (e = e.__vccOpts);
        var s;
        if (t) {
            t = function(e) {
                return e ? ht(e) || ml(e) ? i({}, e) : e : null
            }(t);
            let {
                class: e,
                style: n
            } = t;
            e && !m(e) && (t.class = R(e)), g(n) && (ht(n) && !d(n) && (n = i({}, n)), t.style = F(n))
        }
        const a = m(e) ? 1 : Jl(e) ? 128 : en(e) ? 64 : g(e) ? 4 : p(e) ? 2 : 0;
        return po(e, t, n, l, o, a, r, !0)
    };

    function vo(e, t, n = !1, l = !1) {
        const {
            props: o,
            ref: s,
            patchFlag: i,
            children: a,
            transition: c
        } = e, u = t ? function(...e) {
            const t = {};
            for (let n = 0; n < e.length; n++) {
                const l = e[n];
                for (const e in l)
                    if ("class" === e) t.class !== l.class && (t.class = R([t.class, l.class]));
                    else if ("style" === e) t.style = F([t.style, l.style]);
                else if (r(e)) {
                    const n = t[e],
                        o = l[e];
                    !o || n === o || d(n) && n.includes(o) || (t[e] = n ? [].concat(n, o) : o)
                } else "" !== e && (t[e] = l[e])
            }
            return t
        }(o || {}, t) : o, h = {
            __v_isVNode: !0,
            __v_skip: !0,
            type: e.type,
            props: u,
            key: u && ho(u),
            ref: t && t.ref ? n && s ? d(s) ? s.concat(fo(t)) : [s, fo(t)] : fo(t) : s,
            scopeId: e.scopeId,
            slotScopeIds: e.slotScopeIds,
            children: a,
            target: e.target,
            targetStart: e.targetStart,
            targetAnchor: e.targetAnchor,
            staticCount: e.staticCount,
            shapeFlag: e.shapeFlag,
            patchFlag: t && e.type !== Xl ? -1 === i ? 16 : 16 | i : i,
            dynamicProps: e.dynamicProps,
            dynamicChildren: e.dynamicChildren,
            appContext: e.appContext,
            dirs: e.dirs,
            transition: c,
            component: e.component,
            suspense: e.suspense,
            ssContent: e.ssContent && vo(e.ssContent),
            ssFallback: e.ssFallback && vo(e.ssFallback),
            placeholder: e.placeholder,
            el: e.el,
            anchor: e.anchor,
            ctx: e.ctx,
            ce: e.ce
        };
        return c && l && pn(h, c.clone(h)), h
    }

    function go(e = " ", t = 0) {
        return mo(Ql, null, e, t)
    }

    function Co(e, t) {
        const n = mo(eo, null, e);
        return n.staticCount = t, n
    }

    function wo(e = "", t = !1) {
        return t ? (lo(), ao(Yl, null, e)) : mo(Yl, null, e)
    }

    function xo(e) {
        return null == e || "boolean" == typeof e ? mo(Yl) : d(e) ? mo(Xl, null, e.slice()) : co(e) ? yo(e) : mo(Ql, null, String(e))
    }

    function yo(e) {
        return null === e.el && -1 !== e.patchFlag || e.memo ? e : vo(e)
    }

    function bo(e, t) {
        let n = 0;
        const {
            shapeFlag: l
        } = e;
        if (null == t) t = null;
        else if (d(t)) n = 16;
        else if ("object" == typeof t) {
            if (65 & l) {
                const n = t.default;
                return void(n && (n._c && (n._d = !1), bo(e, n()), n._c && (n._d = !0)))
            } {
                n = 32;
                const l = t._;
                l || ml(t) ? 3 === l && qt && (1 === qt.slots._ ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024)) : t._ctx = qt
            }
        } else p(t) ? (t = {
            default: t,
            _ctx: qt
        }, n = 32) : (t = String(t), 64 & l ? (n = 16, t = [go(t)]) : n = 8);
        e.children = t, e.shapeFlag |= n
    }

    function ko(e, t, n, l = null) {
        $t(e, t, 7, [n, l])
    }
    const _o = al();
    let Mo = 0;
    let Lo = null;
    const So = () => Lo || qt;
    let Vo, zo;
    {
        const e = T(),
            t = (t, n) => {
                let l;
                return (l = e[t]) || (l = e[t] = []), l.push(n), e => {
                    l.length > 1 ? l.forEach(t => t(e)) : l[0](e)
                }
            };
        Vo = t("__VUE_INSTANCE_SETTERS__", e => Lo = e), zo = t("__VUE_SSR_SETTERS__", e => Bo = e)
    }
    const Zo = e => {
            const t = Lo;
            return Vo(e), e.scope.on(), () => {
                e.scope.off(), Vo(t)
            }
        },
        jo = () => {
            Lo && Lo.scope.off(), Vo(null)
        };

    function $o(e) {
        return 4 & e.vnode.shapeFlag
    }
    let Bo = !1;

    function Eo(e, t, n) {
        p(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : g(t) && (e.setupState = bt(t)), Po(e)
    }

    function Po(e, t, n) {
        const o = e.type;
        e.render || (e.render = o.render || l);
        {
            const t = Zo(e);
            ve();
            try {
                Xn(e)
            } finally {
                ge(), t()
            }
        }
    }
    const To = {
        get: (e, t) => (Se(e, 0, ""), e[t])
    };

    function Fo(e) {
        return e.exposed ? e.exposeProxy || (e.exposeProxy = new Proxy(bt(pt(e.exposed)), {
            get: (t, n) => n in t ? t[n] : n in Wn ? Wn[n](e) : void 0,
            has: (e, t) => t in e || t in Wn
        })) : e.proxy
    }

    function Ao(e, t = !0) {
        return p(e) ? e.displayName || e.name : e.name || t && e.__name
    }
    const Oo = (e, t) => {
        const n = function(e, t, n = !1) {
            let l, o;
            return p(e) ? l = e : (l = e.get, o = e.set), new Mt(l, o, n)
        }(e, 0, Bo);
        return n
    };
    const Ho = "3.5.22";
    let Io;
    const Ro = "undefined" != typeof window && window.trustedTypes;
    if (Ro) try {
        Io = Ro.createPolicy("vue", {
            createHTML: e => e
        })
    } catch (Sf) {}
    const No = Io ? e => Io.createHTML(e) : e => e,
        Do = "undefined" != typeof document ? document : null,
        Uo = Do && Do.createElement("template"),
        Wo = {
            insert: (e, t, n) => {
                t.insertBefore(e, n || null)
            },
            remove: e => {
                const t = e.parentNode;
                t && t.removeChild(e)
            },
            createElement: (e, t, n, l) => {
                const o = "svg" === t ? Do.createElementNS("http://www.w3.org/2000/svg", e) : "mathml" === t ? Do.createElementNS("http://www.w3.org/1998/Math/MathML", e) : n ? Do.createElement(e, {
                    is: n
                }) : Do.createElement(e);
                return "select" === e && l && null != l.multiple && o.setAttribute("multiple", l.multiple), o
            },
            createText: e => Do.createTextNode(e),
            createComment: e => Do.createComment(e),
            setText: (e, t) => {
                e.nodeValue = t
            },
            setElementText: (e, t) => {
                e.textContent = t
            },
            parentNode: e => e.parentNode,
            nextSibling: e => e.nextSibling,
            querySelector: e => Do.querySelector(e),
            setScopeId(e, t) {
                e.setAttribute(t, "")
            },
            insertStaticContent(e, t, n, l, o, r) {
                const s = n ? n.previousSibling : t.lastChild;
                if (o && (o === r || o.nextSibling))
                    for (; t.insertBefore(o.cloneNode(!0), n), o !== r && (o = o.nextSibling););
                else {
                    Uo.innerHTML = No("svg" === l ? `<svg>${e}</svg>` : "mathml" === l ? `<math>${e}</math>` : e);
                    const o = Uo.content;
                    if ("svg" === l || "mathml" === l) {
                        const e = o.firstChild;
                        for (; e.firstChild;) o.appendChild(e.firstChild);
                        o.removeChild(e)
                    }
                    t.insertBefore(o, n)
                }
                return [s ? s.nextSibling : t.firstChild, n ? n.previousSibling : t.lastChild]
            }
        },
        Go = "transition",
        qo = "animation",
        Ko = Symbol("_vtc"),
        Jo = {
            name: String,
            type: String,
            css: {
                type: Boolean,
                default: !0
            },
            duration: [String, Number, Object],
            enterFromClass: String,
            enterActiveClass: String,
            enterToClass: String,
            appearFromClass: String,
            appearActiveClass: String,
            appearToClass: String,
            leaveFromClass: String,
            leaveActiveClass: String,
            leaveToClass: String
        },
        Xo = i({}, rn, Jo),
        Qo = (e => (e.displayName = "Transition", e.props = Xo, e))((e, {
            slots: t
        }) => function(e, t, n) {
            try {
                ro(-1);
                const l = arguments.length;
                return 2 === l ? g(t) && !d(t) ? co(t) ? mo(e, null, [t]) : mo(e, t) : mo(e, null, t) : (l > 3 ? n = Array.prototype.slice.call(arguments, 2) : 3 === l && co(n) && (n = [n]), mo(e, t, n))
            } finally {
                ro(1)
            }
        }(cn, tr(e), t)),
        Yo = (e, t = []) => {
            d(e) ? e.forEach(e => e(...t)) : e && e(...t)
        },
        er = e => !!e && (d(e) ? e.some(e => e.length > 1) : e.length > 1);

    function tr(e) {
        const t = {};
        for (const i in e) i in Jo || (t[i] = e[i]);
        if (!1 === e.css) return t;
        const {
            name: n = "v",
            type: l,
            duration: o,
            enterFromClass: r = `${n}-enter-from`,
            enterActiveClass: s = `${n}-enter-active`,
            enterToClass: a = `${n}-enter-to`,
            appearFromClass: c = r,
            appearActiveClass: u = s,
            appearToClass: d = a,
            leaveFromClass: h = `${n}-leave-from`,
            leaveActiveClass: f = `${n}-leave-active`,
            leaveToClass: p = `${n}-leave-to`
        } = e, m = function(e) {
            if (null == e) return null;
            if (g(e)) return [nr(e.enter), nr(e.leave)];
            {
                const t = nr(e);
                return [t, t]
            }
        }(o), v = m && m[0], C = m && m[1], {
            onBeforeEnter: w,
            onEnter: x,
            onEnterCancelled: y,
            onLeave: b,
            onLeaveCancelled: k,
            onBeforeAppear: _ = w,
            onAppear: M = x,
            onAppearCancelled: L = y
        } = t, S = (e, t, n, l) => {
            e._enterCancelled = l, or(e, t ? d : a), or(e, t ? u : s), n && n()
        }, V = (e, t) => {
            e._isLeaving = !1, or(e, h), or(e, p), or(e, f), t && t()
        }, z = e => (t, n) => {
            const o = e ? M : x,
                s = () => S(t, e, n);
            Yo(o, [t, s]), rr(() => {
                or(t, e ? c : r), lr(t, e ? d : a), er(o) || ir(t, l, v, s)
            })
        };
        return i(t, {
            onBeforeEnter(e) {
                Yo(w, [e]), lr(e, r), lr(e, s)
            },
            onBeforeAppear(e) {
                Yo(_, [e]), lr(e, c), lr(e, u)
            },
            onEnter: z(!1),
            onAppear: z(!0),
            onLeave(e, t) {
                e._isLeaving = !0;
                const n = () => V(e, t);
                lr(e, h), e._enterCancelled ? (lr(e, f), dr(e)) : (dr(e), lr(e, f)), rr(() => {
                    e._isLeaving && (or(e, h), lr(e, p), er(b) || ir(e, l, C, n))
                }), Yo(b, [e, n])
            },
            onEnterCancelled(e) {
                S(e, !1, void 0, !0), Yo(y, [e])
            },
            onAppearCancelled(e) {
                S(e, !0, void 0, !0), Yo(L, [e])
            },
            onLeaveCancelled(e) {
                V(e), Yo(k, [e])
            }
        })
    }

    function nr(e) {
        const t = (e => {
            const t = m(e) ? Number(e) : NaN;
            return isNaN(t) ? e : t
        })(e);
        return t
    }

    function lr(e, t) {
        t.split(/\s+/).forEach(t => t && e.classList.add(t)), (e[Ko] || (e[Ko] = new Set)).add(t)
    }

    function or(e, t) {
        t.split(/\s+/).forEach(t => t && e.classList.remove(t));
        const n = e[Ko];
        n && (n.delete(t), n.size || (e[Ko] = void 0))
    }

    function rr(e) {
        requestAnimationFrame(() => {
            requestAnimationFrame(e)
        })
    }
    let sr = 0;

    function ir(e, t, n, l) {
        const o = e._endId = ++sr,
            r = () => {
                o === e._endId && l()
            };
        if (null != n) return setTimeout(r, n);
        const {
            type: s,
            timeout: i,
            propCount: a
        } = ar(e, t);
        if (!s) return l();
        const c = s + "end";
        let u = 0;
        const d = () => {
                e.removeEventListener(c, h), r()
            },
            h = t => {
                t.target === e && ++u >= a && d()
            };
        setTimeout(() => {
            u < a && d()
        }, i + 1), e.addEventListener(c, h)
    }

    function ar(e, t) {
        const n = window.getComputedStyle(e),
            l = e => (n[e] || "").split(", "),
            o = l(`${Go}Delay`),
            r = l(`${Go}Duration`),
            s = cr(o, r),
            i = l(`${qo}Delay`),
            a = l(`${qo}Duration`),
            c = cr(i, a);
        let u = null,
            d = 0,
            h = 0;
        t === Go ? s > 0 && (u = Go, d = s, h = r.length) : t === qo ? c > 0 && (u = qo, d = c, h = a.length) : (d = Math.max(s, c), u = d > 0 ? s > c ? Go : qo : null, h = u ? u === Go ? r.length : a.length : 0);
        return {
            type: u,
            timeout: d,
            propCount: h,
            hasTransform: u === Go && /\b(?:transform|all)(?:,|$)/.test(l(`${Go}Property`).toString())
        }
    }

    function cr(e, t) {
        for (; e.length < t.length;) e = e.concat(e);
        return Math.max(...t.map((t, n) => ur(t) + ur(e[n])))
    }

    function ur(e) {
        return "auto" === e ? 0 : 1e3 * Number(e.slice(0, -1).replace(",", "."))
    }

    function dr(e) {
        return (e ? e.ownerDocument : document).body.offsetHeight
    }
    const hr = Symbol("_vod"),
        fr = Symbol("_vsh"),
        pr = Symbol(""),
        mr = /(?:^|;)\s*display\s*:/;
    const vr = /\s*!important$/;

    function gr(e, t, n) {
        if (d(n)) n.forEach(n => gr(e, t, n));
        else if (null == n && (n = ""), t.startsWith("--")) e.setProperty(t, n);
        else {
            const l = function(e, t) {
                const n = wr[t];
                if (n) return n;
                let l = L(t);
                if ("filter" !== l && l in e) return wr[t] = l;
                l = z(l);
                for (let o = 0; o < Cr.length; o++) {
                    const n = Cr[o] + l;
                    if (n in e) return wr[t] = n
                }
                return t
            }(e, t);
            vr.test(n) ? e.setProperty(V(l), n.replace(vr, ""), "important") : e[l] = n
        }
    }
    const Cr = ["Webkit", "Moz", "ms"],
        wr = {};
    const xr = "http://www.w3.org/1999/xlink";

    function yr(e, t, n, l, o, r = N(t)) {
        l && t.startsWith("xlink:") ? null == n ? e.removeAttributeNS(xr, t.slice(6, t.length)) : e.setAttributeNS(xr, t, n) : null == n || r && !D(n) ? e.removeAttribute(t) : e.setAttribute(t, r ? "" : v(n) ? String(n) : n)
    }

    function br(e, t, n, l, o) {
        if ("innerHTML" === t || "textContent" === t) return void(null != n && (e[t] = "innerHTML" === t ? No(n) : n));
        const r = e.tagName;
        if ("value" === t && "PROGRESS" !== r && !r.includes("-")) {
            const l = "OPTION" === r ? e.getAttribute("value") || "" : e.value,
                o = null == n ? "checkbox" === e.type ? "on" : "" : String(n);
            return l === o && "_value" in e || (e.value = o), null == n && e.removeAttribute(t), void(e._value = n)
        }
        let s = !1;
        if ("" === n || null == n) {
            const l = typeof e[t];
            "boolean" === l ? n = D(n) : null == n && "string" === l ? (n = "", s = !0) : "number" === l && (n = 0, s = !0)
        }
        try {
            e[t] = n
        } catch (Sf) {}
        s && e.removeAttribute(o || t)
    }
    const kr = Symbol("_vei");

    function _r(e, t, n, l, o = null) {
        const r = e[kr] || (e[kr] = {}),
            s = r[t];
        if (l && s) s.value = l;
        else {
            const [n, i] = function(e) {
                let t;
                if (Mr.test(e)) {
                    let n;
                    for (t = {}; n = e.match(Mr);) e = e.slice(0, e.length - n[0].length), t[n[0].toLowerCase()] = !0
                }
                const n = ":" === e[2] ? e.slice(3) : V(e.slice(2));
                return [n, t]
            }(t);
            if (l) {
                const s = r[t] = function(e, t) {
                    const n = e => {
                        if (e._vts) {
                            if (e._vts <= n.attached) return
                        } else e._vts = Date.now();
                        $t(function(e, t) {
                            if (d(t)) {
                                const n = e.stopImmediatePropagation;
                                return e.stopImmediatePropagation = () => {
                                    n.call(e), e._stopped = !0
                                }, t.map(e => t => !t._stopped && e && e(t))
                            }
                            return t
                        }(e, n.value), t, 5, [e])
                    };
                    return n.value = e, n.attached = Vr(), n
                }(l, o);
                ! function(e, t, n, l) {
                    e.addEventListener(t, n, l)
                }(e, n, s, i)
            } else s && (! function(e, t, n, l) {
                e.removeEventListener(t, n, l)
            }(e, n, s, i), r[t] = void 0)
        }
    }
    const Mr = /(?:Once|Passive|Capture)$/;
    let Lr = 0;
    const Sr = Promise.resolve(),
        Vr = () => Lr || (Sr.then(() => Lr = 0), Lr = Date.now());
    const zr = e => 111 === e.charCodeAt(0) && 110 === e.charCodeAt(1) && e.charCodeAt(2) > 96 && e.charCodeAt(2) < 123;
    const Zr = new WeakMap,
        jr = new WeakMap,
        $r = Symbol("_moveCb"),
        Br = Symbol("_enterCb"),
        Er = (e => (delete e.props.mode, e))({
            name: "TransitionGroup",
            props: i({}, Xo, {
                tag: String,
                moveClass: String
            }),
            setup(e, {
                slots: t
            }) {
                const n = So(),
                    l = ln();
                let o, r;
                return $n(() => {
                    if (!o.length) return;
                    const t = e.moveClass || `${e.name||"v"}-move`;
                    if (! function(e, t, n) {
                            const l = e.cloneNode(),
                                o = e[Ko];
                            o && o.forEach(e => {
                                e.split(/\s+/).forEach(e => e && l.classList.remove(e))
                            });
                            n.split(/\s+/).forEach(e => e && l.classList.add(e)), l.style.display = "none";
                            const r = 1 === t.nodeType ? t : t.parentNode;
                            r.appendChild(l);
                            const {
                                hasTransform: s
                            } = ar(l);
                            return r.removeChild(l), s
                        }(o[0].el, n.vnode.el, t)) return void(o = []);
                    o.forEach(Pr), o.forEach(Tr);
                    const l = o.filter(Fr);
                    dr(n.vnode.el), l.forEach(e => {
                        const n = e.el,
                            l = n.style;
                        lr(n, t), l.transform = l.webkitTransform = l.transitionDuration = "";
                        const o = n[$r] = e => {
                            e && e.target !== n || e && !e.propertyName.endsWith("transform") || (n.removeEventListener("transitionend", o), n[$r] = null, or(n, t))
                        };
                        n.addEventListener("transitionend", o)
                    }), o = []
                }), () => {
                    const s = ft(e),
                        i = tr(s);
                    let a = s.tag || Xl;
                    if (o = [], r)
                        for (let e = 0; e < r.length; e++) {
                            const t = r[e];
                            t.el && t.el instanceof Element && (o.push(t), pn(t, dn(t, i, l, n)), Zr.set(t, t.el.getBoundingClientRect()))
                        }
                    r = t.default ? mn(t.default()) : [];
                    for (let e = 0; e < r.length; e++) {
                        const t = r[e];
                        null != t.key && pn(t, dn(t, i, l, n))
                    }
                    return mo(a, null, r)
                }
            }
        });

    function Pr(e) {
        const t = e.el;
        t[$r] && t[$r](), t[Br] && t[Br]()
    }

    function Tr(e) {
        jr.set(e, e.el.getBoundingClientRect())
    }

    function Fr(e) {
        const t = Zr.get(e),
            n = jr.get(e),
            l = t.left - n.left,
            o = t.top - n.top;
        if (l || o) {
            const t = e.el.style;
            return t.transform = t.webkitTransform = `translate(${l}px,${o}px)`, t.transitionDuration = "0s", e
        }
    }
    const Ar = i({
        patchProp: (e, t, n, l, o, i) => {
            const a = "svg" === o;
            "class" === t ? function(e, t, n) {
                const l = e[Ko];
                l && (t = (t ? [t, ...l] : [...l]).join(" ")), null == t ? e.removeAttribute("class") : n ? e.setAttribute("class", t) : e.className = t
            }(e, l, a) : "style" === t ? function(e, t, n) {
                const l = e.style,
                    o = m(n);
                let r = !1;
                if (n && !o) {
                    if (t)
                        if (m(t))
                            for (const e of t.split(";")) {
                                const t = e.slice(0, e.indexOf(":")).trim();
                                null == n[t] && gr(l, t, "")
                            } else
                                for (const e in t) null == n[e] && gr(l, e, "");
                    for (const e in n) "display" === e && (r = !0), gr(l, e, n[e])
                } else if (o) {
                    if (t !== n) {
                        const e = l[pr];
                        e && (n += ";" + e), l.cssText = n, r = mr.test(n)
                    }
                } else t && e.removeAttribute("style");
                hr in e && (e[hr] = r ? l.display : "", e[fr] && (l.display = "none"))
            }(e, n, l) : r(t) ? s(t) || _r(e, t, 0, l, i) : ("." === t[0] ? (t = t.slice(1), 1) : "^" === t[0] ? (t = t.slice(1), 0) : function(e, t, n, l) {
                if (l) return "innerHTML" === t || "textContent" === t || !!(t in e && zr(t) && p(n));
                if ("spellcheck" === t || "draggable" === t || "translate" === t || "autocorrect" === t) return !1;
                if ("form" === t) return !1;
                if ("list" === t && "INPUT" === e.tagName) return !1;
                if ("type" === t && "TEXTAREA" === e.tagName) return !1;
                if ("width" === t || "height" === t) {
                    const t = e.tagName;
                    if ("IMG" === t || "VIDEO" === t || "CANVAS" === t || "SOURCE" === t) return !1
                }
                if (zr(t) && m(n)) return !1;
                return t in e
            }(e, t, l, a)) ? (br(e, t, l), e.tagName.includes("-") || "value" !== t && "checked" !== t && "selected" !== t || yr(e, t, l, a, 0, "value" !== t)) : !e._isVueCE || !/[A-Z]/.test(t) && m(l) ? ("true-value" === t ? e._trueValue = l : "false-value" === t && (e._falseValue = l), yr(e, t, l, a)) : br(e, L(t), l, 0, t)
        }
    }, Wo);
    let Or;
    let Hr;
    const Ir = e => Hr = e,
        Rr = Symbol();

    function Nr(e) {
        return e && "object" == typeof e && "[object Object]" === Object.prototype.toString.call(e) && "function" != typeof e.toJSON
    }
    var Dr, Ur;
    (Ur = Dr || (Dr = {})).direct = "direct", Ur.patchObject = "patch object", Ur.patchFunction = "patch function";
    const Wr = () => {};

    function Gr(e, t, n, l = Wr) {
        e.push(t);
        const o = () => {
            const n = e.indexOf(t);
            n > -1 && (e.splice(n, 1), l())
        };
        var r;
        return !n && Y() && (r = o, K && K.cleanups.push(r)), o
    }

    function qr(e, ...t) {
        e.slice().forEach(e => {
            e(...t)
        })
    }
    const Kr = e => e(),
        Jr = Symbol(),
        Xr = Symbol();

    function Qr(e, t) {
        e instanceof Map && t instanceof Map ? t.forEach((t, n) => e.set(n, t)) : e instanceof Set && t instanceof Set && t.forEach(e.add, e);
        for (const n in t) {
            if (!t.hasOwnProperty(n)) continue;
            const l = t[n],
                o = e[n];
            Nr(o) && Nr(l) && e.hasOwnProperty(n) && !gt(l) && !ct(l) ? e[n] = Qr(o, l) : e[n] = l
        }
        return e
    }
    const Yr = Symbol();

    function es(e) {
        return !Nr(e) || !Object.prototype.hasOwnProperty.call(e, Yr)
    }
    const {
        assign: ts
    } = Object;

    function ns(e) {
        return !(!gt(e) || !e.effect)
    }

    function ls(e, t, n, l) {
        const {
            state: o,
            actions: r,
            getters: s
        } = t, i = n.state.value[e];
        let a;
        return a = os(e, function() {
            i || (n.state.value[e] = o ? o() : {});
            const t = function(e) {
                const t = d(e) ? new Array(e.length) : {};
                for (const n in e) t[n] = _t(e, n);
                return t
            }(n.state.value[e]);
            return ts(t, r, Object.keys(s || {}).reduce((t, l) => (t[l] = pt(Oo(() => {
                Ir(n);
                const t = n._s.get(e);
                return s[l].call(t, t)
            })), t), {}))
        }, t, n, l, !0), a
    }

    function os(e, t, n = {}, l, o, r) {
        let s;
        const i = ts({
                actions: {}
            }, n),
            a = {
                deep: !0
            };
        let c, u, d, h = [],
            f = [];
        const p = l.state.value[e];
        let m;

        function v(t) {
            let n;
            c = u = !1, "function" == typeof t ? (t(l.state.value[e]), n = {
                type: Dr.patchFunction,
                storeId: e,
                events: d
            }) : (Qr(l.state.value[e], t), n = {
                type: Dr.patchObject,
                payload: t,
                storeId: e,
                events: d
            });
            const o = m = Symbol();
            It().then(() => {
                m === o && (c = !0)
            }), u = !0, qr(h, n, l.state.value[e])
        }
        r || p || (l.state.value[e] = {}), Ct({});
        const g = r ? function() {
            const {
                state: e
            } = n, t = e ? e() : {};
            this.$patch(e => {
                ts(e, t)
            })
        } : Wr;
        const C = (t, n = "") => {
                if (Jr in t) return t[Xr] = n, t;
                const o = function() {
                    Ir(l);
                    const n = Array.from(arguments),
                        r = [],
                        s = [];
                    let i;
                    qr(f, {
                        args: n,
                        name: o[Xr],
                        store: w,
                        after: function(e) {
                            r.push(e)
                        },
                        onError: function(e) {
                            s.push(e)
                        }
                    });
                    try {
                        i = t.apply(this && this.$id === e ? this : w, n)
                    } catch (a) {
                        throw qr(s, a), a
                    }
                    return i instanceof Promise ? i.then(e => (qr(r, e), e)).catch(e => (qr(s, e), Promise.reject(e))) : (qr(r, i), i)
                };
                return o[Jr] = !0, o[Xr] = n, o
            },
            w = st({
                _p: l,
                $id: e,
                $onAction: Gr.bind(null, f),
                $patch: v,
                $reset: g,
                $subscribe(t, n = {}) {
                    const o = Gr(h, t, n.detached, () => r()),
                        r = s.run(() => Fl(() => l.state.value[e], l => {
                            ("sync" === n.flush ? u : c) && t({
                                storeId: e,
                                type: Dr.direct,
                                events: d
                            }, l)
                        }, ts({}, a, n)));
                    return o
                },
                $dispose: function() {
                    s.stop(), h = [], f = [], l._s.delete(e)
                }
            });
        l._s.set(e, w);
        const x = (l._a && l._a.runWithContext || Kr)(() => l._e.run(() => (s = Q()).run(() => t({
            action: C
        }))));
        for (const y in x) {
            const t = x[y];
            if (gt(t) && !ns(t) || ct(t)) r || (p && es(t) && (gt(t) ? t.value = p[y] : Qr(t, p[y])), l.state.value[e][y] = t);
            else if ("function" == typeof t) {
                const e = C(t, y);
                x[y] = e, i.actions[y] = t
            }
        }
        return ts(w, x), ts(ft(w), x), Object.defineProperty(w, "$state", {
            get: () => l.state.value[e],
            set: e => {
                v(t => {
                    ts(t, e)
                })
            }
        }), l._p.forEach(e => {
            ts(w, s.run(() => e({
                store: w,
                app: l._a,
                pinia: l,
                options: i
            })))
        }), p && r && n.hydrate && n.hydrate(w.$state, p), c = !0, u = !0, w
    }

    function rs(e, t, n) {
        let l;
        const o = "function" == typeof t;

        function r(n, r) {
            const s = !(!So() && !dl);
            (n = n || (s ? hl(Rr, null) : null)) && Ir(n), (n = Hr)._s.has(e) || (o ? os(e, t, l, n) : ls(e, l, n));
            return n._s.get(e)
        }
        return l = o ? n : t, r.$id = e, r
    }
    const ss = "" + new URL("images/logo.png", document.currentScript && "SCRIPT" === document.currentScript.tagName.toUpperCase() && document.currentScript.src || document.baseURI).href;

    function is(e) {
        if (3 === (e = e.replace("#", "")).length && (e = e.split("").map(e => e + e).join("")), 6 !== e.length) return null;
        const t = e.match(/([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})/i);
        if (!t) return null;
        const [, n, l, o] = t;
        return {
            r: parseInt(n, 16),
            g: parseInt(l, 16),
            b: parseInt(o, 16)
        }
    }

    function as(e, t, n) {
        e /= 255, t /= 255, n /= 255;
        const l = Math.max(e, t, n),
            o = Math.min(e, t, n),
            r = l - o;
        let s = 0;
        0 !== r && (s = l === e ? (t - n) / r % 6 : l === t ? (n - e) / r + 2 : (e - t) / r + 4), s = Math.round((60 * s + 360) % 360);
        const i = (l + o) / 2;
        return {
            h: s,
            s: +(100 * (0 === r ? 0 : r / (1 - Math.abs(2 * i - 1)))).toFixed(1),
            l: +(100 * i).toFixed(1)
        }
    }

    function cs(e, t, n) {
        t /= 100, n /= 100;
        const l = (1 - Math.abs(2 * n - 1)) * t,
            o = l * (1 - Math.abs(e / 60 % 2 - 1)),
            r = n - l / 2;
        let s = 0,
            i = 0,
            a = 0;
        return [s, i, a] = e < 60 ? [l, o, 0] : e < 120 ? [o, l, 0] : e < 180 ? [0, l, o] : e < 240 ? [0, o, l] : e < 300 ? [o, 0, l] : [l, 0, o], {
            r: Math.round(255 * (s + r)),
            g: Math.round(255 * (i + r)),
            b: Math.round(255 * (a + r))
        }
    }

    function us(e, t, n, l) {
        const o = 1 - l / 100,
            r = e => Math.max(0, Math.min(255, Math.floor(e * o)));
        return {
            r: r(e),
            g: r(t),
            b: r(n)
        }
    }

    function ds(e, t, n) {
        return (299 * e + 587 * t + 114 * n) / 1e3
    }
    const hs = new Map;
    let fs = !1,
        ps = null;

    function ms(e, t) {
        const n = So(),
            l = e,
            o = () => {
                fs || (ps = e => {
                    const {
                        Action: t,
                        Payload: n
                    } = e.data ?? {}, l = hs.get(t);
                    l?.size && l.forEach(e => e(n))
                }, window.addEventListener("message", ps), fs = !0), hs.has(l) || hs.set(l, new Set), hs.get(l).add(t)
            },
            r = () => {
                const e = hs.get(l);
                e && (e.delete(t), 0 === e.size && hs.delete(l)), fs && 0 === hs.size && ps && (window.removeEventListener("message", ps), fs = !1, ps = null)
            };
        return n ? (Zn(o, n), Bn(r, n)) : o(), r
    }
    async function vs(e, t, n) {
        const l = n ?? ("function" == typeof GetParentResourceName ? GetParentResourceName() : "nui-fallback"),
            o = await fetch(`https://${l}/${String(e)}`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(t ?? {})
            });
        if (!o.ok) throw new Error(`HTTP error on ${String(e)}: ${o.status}`);
        return await o.json()
    }
    const gs = Ct({});
    const Cs = {
            class: "flex items-center gap-2.5"
        },
        ws = {
            class: "text-sm font-medium bg-white/20 h-[1.625rem] px-2.5 rounded flex items-center uppercase tracking-widest whitespace-nowrap"
        },
        xs = vn({
            __name: "Mode1",
            props: {
                icon: {},
                text: {},
                active: {
                    type: Boolean
                }
            },
            setup: e => (t, n) => (lo(), io("div", Cs, [(lo(), ao(Hn(e.icon), {
                class: R(["size-5 min-w-5 min-h-5", e.active ? "text-green-500" : "opacity-75"])
            }, null, 8, ["class"])), po("div", ws, W(e.text), 1)]))
        }),
        ys = {
            class: "flex items-center gap-2.5"
        },
        bs = {
            class: "relative"
        },
        ks = {
            class: "text-sm font-medium tracking-widest drop-shadow-light"
        },
        _s = {
            key: 0,
            class: "text-white/50 text-xs leading-3"
        },
        Ms = {
            class: "whitespace-nowrap"
        },
        Ls = vn({
            __name: "Mode2",
            props: {
                icon: {},
                title: {},
                text: {},
                active: {
                    type: Boolean
                }
            },
            setup: e => (t, n) => (lo(), io("div", ys, [po("div", bs, [n[0] || (n[0] = po("svg", {
                class: "w-11 h-11 overflow-visible",
                viewBox: "0 0 40 40"
            }, [po("path", {
                class: "fill-white/20 stroke-main",
                "stroke-width": "1.5",
                "stroke-miterlimit": "10",
                d: "M26.3,2.7H13.7c-2.3,0-4.5,1.2-5.6,3.2L1.9,16.8c-1.2,2-1.2,4.5,0,6.5l6.3,10.8c1.2,2,3.3,3.2,5.6,3.2h12.5c2.3,0,4.5-1.2,5.6-3.2l6.3-10.8c1.2-2,1.2-4.5,0-6.5L31.9,5.9C30.7,3.9,28.6,2.7,26.3,2.7z"
            })], -1)), (lo(), ao(Hn(e.icon), {
                class: R(["absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 size-5 min-w-5 min-h-5", e.active ? "text-green-500" : "opacity-75"])
            }, null, 8, ["class"]))]), po("div", ks, [e.title ? (lo(), io("p", _s, W(e.title), 1)) : wo("", !0), po("p", Ms, W(e.text), 1)])]))
        }),
        Ss = {
            class: "flex items-center gap-2.5"
        },
        Vs = vn({
            __name: "Mode3",
            props: {
                icon: {},
                text: {},
                active: {
                    type: Boolean
                }
            },
            setup: e => (t, n) => (lo(), io("div", Ss, [(lo(), ao(Hn(e.icon), {
                class: R(["size-5 min-w-5 min-h-5", e.active ? "text-green-500" : "opacity-75"])
            }, null, 8, ["class"])), po("div", {
                class: R(["text-sm font-medium h-[1.625rem] px-2.5 rounded flex items-center uppercase tracking-widest whitespace-nowrap", xt(gs).grayscale ? "bg-white text-from" : "bg-main text-mainText"])
            }, W(e.text), 3)]))
        }),
        zs = rs("info", () => {
            const e = Ct(0),
                t = Ct(0),
                n = Ct(0),
                l = Ct(0),
                o = Ct({
                    display: !1,
                    value: 0
                }),
                r = Ct(0),
                s = Ct(0),
                i = Ct(0),
                a = Ct([0, 0]),
                c = Ct({
                    distance: "NORMAL",
                    isTalking: !1
                }),
                u = Ct(null),
                d = Ct([]),
                h = Ct([0, 0]),
                f = Ct(0),
                p = Ct(0),
                m = Ct(0),
                v = Ct([0, 0]),
                g = Ct(!1),
                C = Ct({
                    display: !1,
                    name: "",
                    ammo: {
                        current: 0,
                        stored: 0
                    }
                }),
                w = Ct({
                    top: "",
                    bottom: ""
                }),
                x = Oo(() => v.value.length > 0 && v.value[0] > 0 ? Math.min(Math.max(v.value[0] / v.value[1] * 100 * .05, 0), 100) : 0),
                y = Oo(() => Math.min(Math.max(s.value * (100 / 3600), 0), 100)),
                b = Oo(() => Math.min(Math.max(i.value * (100 / 3600), 0), 100)),
                k = Oo(() => a.value.length > 0 && a.value[0] > 0 ? Math.min(Math.max(a.value[0] / a.value[1] * 100, 0), 100) : 0);
            return {
                health: e,
                armor: t,
                hunger: n,
                thirst: l,
                oxygen: o,
                stress: r,
                luck: s,
                dexterity: i,
                repose: a,
                voice: c,
                radio: u,
                radioList: d,
                clock: h,
                id: f,
                players: p,
                gemstone: m,
                wanted: v,
                safezone: g,
                weapon: C,
                location: w,
                wantedLevel: x,
                luckPercentage: y,
                dexterityPercentage: b,
                reposePercentage: k
            }
        }),
        Zs = (e, t) => {
            const n = e.__vccOpts || e;
            for (const [l, o] of t) n[l] = o;
            return n
        },
        js = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const $s = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", js, [...t[0] || (t[0] = [po("path", {
                    "fill-rule": "evenodd",
                    "clip-rule": "evenodd",
                    d: "M12 1.25C6.72451 1.25 2.25 5.60954 2.25 10.9258C2.25 13.6482 3.40187 15.9241 5.01689 17.8025C6.62496 19.6728 8.71834 21.1811 10.6782 22.3944L10.6911 22.4024L10.7043 22.4098C11.0996 22.6329 11.546 22.75 12 22.75C12.454 22.75 12.9004 22.6329 13.2957 22.4098L13.3072 22.4033L13.3185 22.3964C15.2855 21.1928 17.3793 19.6796 18.9866 17.8038C20.6003 15.9206 21.75 13.6392 21.75 10.9258C21.75 5.60954 17.2755 1.25 12 1.25ZM12 7C9.79086 7 8 8.79086 8 11C8 13.2091 9.79086 15 12 15C14.2091 15 16 13.2091 16 11C16 8.79086 14.2091 7 12 7Z",
                    fill: "currentColor"
                }, null, -1)])])
            }]
        ]),
        Bs = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const Es = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", Bs, [...t[0] || (t[0] = [po("path", {
                    d: "M15.5 11C15.5 12.933 13.933 14.5 12 14.5C10.067 14.5 8.5 12.933 8.5 11C8.5 9.067 10.067 7.5 12 7.5C13.933 7.5 15.5 9.067 15.5 11Z",
                    stroke: "currentColor",
                    "stroke-width": "2"
                }, null, -1), po("path", {
                    d: "M12 2C16.8706 2 21 6.03298 21 10.9258C21 15.8965 16.8033 19.3847 12.927 21.7567C12.6445 21.9162 12.325 22 12 22C11.675 22 11.3555 21.9162 11.073 21.7567C7.2039 19.3616 3 15.9137 3 10.9258C3 6.03298 7.12944 2 12 2Z",
                    stroke: "currentColor",
                    "stroke-width": "2"
                }, null, -1)])])
            }]
        ]),
        Ps = {
            class: "flex items-center gap-3"
        },
        Ts = {
            class: "flex items-center justify-center"
        },
        Fs = {
            class: "text-sm leading-[1.125rem]"
        },
        As = {
            class: "font-bold whitespace-nowrap"
        },
        Os = {
            class: "whitespace-nowrap text-white/75"
        },
        Hs = vn({
            __name: "Mode1",
            setup(e) {
                const t = zs(),
                    n = xc(),
                    l = Oo(() => ["fill", "line"].includes(n.modes.icon) && "line" === n.modes.icon ? Es : $s);
                return (e, n) => (lo(), io("div", Ps, [po("div", Ts, [(lo(), ao(Hn(l.value), {
                    class: "w-6 h-6"
                }))]), po("div", Fs, [po("p", As, W(xt(t).location.top), 1), po("p", Os, W(xt(t).location.bottom), 1)])]))
            }
        }),
        Is = {
            class: "flex items-center gap-3"
        },
        Rs = {
            class: "relative"
        },
        Ns = {
            class: "text-sm leading-[1.125rem]"
        },
        Ds = {
            class: "font-bold whitespace-nowrap"
        },
        Us = {
            class: "whitespace-nowrap text-white/75"
        },
        Ws = vn({
            __name: "Mode2",
            setup(e) {
                const t = zs(),
                    n = xc(),
                    l = Oo(() => ["fill", "line"].includes(n.modes.icon) && "line" === n.modes.icon ? Es : $s);
                return (e, n) => (lo(), io("div", Is, [po("div", Rs, [n[0] || (n[0] = po("svg", {
                    class: "w-11 h-11 overflow-visible",
                    viewBox: "0 0 40 40"
                }, [po("path", {
                    class: "fill-white/20 stroke-main",
                    "stroke-width": "1.5",
                    "stroke-miterlimit": "10",
                    d: "M26.3,2.7H13.7c-2.3,0-4.5,1.2-5.6,3.2L1.9,16.8c-1.2,2-1.2,4.5,0,6.5l6.3,10.8c1.2,2,3.3,3.2,5.6,3.2h12.5c2.3,0,4.5-1.2,5.6-3.2l6.3-10.8c1.2-2,1.2-4.5,0-6.5L31.9,5.9C30.7,3.9,28.6,2.7,26.3,2.7z"
                })], -1)), (lo(), ao(Hn(l.value), {
                    class: "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4"
                }))]), po("div", Ns, [po("p", Ds, W(xt(t).location.top), 1), po("p", Us, W(xt(t).location.bottom), 1)])]))
            }
        }),
        Gs = {
            viewBox: "0 0 212 212"
        };
    const qs = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", Gs, [...t[0] || (t[0] = [Co('<rect fill="currentColor" x="30.1" y="176.8" transform="matrix(0.7091 -0.7052 0.7052 0.7091 -115.717 75.1526)" width="6.2" height="2"></rect><rect fill="currentColor" x="5" y="136.1" transform="matrix(0.9515 -0.3077 0.3077 0.9515 -41.7847 9.1423)" width="6.2" height="2"></rect><rect fill="currentColor" x="3.3" y="86.3" transform="matrix(0.1555 -0.9878 0.9878 0.1555 -84.6913 79.7971)" width="2" height="6.2"></rect><rect fill="currentColor" x="21.7" y="42.2" transform="matrix(0.5854 -0.8107 0.8107 0.5854 -27.296 37.1953)" width="2" height="6.2"></rect><rect fill="currentColor" x="58.3" y="11.2" transform="matrix(0.8899 -0.4562 0.4562 0.8899 2.386854e-02 28.6106)" width="2" height="6.2"></rect><rect fill="currentColor" x="105" width="2" height="6.2"></rect><rect fill="currentColor" x="149.7" y="13.3" transform="matrix(0.4562 -0.8899 0.8899 0.4562 70.3899 143.6949)" width="6.2" height="2"></rect><rect fill="currentColor" x="186.2" y="44.3" transform="matrix(0.8111 -0.585 0.585 0.8111 9.2789 119.3023)" width="6.2" height="2"></rect><rect fill="currentColor" x="204.6" y="88.4" transform="matrix(0.9879 -0.1553 0.1553 0.9879 -11.3678 33.3397)" width="6.2" height="2"></rect><rect fill="currentColor" x="202.9" y="133.9" transform="matrix(0.3074 -0.9516 0.9516 0.3074 10.8232 289.0029)" width="2" height="6.2"></rect><rect fill="currentColor" x="177.8" y="174.7" transform="matrix(0.705 -0.7092 0.7092 0.705 -73.3486 179.2819)" width="2" height="6.2"></rect><rect fill="currentColor" fill-opacity="0.3" x="22.2" y="168.6" transform="matrix(0.7869 -0.617 0.617 0.7869 -99.0804 51.3089)" width="5.2" height="1"></rect><rect fill="currentColor" fill-opacity="0.3" x="15.2" y="158.7" transform="matrix(0.8538 -0.5207 0.5207 0.8538 -80.2797 32.5392)" width="5.2" height="1"></rect><rect fill="currentColor" fill-opacity="0.3" x="9.4" y="148" transform="matrix(0.9088 -0.4173 0.4173 0.9088 -60.8661 18.5706)" width="5.2" height="1"></rect><rect fill="currentColor" fill-opacity="0.3" x="1.9" y="125" transform="matrix(0.9809 -0.1944 0.1944 0.9809 -24.3155 3.275)" width="5.2" height="1"></rect><rect fill="currentColor" fill-opacity="0.3" x="0.3" y="113" transform="matrix(0.9969 -7.819124e-02 7.819124e-02 0.9969 -8.8669 0.5709)" width="5.2" height="1"></rect><rect fill="currentColor" fill-opacity="0.3" x="2.1" y="98.8" transform="matrix(3.887670e-02 -0.9992 0.9992 3.887670e-02 -98.811 100.0765)" width="1" height="5.2"></rect><rect fill="currentColor" fill-opacity="0.3" x="5.9" y="74.9" transform="matrix(0.27 -0.9629 0.9629 0.27 -69.9545 62.7771)" width="1" height="5.2"></rect><rect fill="currentColor" fill-opacity="0.3" x="9.9" y="63.5" transform="matrix(0.3807 -0.9247 0.9247 0.3807 -54.6537 50.5523)" width="1" height="5.2"></rect><rect fill="currentColor" fill-opacity="0.3" x="15.2" y="52.6" transform="matrix(0.4864 -0.8737 0.8737 0.4864 -40.1353 42.0871)" width="1" height="5.2"></rect><rect fill="currentColor" fill-opacity="0.3" x="29.5" y="33" transform="matrix(0.6766 -0.7363 0.7363 0.6766 -16.5185 33.6312)" width="1" height="5.2"></rect><rect fill="currentColor" fill-opacity="0.3" x="38.3" y="24.6" transform="matrix(0.7585 -0.6517 0.6517 0.7585 -8.3703 31.8714)" width="1" height="5.2"></rect><rect fill="currentColor" fill-opacity="0.3" x="48" y="17.3" transform="matrix(0.83 -0.5578 0.5578 0.83 -2.8595 30.4574)" width="1" height="5.2"></rect><rect fill="currentColor" fill-opacity="0.3" x="69.7" y="6.4" transform="matrix(0.9375 -0.3479 0.3479 0.9375 1.2752 24.9847)" width="1" height="5.2"></rect><rect fill="currentColor" fill-opacity="0.3" x="81.4" y="2.8" transform="matrix(0.9721 -0.2348 0.2348 0.9721 1.014 19.3706)" width="1" height="5.2"></rect><rect fill="currentColor" fill-opacity="0.3" x="93.4" y="0.7" transform="matrix(0.993 -0.1184 0.1184 0.993 0.2695 11.132)" width="1" height="5.2"></rect><rect fill="currentColor" fill-opacity="0.3" x="115.6" y="2.8" transform="matrix(0.1183 -0.993 0.993 0.1183 100.9318 120.2602)" width="5.2" height="1"></rect><rect fill="currentColor" fill-opacity="0.3" x="127.6" y="4.9" transform="matrix(0.2343 -0.9722 0.9722 0.2343 94.4058 130.7093)" width="5.2" height="1"></rect><rect fill="currentColor" fill-opacity="0.3" x="139.3" y="8.4" transform="matrix(0.3477 -0.9376 0.9376 0.3477 84.1365 138.8197)" width="5.2" height="1"></rect><rect fill="currentColor" fill-opacity="0.3" x="160.9" y="19.4" transform="matrix(0.5576 -0.8301 0.8301 0.5576 55.7983 144.5406)" width="5.2" height="1"></rect><rect fill="currentColor" fill-opacity="0.3" x="170.6" y="26.7" transform="matrix(0.6518 -0.7584 0.7584 0.6518 39.6619 140.8471)" width="5.2" height="1"></rect><rect fill="currentColor" fill-opacity="0.3" x="179.4" y="35.1" transform="matrix(0.7367 -0.6762 0.6762 0.7367 23.8275 132.4456)" width="5.2" height="1"></rect><rect fill="currentColor" fill-opacity="0.3" x="193.7" y="54.7" transform="matrix(0.8738 -0.4862 0.4862 0.8738 -2.0643 102.411)" width="5.2" height="1"></rect><rect fill="currentColor" fill-opacity="0.3" x="199" y="65.6" transform="matrix(0.9247 -0.3808 0.3808 0.9247 -9.9723 81.757)" width="5.2" height="1"></rect><rect fill="currentColor" fill-opacity="0.3" x="203" y="77" transform="matrix(0.963 -0.2696 0.2696 0.963 -13.2856 58.2948)" width="5.2" height="1"></rect><rect fill="currentColor" fill-opacity="0.3" x="206.8" y="100.9" transform="matrix(0.9992 -3.903273e-02 3.903273e-02 0.9992 -3.7985 8.2516)" width="5.2" height="1"></rect><rect fill="currentColor" fill-opacity="0.3" x="208.7" y="110.9" transform="matrix(7.794601e-02 -0.997 0.997 7.794601e-02 79.7113 313.2101)" width="1" height="5.2"></rect><rect fill="currentColor" fill-opacity="0.3" x="207" y="122.9" transform="matrix(0.194 -0.981 0.981 0.194 44.1346 304.7321)" width="1" height="5.2"></rect><rect fill="currentColor" fill-opacity="0.3" x="199.5" y="145.9" transform="matrix(0.4166 -0.9091 0.9091 0.4166 -18.3222 268.4568)" width="1" height="5.2"></rect><rect fill="currentColor" fill-opacity="0.3" x="193.8" y="156.6" transform="matrix(0.5203 -0.854 0.854 0.5203 -42.7572 242.2505)" width="1" height="5.2"></rect><rect fill="currentColor" fill-opacity="0.3" x="186.8" y="166.5" transform="matrix(0.6168 -0.7871 0.7871 0.6168 -61.3496 212.2258)" width="1" height="5.2"></rect>', 41)])])
            }]
        ]),
        Ks = {
            width: "19",
            height: "17",
            viewBox: "0 0 19 17",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg"
        };
    const Js = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", Ks, [...t[0] || (t[0] = [po("path", {
                    "fill-rule": "evenodd",
                    "clip-rule": "evenodd",
                    d: "M1.61805 0.680932C1.25884 1.05545 0.964912 1.3711 0.964912 1.38232C0.964912 1.39359 1.16186 1.50106 1.40261 1.62116C2.85361 2.34497 4.43169 3.3253 5.75236 4.32328C6.40018 4.81284 7.1422 5.42279 7.48456 5.74719L7.71373 5.96434L7.28972 6.84622C7.05651 7.33123 6.86572 7.73651 6.86572 7.74678C6.86572 7.75704 7.01925 7.92124 7.20692 8.11165L7.54809 8.45788L7.41453 8.59604C7.02192 9.00206 6.5421 9.85885 6.36511 10.4699C6.06562 11.5039 6.07493 12.6015 6.39161 13.5904C6.80248 14.8734 7.70534 15.9424 8.87277 16.5283C9.5164 16.8512 10.1591 17 10.9109 17C11.6628 17 12.3054 16.8512 12.9491 16.5283C13.6328 16.1852 13.8436 16.0026 15.27 14.5175L15.639 14.1334L15.8232 14.3328C15.9245 14.4425 16.3762 14.9206 16.827 15.3952L17.6466 16.2582L18.3226 15.5614C18.6944 15.1782 18.9993 14.8549 19 14.8431C19.0011 14.8251 17.3805 13.089 16.877 12.5688L16.728 12.4148L16.7977 12.1441C16.8527 11.9305 16.867 11.7446 16.8652 11.2639C16.8633 10.7193 16.8524 10.616 16.7626 10.2918C16.584 9.64691 16.2876 9.13187 15.7921 8.60546C14.6717 7.41506 12.306 4.94254 12.1768 4.82691C11.8584 4.54191 11.4312 4.32007 10.9825 4.20669C10.7245 4.14147 10.0248 4.14099 9.76045 4.20584C9.64819 4.23335 9.43568 4.30511 9.28828 4.36531L9.02018 4.4747L8.6017 4.10901C7.3661 3.02929 5.82131 1.91945 4.39777 1.08865C3.82042 0.751729 2.37906 0 2.31037 0C2.28881 0 1.97729 0.306416 1.61805 0.680932ZM1.70949 4.97722C1.31829 5.56752 0.818616 6.41361 0.535006 6.96583C0.174018 7.66874 0 8.16945 0 8.50526C0 9.33588 0.605371 10.1078 1.42881 10.3272C1.70674 10.4013 2.17576 10.3908 2.45744 10.3043C3.3157 10.0405 3.91951 9.12633 3.78579 8.29321C3.68945 7.69319 3.09061 6.50782 2.1755 5.1057C2.0396 4.89752 1.9162 4.72749 1.90128 4.72793C1.88636 4.72834 1.80004 4.84053 1.70949 4.97722ZM10.3177 11.3747C11.0802 12.177 11.979 13.1206 12.3151 13.4715L12.9261 14.1096L12.837 14.2049C12.788 14.2574 12.6478 14.3713 12.5253 14.458C12.0129 14.8211 11.5498 14.9706 10.9295 14.9732C10.3356 14.9756 9.86652 14.836 9.38933 14.5146C8.13617 13.6704 7.7138 11.9747 8.41076 10.5857C8.545 10.3182 8.85815 9.886 8.90413 9.90483C8.91905 9.91096 9.55515 10.5724 10.3177 11.3747Z",
                    fill: "currentColor"
                }, null, -1)])])
            }]
        ]),
        Xs = {
            width: "16",
            height: "15",
            viewBox: "0 0 16 15",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg"
        };
    const Qs = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", Xs, [...t[0] || (t[0] = [po("path", {
                    d: "M15.5713 0.59151C15.5713 4.85121 15.5713 9.11604 15.5713 13.3757C15.53 13.5092 15.5025 13.6477 15.4475 13.7709C15.1907 14.3303 14.7688 14.5715 14.2185 14.5715C10.6508 14.5715 7.0831 14.5715 3.51081 14.5715C3.39158 14.5715 3.26318 14.5715 3.14854 14.5407C2.45609 14.3509 1.97918 13.8941 1.77282 13.114C1.41054 11.7642 1.04369 10.4145 0.685999 9.05959C0.424612 8.06908 0.612627 7.18121 1.22253 6.41139C2.32311 5.03597 3.4191 3.65541 4.53343 2.29539C5.4414 1.18684 6.58325 0.596642 7.92687 0.586378C10.4169 0.560717 12.907 0.576113 15.397 0.576113C15.4566 0.576113 15.5117 0.586378 15.5713 0.59151ZM14.3102 6.85789C14.3102 5.23099 14.3102 3.61436 14.3102 1.97719C14.246 1.97719 14.191 1.97719 14.1314 1.97719C12.0586 1.9772 9.98128 1.96693 7.90853 1.98233C6.96845 1.98746 6.15678 2.39803 5.51936 3.16786C4.5426 4.34312 3.59335 5.54918 2.63494 6.74498C2.61201 6.77577 2.59366 6.80656 2.56156 6.85275C6.48695 6.85789 10.394 6.85789 14.3102 6.85789ZM11.8247 9.66518C12.6593 9.66518 13.4802 9.66518 14.3056 9.66518C14.3056 9.20329 14.3056 8.74652 14.3056 8.28976C13.4756 8.28976 12.6548 8.28976 11.8247 8.28976C11.8247 8.74652 11.8247 9.19815 11.8247 9.66518Z",
                    fill: "currentColor"
                }, null, -1)])])
            }]
        ]),
        Ys = {
            viewBox: "0 0 24 24",
            xmlns: "http://www.w3.org/2000/svg",
            class: "scale-125"
        };
    const ei = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", Ys, [...t[0] || (t[0] = [po("path", {
                    fill: "currentColor",
                    d: "M15.8 7.4c-0.6-1.1-1.4-2-2.5-2.7c-1.1-0.6-2.3-1-3.6-1S7.1 4 6.1 4.7C5 5.3 4.2 6.2 3.6 7.4C3 8.5 2.7 9.8 2.7 11.2S3 13.9 3.6 15s1.4 2 2.5 2.7c1.1 0.6 2.3 1 3.6 1s2.6-0.3 3.6-1c1.1-0.6 1.9-1.6 2.5-2.7l0 0c0.6-1.1 0.9-2.4 0.9-3.8C16.7 9.8 16.4 8.5 15.8 7.4z M14.7 11.2c0 1.1-0.2 2.1-0.6 2.9c-0.4 0.8-1 1.5-1.8 2c-0.7 0.5-1.6 0.7-2.6 0.7s-1.8-0.2-2.6-0.7c-0.7-0.5-1.3-1.1-1.8-2c-0.4-0.8-0.6-1.8-0.6-2.9s0.2-2.1 0.6-2.9c0.4-0.8 1-1.5 1.8-2c0.7-0.5 1.6-0.7 2.6-0.7s1.8 0.2 2.6 0.7s1.3 1.1 1.8 2C14.5 9.2 14.7 10.1 14.7 11.2z"
                }, null, -1), po("path", {
                    fill: "currentColor",
                    d: "M21.1 18.8c-0.2-0.2-0.4-0.2-0.6-0.2h-0.9l0.5-0.5c0.3-0.4 0.6-0.7 0.8-1.1c0.2-0.4 0.3-0.8 0.3-1.2c0-0.4-0.1-0.8-0.3-1.1c-0.2-0.3-0.5-0.6-0.8-0.8c-0.6-0.3-1.4-0.4-2.2-0.1c-0.3 0.2-0.6 0.4-0.9 0.6c-0.1 0.1-0.2 0.3-0.3 0.4c-0.1 0.2-0.1 0.3-0.1 0.5s0 0.4 0.3 0.6c0.4 0.4 1 0.3 1.3-0.1c0.1-0.1 0.2-0.3 0.4-0.4c0.3-0.2 0.5-0.1 0.7 0.1c0.1 0.1 0.2 0.2 0.2 0.4c0 0.1 0 0.3-0.1 0.5S19.1 16.8 19 17l-1.9 2c-0.2 0.2-0.3 0.4-0.3 0.6s0.1 0.4 0.2 0.6c0.1 0.1 0.3 0.3 0.6 0.3h2.9c0.2 0 0.4-0.1 0.6-0.2c0.2-0.2 0.2-0.4 0.2-0.6C21.3 19.2 21.3 19 21.1 18.8z"
                }, null, -1)])])
            }]
        ]),
        ti = {
            width: "21",
            height: "13",
            viewBox: "0 0 21 13",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg"
        };
    const ni = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", ti, [...t[0] || (t[0] = [po("path", {
                    d: "M19.4313 3.95762C19.4313 3.95762 19.2321 3.56801 18.9858 3.56801L16.6909 3.56801C16.4454 3.56801 16.2462 3.74287 16.2462 3.95762L16.2462 4.33459L15.6207 4.33459C15.6207 3.96227 15.6207 3.72825 15.6207 3.70564C15.6207 3.56801 15.4572 3.58065 15.4572 3.58065L14.0631 3.58065C14.0631 1.67051 12.9602 1.67716 12.9602 1.67716L10.4935 1.67716L10.4935 1.02826L12.9602 1.02826L12.9602 0.0715326L4.78185 0.071533L4.78185 1.02826L7.47121 1.02826L7.47121 1.67716C7.47121 1.67716 6.10069 1.67716 4.99545 1.67716L3.50709 2.67245L2.35323 2.67245C2.10694 2.67245 1.90776 2.84665 1.90776 3.06139L1.90776 5.55926L1.16662 5.55926L1.16662 2.89119L0.0712892 2.89119L0.0712895 9.59029L1.16662 9.59029L1.16662 6.83246L1.90776 6.83246L1.90776 9.41942C1.90776 9.63417 2.10694 9.80836 2.35323 9.80836L3.50709 9.80836L7.12763 12.0715C7.12763 12.0715 13.6732 12.0715 14.7032 12.0715C15.7316 12.0715 15.6207 11.305 15.6207 11.305C15.6207 11.305 15.6207 10.8409 15.6207 10.1408L16.2462 10.1408L16.2462 11.0004C16.2462 11.2159 16.4454 11.3901 16.6909 11.3901L18.9858 11.3901C19.2321 11.3901 19.4313 11.0004 19.4313 11.0004L20.0713 9.37088L20.0713 5.58785L19.4313 3.95762V3.95762Z",
                    fill: "currentColor"
                }, null, -1)])])
            }]
        ]),
        li = {
            width: "14",
            height: "22",
            viewBox: "0 0 14 22",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg"
        };
    const oi = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", li, [...t[0] || (t[0] = [po("path", {
                    d: "M2.45882 15.4187C2.08241 15.7639 1.71208 16.1091 1.33567 16.4543C1.05639 16.7074 0.740697 16.7707 0.455354 16.6441C-0.0181931 16.4313 -0.151758 15.879 0.224652 15.5165C0.953186 14.8089 1.706 14.13 2.44668 13.4396C2.62881 13.267 2.80488 13.0887 2.98094 12.9103C3.01737 12.9218 3.04772 12.9334 3.08415 12.9449C3.02951 13.3361 2.98701 13.7273 2.90809 14.1127C2.82916 14.504 2.72595 14.8952 2.63489 15.2749C5.73116 13.7963 8.82135 13.7963 11.9237 15.2634C11.7598 14.7168 11.5837 14.1473 11.4077 13.5604C11.4866 13.5489 11.5169 13.5317 11.5412 13.5374C12.4094 13.8769 13.1926 14.3486 13.7997 15.039C14.0911 15.3727 14.0668 15.8042 13.7511 16.0688C13.4233 16.3392 12.974 16.2817 12.6522 15.948C12.4762 15.7639 12.2819 15.6028 12.0876 15.4245C12.1423 15.9192 12.2394 16.3852 12.2273 16.8455C12.203 18.1112 11.8508 19.3193 11.4259 20.5102C11.3409 20.7461 11.2619 20.982 11.1709 21.2179C10.928 21.8622 10.2602 22.1729 9.65917 21.9313C9.01563 21.6666 8.82743 21.0395 9.09456 20.3894C9.57417 19.233 9.9263 18.0364 9.99308 16.7822C10.0052 16.5463 9.93844 16.414 9.66524 16.3737C8.99135 16.2702 8.31745 16.1091 7.64356 16.0343C6.78753 15.9422 5.95579 16.1436 5.13011 16.3277C4.55336 16.4543 4.523 16.4658 4.58371 17.0468C4.70514 18.232 5.04512 19.3711 5.50045 20.4815C5.74937 21.0913 5.53081 21.6666 4.9662 21.914C4.39551 22.1671 3.72162 21.937 3.4727 21.3732C2.94451 20.1766 2.6106 18.9281 2.39811 17.6452C2.27669 16.9145 2.30705 16.1954 2.53168 15.4877C2.50132 15.4532 2.47704 15.436 2.45882 15.4187Z",
                    fill: "currentColor"
                }, null, -1), po("path", {
                    d: "M5.08154 12.8586C5.28189 12.6917 5.49438 12.5306 5.68866 12.3523C7.35214 10.7932 9.00349 9.2341 10.673 7.68075C10.843 7.52541 10.8552 7.41035 10.7155 7.24926C10.4666 6.96736 10.2177 6.6797 9.92022 6.33451C10.1327 6.15041 10.3756 5.94905 10.6063 5.74194C10.9584 5.42552 11.2984 5.10334 11.6505 4.78692C12.0208 4.44748 12.4337 4.42447 12.7494 4.72363C13.0651 5.01704 13.0408 5.44853 12.6826 5.79372C12.0876 6.36903 11.4987 6.94435 10.8977 7.51966C11.7962 9.05575 11.6262 11.892 11.4137 13.4799C9.3799 12.732 7.29143 12.6227 5.16047 12.9334C5.13618 12.9046 5.1119 12.8816 5.08154 12.8586Z",
                    fill: "currentColor"
                }, null, -1), po("path", {
                    d: "M3.0297 12.7263C3.0297 11.754 3.00542 10.7759 3.03578 9.80366C3.06006 9.09027 3.24219 8.40565 3.55789 7.75554C4.04965 6.72573 4.84497 6.05837 6.03491 5.85701C7.06093 5.68441 8.08695 5.68441 9.08261 6.00084C9.35581 6.08713 9.60472 6.23671 9.76864 6.31151C7.56483 8.46893 5.36101 10.6264 3.1572 12.778C3.12077 12.7608 3.0722 12.7435 3.0297 12.7263Z",
                    fill: "currentColor"
                }, null, -1), po("path", {
                    d: "M7.28511 0.000327317C8.74825 -0.00542588 9.91997 1.10493 9.88962 2.51445C9.85926 3.90095 8.76646 4.86173 7.42475 4.92501C5.72483 4.9998 4.66846 3.73411 4.66846 2.47418C4.67453 1.08767 5.8159 0.00608052 7.28511 0.000327317Z",
                    fill: "currentColor"
                }, null, -1)])])
            }]
        ]),
        ri = {
            width: "4",
            height: "146",
            viewBox: "0 0 4 146",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg"
        };
    const si = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", ri, [...t[0] || (t[0] = [Co('<defs><linearGradient id="PointerSpeedometer" x1="2" y1="0" x2="2" y2="75" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="currentColor" stop-opacity="0"></stop><stop offset=".4" stop-color="currentColor"></stop><stop offset="1" stop-color="currentColor" stop-opacity="0"></stop></linearGradient></defs><rect fill="url(#PointerSpeedometer)" x="0" width="4" height="75" rx="2" ry="2"></rect>', 2)])])
            }]
        ]),
        ii = {
            class: "relative -mb-6 mr-1"
        },
        ai = {
            class: "w-60 h-60 relative overflow-visible rotate-[135deg]",
            viewBox: "0 0 220 220"
        },
        ci = ["stroke-dasharray", "stroke-dashoffset"],
        ui = ["stroke-dasharray", "stroke-dashoffset"],
        di = ["stroke-dasharray", "stroke-dashoffset"],
        hi = ["stroke-dasharray", "stroke-dashoffset"],
        fi = {
            class: "absolute top-0 right-0 w-60 h-60 overflow-visible -rotate-[135deg] -scale-x-100",
            viewBox: "0 0 220 220"
        },
        pi = ["stroke-dasharray", "stroke-dashoffset"],
        mi = ["stroke-dasharray", "stroke-dashoffset"],
        vi = {
            class: "w-[10.675rem] h-[10.675rem] absolute top-1/2 left-1/2 -translate-y-1/2 -translate-x-1/2 rotate-[143deg] -scale-100",
            viewBox: "0 0 220 220"
        },
        gi = ["stroke-dasharray", "stroke-dashoffset"],
        Ci = {
            class: "absolute left-1/2 -translate-x-1/2 top-[38%] text-center"
        },
        wi = {
            class: "text-5xl font-semibold font-rajdhani drop-shadow-light"
        },
        xi = {
            class: "text-white/50"
        },
        yi = {
            class: "absolute bottom-9 left-1/2 -translate-x-1/2 flex items-center gap-3"
        },
        bi = .275,
        ki = vn({
            __name: "Mode1",
            props: {
                vehicle: {}
            },
            setup(e) {
                const t = e,
                    n = Ct(0);
                Fl(() => t.vehicle.speed, e => {
                    (e => {
                        const t = n.value,
                            l = e - t;
                        if (0 === l) return;
                        const o = Math.abs(l),
                            r = 100 / o;
                        let s = 0;
                        const i = () => {
                            if (s <= o) {
                                const e = s / o,
                                    a = 1 - Math.pow(1 - e, 3);
                                n.value = Math.round(t + l * a), s++, setTimeout(i, r)
                            }
                        };
                        i()
                    })(e)
                }, {
                    immediate: !0
                });
                const l = Oo(() => t.vehicle.speed >= 100 ? "" : t.vehicle.speed >= 10 ? "0" : "00"),
                    o = 2 * Math.PI * 90,
                    r = Oo(() => Math.min(Math.max(t.vehicle.fuel, 0), 100) * bi * .75),
                    s = Oo(() => .75 * Math.min(Math.max(t.vehicle.rpm / 10 * 100 * 10, 0), 100)),
                    i = Oo(() => 2.7 * Math.min(Math.max(t.vehicle.rpm / 10 * 100 * 10, 0), 100) - 135),
                    a = 2 * Math.PI * 105,
                    c = Oo(() => Math.min(Math.max(t.vehicle.nitro, 0), 2e3) * bi * .75 * .05),
                    u = 2 * Math.PI * 105,
                    d = 2 * Math.PI * 105;
                return (t, h) => (lo(), io("div", ii, [(lo(), io("svg", ai, [po("circle", {
                    class: "stroke-hud-rpm/40",
                    r: 90,
                    cx: "110",
                    cy: "110",
                    fill: "transparent",
                    "stroke-width": "4",
                    "stroke-linecap": "round",
                    "stroke-dasharray": `${o}px`,
                    "stroke-dashoffset": .25 * o + "px"
                }, null, 8, ci), po("circle", {
                    class: "stroke-hud-rpm transition-all ease-linear duration-100",
                    r: 90,
                    cx: "110",
                    cy: "110",
                    fill: "transparent",
                    "stroke-width": "4",
                    "stroke-linecap": "round",
                    "stroke-dasharray": `${o}px`,
                    "stroke-dashoffset": o * ((100 - s.value) / 100) + "px"
                }, null, 8, ui), po("circle", {
                    class: "stroke-hud-fuel/40",
                    r: 105,
                    cx: "110",
                    cy: "110",
                    fill: "transparent",
                    "stroke-width": "4",
                    "stroke-linecap": "round",
                    "stroke-dasharray": `${a}px`,
                    "stroke-dashoffset": .79375 * a + "px"
                }, null, 8, di), po("circle", {
                    class: "stroke-hud-fuel transition-all",
                    r: 105,
                    cx: "110",
                    cy: "110",
                    fill: "transparent",
                    "stroke-width": "4",
                    "stroke-linecap": "round",
                    "stroke-dasharray": `${a}px`,
                    "stroke-dashoffset": a * ((100 - r.value) / 100) + "px"
                }, null, 8, hi)])), (lo(), io("svg", fi, [po("circle", {
                    class: "stroke-hud-nitro/40",
                    r: 105,
                    cx: "110",
                    cy: "110",
                    fill: "transparent",
                    "stroke-width": "4",
                    "stroke-linecap": "round",
                    "stroke-dasharray": `${u}px`,
                    "stroke-dashoffset": .79375 * u + "px"
                }, null, 8, pi), po("circle", {
                    class: "stroke-hud-nitro transition-all",
                    r: 105,
                    cx: "110",
                    cy: "110",
                    fill: "transparent",
                    "stroke-width": "4",
                    "stroke-linecap": "round",
                    "stroke-dasharray": `${u}px`,
                    "stroke-dashoffset": u * ((100 - c.value) / 100) + "px"
                }, null, 8, mi)])), (lo(), io("svg", vi, [po("circle", {
                    class: "stroke-red-500/60",
                    r: 105,
                    cx: "110",
                    cy: "110",
                    fill: "transparent",
                    "stroke-width": "6",
                    "stroke-dasharray": `${d}px`,
                    "stroke-dashoffset": .77125 * d + "px"
                }, null, 8, gi)])), mo(qs, {
                    class: "w-[10.5rem] h-[10.5rem] absolute top-1/2 left-1/2 -translate-y-1/2 -translate-x-1/2 drop-shadow-light"
                }), mo(Js, {
                    class: R(["absolute left-2 bottom-6 w-5 h-5 drop-shadow-light", [r.value > 0 ? "text-white " : "text-white/50", r.value > 0 && r.value / 20.625000000000004 * 100 < 15 ? "animate-flashing " : ""]])
                }, null, 8, ["class"]), mo(ei, {
                    class: R(["absolute right-1 bottom-6 w-5 h-5 drop-shadow-light", [c.value > 0 ? "text-white" : "text-white/50", c.value > 0 && c.value / 20.625000000000004 * 100 < 15 ? "animate-flashing" : ""]])
                }, null, 8, ["class"]), mo(si, {
                    class: "absolute top-1/2 left-1/2 -translate-y-1/2 -translate-x-1/2 transition-transform ease-linear duration-100 h-[9.125rem] w-1 text-hud-pointer",
                    style: F({
                        transform: `translate(-50%, -50%) rotate(${i.value}deg)`
                    })
                }, null, 8, ["style"]), po("div", Ci, [po("p", wi, [po("span", xi, W(l.value), 1), po("span", null, W(n.value), 1)]), h[0] || (h[0] = po("p", {
                    class: "text-white/50 text-xs -mt-1.5 drop-shadow-light"
                }, "KM/H", -1))]), h[1] || (h[1] = Co('<p class="absolute font-rajdhani font-semibold text-sm drop-shadow-light" style="top:66%;left:28%;">0</p><p class="absolute font-rajdhani font-semibold text-sm drop-shadow-light" style="top:55%;left:21.5%;">1</p><p class="absolute font-rajdhani font-semibold text-sm drop-shadow-light" style="top:41%;left:20%;">2</p><p class="absolute font-rajdhani font-semibold text-sm drop-shadow-light" style="top:29%;left:25.5%;">3</p><p class="absolute font-rajdhani font-semibold text-sm drop-shadow-light" style="top:20.5%;left:35.5%;">4</p><p class="absolute font-rajdhani font-semibold text-sm drop-shadow-light" style="top:17.5%;left:48.5%;">5</p><p class="absolute font-rajdhani font-semibold text-sm drop-shadow-light" style="top:20.5%;right:35.5%;">6</p><p class="absolute font-rajdhani font-semibold text-sm drop-shadow-light" style="top:29%;right:25.5%;">7</p><p class="absolute font-rajdhani font-semibold text-sm drop-shadow-light" style="top:41%;right:20%;">8</p><p class="absolute font-rajdhani font-semibold text-sm drop-shadow-light" style="top:55%;right:21.5%;">9</p><p class="absolute font-rajdhani font-semibold text-sm drop-shadow-light" style="top:66%;right:28%;">10</p>', 11)), po("div", yi, [mo(Qs, {
                    class: R(["w-4 h-4 drop-shadow-light", [e.vehicle.doors ? "text-white" : "text-white/50"]])
                }, null, 8, ["class"]), mo(oi, {
                    class: R(["w-3.5 h-6 drop-shadow-light", [e.vehicle.seatbelt ? "text-white" : "text-white/50"]])
                }, null, 8, ["class"]), mo(ni, {
                    class: R(["w-5 h-5 drop-shadow-light", [e.vehicle.engine <= 300 ? "text-white animate-flashing" : "text-white/50"]])
                }, null, 8, ["class"])])]))
            }
        }),
        _i = {
            class: "relative"
        },
        Mi = {
            class: "w-60"
        },
        Li = {
            class: "flex items-center justify-between mb-2"
        },
        Si = {
            class: "flex-1 flex items-center gap-2"
        },
        Vi = {
            class: "text-4xl font-semibold"
        },
        zi = {
            class: "text-white/50"
        },
        Zi = {
            class: ""
        },
        ji = {
            class: "flex items-center gap-2"
        },
        $i = {
            class: "space-y-2 w-24"
        },
        Bi = {
            class: "flex items-center gap-2"
        },
        Ei = {
            class: "flex-1 border overflow-hidden rounded h-1.5 border-hud-fuel bg-hud-fuel/30"
        },
        Pi = {
            class: "flex items-center gap-2"
        },
        Ti = {
            class: "flex-1 border overflow-hidden rounded h-1.5 border-hud-nitro bg-hud-nitro/30"
        },
        Fi = {
            class: "w-full",
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 240 40"
        },
        Ai = {
            class: "absolute -bottom-1 pl-[35%] flex items-center gap-2 w-full"
        },
        Oi = {
            class: "flex-1 border overflow-hidden rounded h-1.5 border-hud-engine bg-hud-engine/30"
        },
        Hi = vn({
            __name: "Mode2",
            props: {
                vehicle: {}
            },
            setup(e) {
                const t = e,
                    n = Ct(0);
                Fl(() => t.vehicle.speed, e => {
                    (e => {
                        const t = n.value,
                            l = e - t;
                        if (0 === l) return;
                        const o = Math.abs(l),
                            r = 100 / o;
                        let s = 0;
                        const i = () => {
                            if (s <= o) {
                                const e = s / o,
                                    a = 1 - Math.pow(1 - e, 3);
                                n.value = Math.round(t + l * a), s++, setTimeout(i, r)
                            }
                        };
                        i()
                    })(e)
                }, {
                    immediate: !0
                });
                const l = Oo(() => t.vehicle.speed >= 100 ? "" : t.vehicle.speed >= 10 ? "0" : "00"),
                    o = Oo(() => Math.min(Math.max(t.vehicle.rpm / 10 * 100 * 10, 0), 100)),
                    r = Oo(() => Math.min(Math.max(t.vehicle.fuel, 0), 100)),
                    s = Oo(() => .05 * Math.min(Math.max(t.vehicle.nitro, 0), 2e3));
                return (t, i) => (lo(), io("div", _i, [po("div", Mi, [po("div", Li, [po("div", Si, [po("p", Vi, [po("span", zi, W(l.value), 1), po("span", null, W(n.value), 1)]), po("div", Zi, [i[0] || (i[0] = po("p", {
                    class: "text-white/50 text-xs -mt-1.5 drop-shadow-light"
                }, "KM/H", -1)), po("div", ji, [mo(oi, {
                    class: R(["w-3 min-w-3 drop-shadow-light", [e.vehicle.seatbelt ? "text-white" : "text-white/50"]])
                }, null, 8, ["class"]), mo(Qs, {
                    class: R(["w-3 min-w-3 drop-shadow-light", [e.vehicle.doors ? "text-white" : "text-white/50"]])
                }, null, 8, ["class"])])])]), po("div", $i, [po("div", Bi, [po("div", Ei, [po("div", {
                    class: "h-full rounded bg-hud-fuel",
                    style: F({
                        width: r.value + "%"
                    })
                }, null, 4)]), mo(Js, {
                    class: R(["w-3.5 h-3.5 text-hud-fuel", [r.value > 0 && r.value < 15 ? "animate-flashing " : ""]])
                }, null, 8, ["class"])]), po("div", Pi, [po("div", Ti, [po("div", {
                    class: "h-full rounded bg-hud-nitro",
                    style: F({
                        width: s.value + "%"
                    })
                }, null, 4)]), mo(ei, {
                    class: R(["w-3.5 h-3.5 text-hud-nitro", [s.value > 0 && s.value < 15 ? "animate-flashing " : ""]])
                }, null, 8, ["class"])])])]), (lo(), io("svg", Fi, [po("defs", null, [po("rect", {
                    id: "rpm_full",
                    height: "100%",
                    style: F({
                        width: o.value + "%"
                    })
                }, null, 4)]), i[1] || (i[1] = po("clipPath", {
                    id: "rpm"
                }, [po("use", {
                    "xlink:href": "#rpm_full",
                    style: {
                        overflow: "visible"
                    }
                })], -1)), i[2] || (i[2] = po("path", {
                    class: "fill-hud-rpm/40",
                    "fill-rule": "evenodd",
                    "clip-rule": "evenodd",
                    d: "m0,40h5V0H0v40h0Zm235-16h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,16h5V0h-5v40h0Zm-7.58,0h5V0h-5v40h0Zm-7.58,0h5V0h-5v40h0Zm-7.58,0h5V0h-5v40h0Zm-7.58,0h5V0h-5v40h0Zm-7.58,0h5V0h-5v40h0Zm-7.58,0h5V0h-5v40h0Zm-7.58,0h5V0h-5v40h0Zm-7.58,0h5V0h-5v40Z"
                }, null, -1)), i[3] || (i[3] = po("path", {
                    class: "fill-hud-rpm transition-all duration-100 ease-linear",
                    "fill-rule": "evenodd",
                    "clip-rule": "evenodd",
                    style: {
                        "clip-path": "url(#rpm)"
                    },
                    d: "m0,40h5V0H0v40h0Zm235-16h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,0h5V0h-5v24h0Zm-7.58,16h5V0h-5v40h0Zm-7.58,0h5V0h-5v40h0Zm-7.58,0h5V0h-5v40h0Zm-7.58,0h5V0h-5v40h0Zm-7.58,0h5V0h-5v40h0Zm-7.58,0h5V0h-5v40h0Zm-7.58,0h5V0h-5v40h0Zm-7.58,0h5V0h-5v40h0Zm-7.58,0h5V0h-5v40Z"
                }, null, -1))]))]), po("div", Ai, [mo(ni, {
                    class: R(["w-4 h-4 text-hud-engine", [e.vehicle.engine > 0 && e.vehicle.engine / 10 < 30 ? "animate-flashing" : ""]])
                }, null, 8, ["class"]), po("div", Oi, [po("div", {
                    class: "h-full rounded bg-hud-engine",
                    style: F({
                        width: e.vehicle.engine / 10 + "%"
                    })
                }, null, 4)])])]))
            }
        }),
        Ii = {
            class: "relative"
        },
        Ri = {
            class: "w-72 aspect-[27.5/6.98] relative"
        },
        Ni = {
            class: "w-full",
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 275 69.8"
        },
        Di = ["stroke-dashoffset"],
        Ui = {
            class: "w-full absolute top-1/2 left-0 -translate-y-1/2 mt-2 pl-12 flex items-center justify-between mb-2"
        },
        Wi = {
            class: "flex-1 flex items-center gap-2"
        },
        Gi = {
            class: "text-4xl font-semibold"
        },
        qi = {
            class: "text-white/50"
        },
        Ki = {
            class: ""
        },
        Ji = {
            class: "flex items-center gap-2"
        },
        Xi = {
            class: "space-y-2 w-24"
        },
        Qi = {
            class: "flex items-center gap-2"
        },
        Yi = {
            class: "flex-1 border overflow-hidden rounded h-1.5 border-hud-fuel bg-hud-fuel/30"
        },
        ea = {
            class: "flex items-center gap-2"
        },
        ta = {
            class: "flex-1 border overflow-hidden rounded h-1.5 border-hud-nitro bg-hud-nitro/30"
        },
        na = vn({
            __name: "Mode3",
            props: {
                vehicle: {}
            },
            setup(e) {
                const t = e,
                    n = Ct(0);
                Fl(() => t.vehicle.speed, e => {
                    (e => {
                        const t = n.value,
                            l = e - t;
                        if (0 === l) return;
                        const o = Math.abs(l),
                            r = 100 / o;
                        let s = 0;
                        const i = () => {
                            if (s <= o) {
                                const e = s / o,
                                    a = 1 - Math.pow(1 - e, 3);
                                n.value = Math.round(t + l * a), s++, setTimeout(i, r)
                            }
                        };
                        i()
                    })(e)
                }, {
                    immediate: !0
                });
                const l = Oo(() => t.vehicle.speed >= 100 ? "" : t.vehicle.speed >= 10 ? "0" : "00"),
                    o = Oo(() => Math.min(Math.max(t.vehicle.rpm / 10 * 100 * 10, 0), 100)),
                    r = Oo(() => Math.min(Math.max(t.vehicle.fuel, 0), 100)),
                    s = Oo(() => .05 * Math.min(Math.max(t.vehicle.nitro, 0), 2e3));
                return (t, i) => (lo(), io("div", Ii, [po("div", Ri, [(lo(), io("svg", Ni, [i[0] || (i[0] = po("path", {
                    class: "stroke-hud-rpm/40",
                    fill: "none",
                    "stroke-width": "5",
                    "stroke-linecap": "round",
                    "stroke-miterlimit": "10",
                    d: "M2.5,67.3l28.2-49.3C36.2,8.4,46.4,2.5,57.5,2.5h215"
                }, null, -1)), po("path", {
                    class: "stroke-hud-rpm transition-all duration-100 ease-linear",
                    fill: "none",
                    "stroke-width": "5",
                    "stroke-linecap": "round",
                    "stroke-miterlimit": "10",
                    d: "M2.5,67.3l28.2-49.3C36.2,8.4,46.4,2.5,57.5,2.5h215",
                    "stroke-dasharray": 304.23,
                    "stroke-dashoffset": (100 - o.value) / 100 * 304.23
                }, null, 8, Di)])), po("div", Ui, [po("div", Wi, [po("p", Gi, [po("span", qi, W(l.value), 1), po("span", null, W(n.value), 1)]), po("div", Ki, [i[1] || (i[1] = po("p", {
                    class: "text-white/50 text-xs -mt-1.5 drop-shadow-light"
                }, "KM/H", -1)), po("div", Ji, [mo(oi, {
                    class: R(["w-3 min-w-3 drop-shadow-light", [e.vehicle.seatbelt ? "text-white" : "text-white/50"]])
                }, null, 8, ["class"]), mo(Qs, {
                    class: R(["w-3 min-w-3 drop-shadow-light", [e.vehicle.doors ? "text-white" : "text-white/50"]])
                }, null, 8, ["class"]), mo(ni, {
                    class: R(["w-3.5 h-3.5 drop-shadow-light", [e.vehicle.engine <= 300 ? "text-white animate-flashing" : "text-white/50"]])
                }, null, 8, ["class"])])])]), po("div", Xi, [po("div", Qi, [po("div", Yi, [po("div", {
                    class: "h-full rounded bg-hud-fuel",
                    style: F({
                        width: r.value + "%"
                    })
                }, null, 4)]), mo(Js, {
                    class: R(["w-3.5 h-3.5 text-hud-fuel", [r.value > 0 && r.value < 15 ? "animate-flashing " : ""]])
                }, null, 8, ["class"])]), po("div", ea, [po("div", ta, [po("div", {
                    class: "h-full rounded bg-hud-nitro",
                    style: F({
                        width: s.value + "%"
                    })
                }, null, 4)]), mo(ei, {
                    class: R(["w-3.5 h-3.5 text-hud-nitro", [s.value > 0 && s.value < 15 ? "animate-flashing " : ""]])
                }, null, 8, ["class"])])])])])]))
            }
        }),
        la = vn({
            __name: "Base",
            props: {
                color: {}
            },
            setup: e => (t, n) => (lo(), io("div", {
                class: R(["relative", {
                    "mb-6": xt(gs).percentage
                }]),
                style: F({
                    "--main": `var(--hud-${e.color})`
                })
            }, [Nn(t.$slots, "default")], 6))
        }),
        oa = ["viewBox"],
        ra = ["r", "cx", "cy"],
        sa = ["r", "cx", "cy"],
        ia = ["cx", "cy"],
        aa = ["cx", "cy"],
        ca = ["cx", "cy", "stroke-dashoffset"],
        ua = {
            key: 0,
            class: "absolute -bottom-6 left-1/2 -translate-x-1/2 text-xs font-semibold drop-shadow-light"
        },
        da = vn({
            __name: "Mode1",
            props: {
                icon: {},
                color: {},
                percentage: {}
            },
            setup(e) {
                const t = xc(),
                    n = e,
                    l = 18,
                    o = 2 * Math.PI * l,
                    r = Oo(() => Math.min(Math.max(n.percentage, 0), 100));
                return (n, s) => (lo(), ao(la, {
                    color: e.color
                }, {
                    default: Xt(() => [(lo(), io("svg", {
                        class: "w-11 h-11 -rotate-90",
                        viewBox: "0 0 40 40"
                    }, [po("circle", {
                        r: 12,
                        cx: 20,
                        cy: 20,
                        class: "fill-black/50"
                    }, null, 8, ra), po("circle", {
                        r: 12,
                        cx: 20,
                        cy: 20,
                        class: "fill-main/30"
                    }, null, 8, sa), po("circle", {
                        r: l,
                        cx: 20,
                        cy: 20,
                        fill: "transparent",
                        "stroke-width": 4,
                        class: "stroke-black/50"
                    }, null, 8, ia), po("circle", {
                        r: l,
                        cx: 20,
                        cy: 20,
                        fill: "transparent",
                        "stroke-width": 4,
                        class: "stroke-main/30"
                    }, null, 8, aa), po("circle", {
                        r: l,
                        cx: 20,
                        cy: 20,
                        fill: "transparent",
                        "stroke-width": 4,
                        "stroke-dasharray": o,
                        "stroke-dashoffset": o * ((100 - r.value) / 100),
                        class: "transition-all stroke-main"
                    }, null, 8, ca)], 8, oa)), (lo(), ao(Hn(e.icon), {
                        class: "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4",
                        style: F({
                            color: `rgb(${xt(t).icons||`var(--hud-${e.color})`}${xt(t).icons?" / 0.8":""})`
                        })
                    }, null, 8, ["style"])), xt(gs).percentage ? (lo(), io("p", ua, W(Math.floor(r.value)) + "%", 1)) : wo("", !0)]),
                    _: 1
                }, 8, ["color"]))
            }
        }),
        ha = ["viewBox"],
        fa = ["cx", "cy"],
        pa = ["r", "cx", "cy"],
        ma = ["r", "cx", "cy", "stroke-dashoffset"],
        va = {
            key: 0,
            class: "absolute -bottom-6 left-1/2 -translate-x-1/2 text-xs font-semibold drop-shadow-light"
        },
        ga = vn({
            __name: "Mode2",
            props: {
                icon: {},
                color: {},
                percentage: {}
            },
            setup(e) {
                const t = xc(),
                    n = e,
                    l = 2 * Math.PI * 19,
                    o = Oo(() => Math.min(Math.max(n.percentage, 0), 100));
                return (n, r) => (lo(), ao(la, {
                    color: e.color
                }, {
                    default: Xt(() => [(lo(), io("svg", {
                        class: "w-11 h-11 -rotate-90",
                        viewBox: "0 0 40 40"
                    }, [po("circle", {
                        r: 19,
                        cx: 20,
                        cy: 20,
                        class: "fill-black/50"
                    }, null, 8, fa), po("circle", {
                        r: 17,
                        cx: 20,
                        cy: 20,
                        fill: "none",
                        "stroke-width": 2,
                        class: "stroke-white/5"
                    }, null, 8, pa), po("circle", {
                        r: 17,
                        cx: 20,
                        cy: 20,
                        fill: "none",
                        "stroke-width": 2,
                        "stroke-dasharray": l,
                        "stroke-dashoffset": l * ((100 - o.value) / 100),
                        class: "transition-all stroke-main"
                    }, null, 8, ma)], 8, ha)), (lo(), ao(Hn(e.icon), {
                        class: "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4",
                        style: F({
                            color: `rgb(${xt(t).icons||`var(--hud-${e.color})`}${xt(t).icons?" / 0.8":""})`
                        })
                    }, null, 8, ["style"])), xt(gs).percentage ? (lo(), io("p", va, W(Math.floor(o.value)) + "%", 1)) : wo("", !0)]),
                    _: 1
                }, 8, ["color"]))
            }
        }),
        Ca = ["viewBox"],
        wa = ["cx", "cy"],
        xa = ["cx", "cy", "stroke-dashoffset"],
        ya = {
            key: 0,
            class: "absolute -bottom-6 left-1/2 -translate-x-1/2 text-xs font-semibold drop-shadow-light"
        },
        ba = vn({
            __name: "Mode3",
            props: {
                icon: {},
                color: {},
                percentage: {}
            },
            setup(e) {
                const t = xc(),
                    n = e,
                    l = 2 * Math.PI * 19,
                    o = Oo(() => Math.min(Math.max(n.percentage, 0), 100));
                return (n, r) => (lo(), ao(la, {
                    color: e.color
                }, {
                    default: Xt(() => [(lo(), io("svg", {
                        class: "w-11 h-11 -rotate-90",
                        viewBox: "0 0 40 40"
                    }, [po("circle", {
                        r: 19,
                        cx: 20,
                        cy: 20,
                        fill: "transparent",
                        "stroke-width": 2,
                        class: "stroke-black/50"
                    }, null, 8, wa), po("circle", {
                        r: 19,
                        cx: 20,
                        cy: 20,
                        fill: "transparent",
                        "stroke-width": 2,
                        "stroke-dasharray": l,
                        "stroke-dashoffset": l * ((100 - o.value) / 100),
                        class: "transition-all stroke-main"
                    }, null, 8, xa)], 8, Ca)), (lo(), ao(Hn(e.icon), {
                        class: "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 drop-shadow-light",
                        style: F({
                            color: `rgb(${xt(t).icons||`var(--hud-${e.color})`}${xt(t).icons?" / 0.8":""})`
                        })
                    }, null, 8, ["style"])), xt(gs).percentage ? (lo(), io("p", ya, W(Math.floor(o.value)) + "%", 1)) : wo("", !0)]),
                    _: 1
                }, 8, ["color"]))
            }
        }),
        ka = {
            class: "w-11 h-11 overflow-visible -scale-x-100",
            viewBox: "0 0 40 40"
        },
        _a = ["stroke-dashoffset"],
        Ma = {
            key: 0,
            class: "absolute -bottom-6 left-1/2 -translate-x-1/2 text-xs font-semibold drop-shadow-light"
        },
        La = vn({
            __name: "Mode4",
            props: {
                icon: {},
                color: {},
                percentage: {}
            },
            setup(e) {
                const t = xc(),
                    n = e,
                    l = Oo(() => Math.min(Math.max(n.percentage, 0), 100));
                return (n, o) => (lo(), ao(la, {
                    color: e.color
                }, {
                    default: Xt(() => [(lo(), io("svg", ka, [o[0] || (o[0] = po("path", {
                        class: "stroke-black/50",
                        fill: "none",
                        "stroke-width": "2",
                        "stroke-miterlimit": "10",
                        d: "M26.3,2.7H13.7c-2.3,0-4.5,1.2-5.6,3.2L1.9,16.8c-1.2,2-1.2,4.5,0,6.5l6.3,10.8c1.2,2,3.3,3.2,5.6,3.2h12.5c2.3,0,4.5-1.2,5.6-3.2l6.3-10.8c1.2-2,1.2-4.5,0-6.5L31.9,5.9C30.7,3.9,28.6,2.7,26.3,2.7z"
                    }, null, -1)), o[1] || (o[1] = po("path", {
                        class: "stroke-main/30",
                        fill: "none",
                        "stroke-width": "2",
                        "stroke-miterlimit": "10",
                        d: "M26.3,2.7H13.7c-2.3,0-4.5,1.2-5.6,3.2L1.9,16.8c-1.2,2-1.2,4.5,0,6.5l6.3,10.8c1.2,2,3.3,3.2,5.6,3.2h12.5c2.3,0,4.5-1.2,5.6-3.2l6.3-10.8c1.2-2,1.2-4.5,0-6.5L31.9,5.9C30.7,3.9,28.6,2.7,26.3,2.7z"
                    }, null, -1)), po("path", {
                        class: "stroke-main",
                        fill: "none",
                        "stroke-width": "2",
                        "stroke-miterlimit": "10",
                        d: "M26.3,2.7H13.7c-2.3,0-4.5,1.2-5.6,3.2L1.9,16.8c-1.2,2-1.2,4.5,0,6.5l6.3,10.8c1.2,2,3.3,3.2,5.6,3.2h12.5c2.3,0,4.5-1.2,5.6-3.2l6.3-10.8c1.2-2,1.2-4.5,0-6.5L31.9,5.9C30.7,3.9,28.6,2.7,26.3,2.7z",
                        "stroke-dasharray": 115.912,
                        "stroke-dashoffset": (100 - l.value) / 100 * 115.912
                    }, null, 8, _a)])), o[2] || (o[2] = po("svg", {
                        class: "w-9 h-9 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 overflow-visible -scale-x-100",
                        viewBox: "0 0 40 40"
                    }, [po("path", {
                        class: "fill-black/50",
                        d: "M26.3,2.7H13.7c-2.3,0-4.5,1.2-5.6,3.2L1.9,16.8c-1.2,2-1.2,4.5,0,6.5l6.3,10.8c1.2,2,3.3,3.2,5.6,3.2h12.5c2.3,0,4.5-1.2,5.6-3.2l6.3-10.8c1.2-2,1.2-4.5,0-6.5L31.9,5.9C30.7,3.9,28.6,2.7,26.3,2.7z"
                    }), po("path", {
                        class: "fill-main/30",
                        d: "M26.3,2.7H13.7c-2.3,0-4.5,1.2-5.6,3.2L1.9,16.8c-1.2,2-1.2,4.5,0,6.5l6.3,10.8c1.2,2,3.3,3.2,5.6,3.2h12.5c2.3,0,4.5-1.2,5.6-3.2l6.3-10.8c1.2-2,1.2-4.5,0-6.5L31.9,5.9C30.7,3.9,28.6,2.7,26.3,2.7z"
                    })], -1)), (lo(), ao(Hn(e.icon), {
                        class: "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 drop-shadow-light",
                        style: F({
                            color: `rgb(${xt(t).icons||`var(--hud-${e.color})`}${xt(t).icons?" / 0.8":""})`
                        })
                    }, null, 8, ["style"])), xt(gs).percentage ? (lo(), io("p", Ma, W(Math.floor(l.value)) + "%", 1)) : wo("", !0)]),
                    _: 1
                }, 8, ["color"]))
            }
        }),
        Sa = {
            class: "w-10 h-10 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 overflow-visible -scale-x-100",
            viewBox: "0 0 40 40"
        },
        Va = ["stroke-dashoffset"],
        za = {
            key: 0,
            class: "absolute -bottom-6 left-1/2 -translate-x-1/2 text-xs font-semibold drop-shadow-light"
        },
        Za = vn({
            __name: "Mode5",
            props: {
                icon: {},
                color: {},
                percentage: {}
            },
            setup(e) {
                const t = xc(),
                    n = e,
                    l = Oo(() => Math.min(Math.max(n.percentage, 0), 100));
                return (n, o) => (lo(), ao(la, {
                    color: e.color
                }, {
                    default: Xt(() => [o[2] || (o[2] = po("svg", {
                        class: "w-11 h-11 overflow-visible -scale-x-100",
                        viewBox: "0 0 40 40"
                    }, [po("path", {
                        class: "fill-black/50",
                        d: "M26.3,2.7H13.7c-2.3,0-4.5,1.2-5.6,3.2L1.9,16.8c-1.2,2-1.2,4.5,0,6.5l6.3,10.8c1.2,2,3.3,3.2,5.6,3.2h12.5c2.3,0,4.5-1.2,5.6-3.2l6.3-10.8c1.2-2,1.2-4.5,0-6.5L31.9,5.9C30.7,3.9,28.6,2.7,26.3,2.7z"
                    })], -1)), (lo(), io("svg", Sa, [o[0] || (o[0] = po("path", {
                        class: "fill-black/50",
                        d: "M26.3,2.7H13.7c-2.3,0-4.5,1.2-5.6,3.2L1.9,16.8c-1.2,2-1.2,4.5,0,6.5l6.3,10.8c1.2,2,3.3,3.2,5.6,3.2h12.5c2.3,0,4.5-1.2,5.6-3.2l6.3-10.8c1.2-2,1.2-4.5,0-6.5L31.9,5.9C30.7,3.9,28.6,2.7,26.3,2.7z"
                    }, null, -1)), o[1] || (o[1] = po("path", {
                        class: "stroke-white/5",
                        fill: "none",
                        "stroke-width": "2",
                        "stroke-miterlimit": "10",
                        d: "M26.3,2.7H13.7c-2.3,0-4.5,1.2-5.6,3.2L1.9,16.8c-1.2,2-1.2,4.5,0,6.5l6.3,10.8c1.2,2,3.3,3.2,5.6,3.2h12.5c2.3,0,4.5-1.2,5.6-3.2l6.3-10.8c1.2-2,1.2-4.5,0-6.5L31.9,5.9C30.7,3.9,28.6,2.7,26.3,2.7z"
                    }, null, -1)), po("path", {
                        class: "stroke-main",
                        fill: "none",
                        "stroke-width": "2",
                        "stroke-miterlimit": "10",
                        d: "M26.3,2.7H13.7c-2.3,0-4.5,1.2-5.6,3.2L1.9,16.8c-1.2,2-1.2,4.5,0,6.5l6.3,10.8c1.2,2,3.3,3.2,5.6,3.2h12.5c2.3,0,4.5-1.2,5.6-3.2l6.3-10.8c1.2-2,1.2-4.5,0-6.5L31.9,5.9C30.7,3.9,28.6,2.7,26.3,2.7z",
                        "stroke-dasharray": 115.912,
                        "stroke-dashoffset": (100 - l.value) / 100 * 115.912
                    }, null, 8, Va)])), (lo(), ao(Hn(e.icon), {
                        class: "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 drop-shadow-light",
                        style: F({
                            color: `rgb(${xt(t).icons||`var(--hud-${e.color})`}${xt(t).icons?" / 0.8":""})`
                        })
                    }, null, 8, ["style"])), xt(gs).percentage ? (lo(), io("p", za, W(Math.floor(l.value)) + "%", 1)) : wo("", !0)]),
                    _: 1
                }, 8, ["color"]))
            }
        }),
        ja = {
            class: "w-11 h-11 overflow-visible -scale-x-100",
            viewBox: "0 0 40 40"
        },
        $a = ["stroke-dashoffset"],
        Ba = {
            key: 0,
            class: "absolute -bottom-6 left-1/2 -translate-x-1/2 text-xs font-semibold drop-shadow-light"
        },
        Ea = vn({
            __name: "Mode6",
            props: {
                icon: {},
                color: {},
                percentage: {}
            },
            setup(e) {
                const t = xc(),
                    n = e,
                    l = Oo(() => Math.min(Math.max(n.percentage, 0), 100));
                return (n, o) => (lo(), ao(la, {
                    color: e.color
                }, {
                    default: Xt(() => [(lo(), io("svg", ja, [o[0] || (o[0] = po("path", {
                        class: "stroke-black/50",
                        fill: "none",
                        "stroke-width": "2",
                        "stroke-miterlimit": "10",
                        d: "M26.3,2.7H13.7c-2.3,0-4.5,1.2-5.6,3.2L1.9,16.8c-1.2,2-1.2,4.5,0,6.5l6.3,10.8c1.2,2,3.3,3.2,5.6,3.2h12.5c2.3,0,4.5-1.2,5.6-3.2l6.3-10.8c1.2-2,1.2-4.5,0-6.5L31.9,5.9C30.7,3.9,28.6,2.7,26.3,2.7z"
                    }, null, -1)), po("path", {
                        class: "stroke-main",
                        fill: "none",
                        "stroke-width": "2",
                        "stroke-miterlimit": "10",
                        d: "M26.3,2.7H13.7c-2.3,0-4.5,1.2-5.6,3.2L1.9,16.8c-1.2,2-1.2,4.5,0,6.5l6.3,10.8c1.2,2,3.3,3.2,5.6,3.2h12.5c2.3,0,4.5-1.2,5.6-3.2l6.3-10.8c1.2-2,1.2-4.5,0-6.5L31.9,5.9C30.7,3.9,28.6,2.7,26.3,2.7z",
                        "stroke-dasharray": 115.912,
                        "stroke-dashoffset": (100 - l.value) / 100 * 115.912
                    }, null, 8, $a)])), (lo(), ao(Hn(e.icon), {
                        class: "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 drop-shadow-light",
                        style: F({
                            color: `rgb(${xt(t).icons||`var(--hud-${e.color})`}${xt(t).icons?" / 0.8":""})`
                        })
                    }, null, 8, ["style"])), xt(gs).percentage ? (lo(), io("p", Ba, W(Math.floor(l.value)) + "%", 1)) : wo("", !0)]),
                    _: 1
                }, 8, ["color"]))
            }
        }),
        Pa = ["viewBox"],
        Ta = ["x", "y", "width", "height", "rx", "ry"],
        Fa = ["x", "y", "width", "height", "rx", "ry"],
        Aa = ["x", "y", "width", "height"],
        Oa = ["x", "y", "width", "height"],
        Ha = ["x", "y", "width", "height", "stroke-dashoffset"],
        Ia = {
            key: 0,
            class: "absolute -bottom-6 left-1/2 -translate-x-1/2 text-xs font-semibold drop-shadow-light"
        },
        Ra = 40,
        Na = vn({
            __name: "Mode7",
            props: {
                icon: {},
                color: {},
                percentage: {}
            },
            setup(e) {
                const t = xc(),
                    n = e,
                    l = 112 + 2 * Math.PI * 6,
                    o = Oo(() => Math.min(Math.max(n.percentage, 0), 100));
                return (n, r) => (lo(), ao(la, {
                    color: e.color
                }, {
                    default: Xt(() => [(lo(), io("svg", {
                        class: "w-11 h-11 overflow-visible",
                        viewBox: "0 0 40 40"
                    }, [po("rect", {
                        class: "fill-black/50",
                        x: (Ra - 33.15) / 2,
                        y: (Ra - 33.15) / 2,
                        width: 33.15,
                        height: 33.15,
                        rx: 4.25,
                        ry: 4.25
                    }, null, 8, Ta), po("rect", {
                        class: "fill-main/30",
                        x: (Ra - 33.15) / 2,
                        y: (Ra - 33.15) / 2,
                        width: 33.15,
                        height: 33.15,
                        rx: 4.25,
                        ry: 4.25
                    }, null, 8, Fa), po("rect", {
                        class: "stroke-black/50",
                        fill: "none",
                        "stroke-width": 2,
                        "stroke-miterlimit": "10",
                        x: 1,
                        y: 1,
                        width: 38,
                        height: 38,
                        rx: 6,
                        ry: 6,
                        "stroke-dasharray": l
                    }, null, 8, Aa), po("rect", {
                        class: "stroke-main/30",
                        fill: "none",
                        "stroke-width": 2,
                        "stroke-miterlimit": "10",
                        x: 1,
                        y: 1,
                        width: 38,
                        height: 38,
                        rx: 6,
                        ry: 6,
                        "stroke-dasharray": l
                    }, null, 8, Oa), po("rect", {
                        class: "stroke-main",
                        fill: "none",
                        "stroke-width": 2,
                        "stroke-miterlimit": "10",
                        x: 1,
                        y: 1,
                        width: 38,
                        height: 38,
                        rx: 6,
                        ry: 6,
                        "stroke-dasharray": l,
                        "stroke-dashoffset": l * ((100 - o.value) / 100)
                    }, null, 8, Ha)], 8, Pa)), (lo(), ao(Hn(e.icon), {
                        class: "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 drop-shadow-light",
                        style: F({
                            color: `rgb(${xt(t).icons||`var(--hud-${e.color})`}${xt(t).icons?" / 0.8":""})`
                        })
                    }, null, 8, ["style"])), xt(gs).percentage ? (lo(), io("p", Ia, W(Math.floor(o.value)) + "%", 1)) : wo("", !0)]),
                    _: 1
                }, 8, ["color"]))
            }
        }),
        Da = ["viewBox"],
        Ua = ["x", "y", "width", "height", "rx", "ry"],
        Wa = ["x", "y", "width", "height", "rx", "ry", "stroke-dashoffset"],
        Ga = {
            key: 0,
            class: "absolute -bottom-6 left-1/2 -translate-x-1/2 text-xs font-semibold drop-shadow-light"
        },
        qa = 40,
        Ka = vn({
            __name: "Mode8",
            props: {
                icon: {},
                color: {},
                percentage: {}
            },
            setup(e) {
                const t = xc(),
                    n = e,
                    l = 112 + 2 * Math.PI * 6,
                    o = Oo(() => Math.min(Math.max(n.percentage, 0), 100));
                return (n, r) => (lo(), ao(la, {
                    color: e.color
                }, {
                    default: Xt(() => [(lo(), io("svg", {
                        class: "w-11 h-11 overflow-visible",
                        viewBox: "0 0 40 40"
                    }, [po("rect", {
                        class: "fill-black/50",
                        x: 0,
                        y: 0,
                        width: qa,
                        height: qa,
                        rx: 6,
                        ry: 6
                    }), po("rect", {
                        class: "stroke-white/5",
                        fill: "none",
                        "stroke-width": 2,
                        "stroke-miterlimit": "10",
                        x: 2,
                        y: 2,
                        width: 36,
                        height: 36,
                        rx: 4,
                        ry: 4
                    }, null, 8, Ua), po("rect", {
                        class: "stroke-main",
                        fill: "none",
                        "stroke-width": 2,
                        "stroke-miterlimit": "10",
                        x: 2,
                        y: 2,
                        width: 36,
                        height: 36,
                        rx: 4,
                        ry: 4,
                        "stroke-dasharray": l,
                        "stroke-dashoffset": l * ((100 - o.value) / 100)
                    }, null, 8, Wa)], 8, Da)), (lo(), ao(Hn(e.icon), {
                        class: "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 drop-shadow-light",
                        style: F({
                            color: `rgb(${xt(t).icons||`var(--hud-${e.color})`}${xt(t).icons?" / 0.8":""})`
                        })
                    }, null, 8, ["style"])), xt(gs).percentage ? (lo(), io("p", Ga, W(Math.floor(o.value)) + "%", 1)) : wo("", !0)]),
                    _: 1
                }, 8, ["color"]))
            }
        }),
        Ja = ["viewBox"],
        Xa = ["x", "y", "width", "height"],
        Qa = ["x", "y", "width", "height", "stroke-dashoffset"],
        Ya = {
            key: 0,
            class: "absolute -bottom-6 left-1/2 -translate-x-1/2 text-xs font-semibold drop-shadow-light"
        },
        ec = vn({
            __name: "Mode9",
            props: {
                icon: {},
                color: {},
                percentage: {}
            },
            setup(e) {
                const t = xc(),
                    n = e,
                    l = 112 + 2 * Math.PI * 6,
                    o = Oo(() => Math.min(Math.max(n.percentage, 0), 100));
                return (n, r) => (lo(), ao(la, {
                    color: e.color
                }, {
                    default: Xt(() => [(lo(), io("svg", {
                        class: "w-11 h-11 overflow-visible",
                        viewBox: "0 0 40 40"
                    }, [po("rect", {
                        class: "stroke-black/50",
                        fill: "none",
                        "stroke-width": 2,
                        "stroke-miterlimit": "10",
                        x: 1,
                        y: 1,
                        width: 38,
                        height: 38,
                        rx: 6,
                        ry: 6,
                        "stroke-dasharray": l
                    }, null, 8, Xa), po("rect", {
                        class: "stroke-main",
                        fill: "none",
                        "stroke-width": 2,
                        "stroke-miterlimit": "10",
                        x: 1,
                        y: 1,
                        width: 38,
                        height: 38,
                        rx: 6,
                        ry: 6,
                        "stroke-dasharray": l,
                        "stroke-dashoffset": l * ((100 - o.value) / 100)
                    }, null, 8, Qa)], 8, Ja)), (lo(), ao(Hn(e.icon), {
                        class: "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 drop-shadow-light",
                        style: F({
                            color: `rgb(${xt(t).icons||`var(--hud-${e.color})`}${xt(t).icons?" / 0.8":""})`
                        })
                    }, null, 8, ["style"])), xt(gs).percentage ? (lo(), io("p", Ya, W(Math.floor(o.value)) + "%", 1)) : wo("", !0)]),
                    _: 1
                }, 8, ["color"]))
            }
        }),
        tc = ["viewBox"],
        nc = ["r", "cx", "cy"],
        lc = ["r", "cx", "cy"],
        oc = ["cx", "cy"],
        rc = ["cx", "cy"],
        sc = ["cx", "cy", "stroke-dashoffset"],
        ic = {
            key: 0,
            class: "absolute -bottom-6 left-1/2 -translate-x-1/2 text-xs font-semibold drop-shadow-light"
        },
        ac = vn({
            __name: "Mode10",
            props: {
                icon: {},
                color: {},
                percentage: {}
            },
            setup(e) {
                const t = xc(),
                    n = e,
                    l = 18,
                    o = 2 * Math.PI * l,
                    r = Oo(() => Math.min(Math.max(n.percentage, 0), 100));
                return (n, s) => (lo(), ao(la, {
                    color: e.color
                }, {
                    default: Xt(() => [(lo(), io("svg", {
                        class: "w-11 h-11 -rotate-90",
                        viewBox: "0 0 40 40"
                    }, [s[0] || (s[0] = po("defs", null, [po("path", {
                        id: "hud_dashed",
                        d: "m16.13.38c2.7-.53,5.39-.5,7.93.03l-3.86,19.53,14.79-13.19c1.72,1.94,3.08,4.24,3.95,6.81l-18.74,6.38,18.83,6.21c-.82,2.53-2.14,4.87-3.87,6.88l-14.96-13.1,4.07,19.59c-.07.01-.13.03-.2.04-2.64.55-5.28.55-7.78.08l3.9-19.71-15.06,13.44c-1.77-1.97-3.17-4.3-4.06-6.92l19.12-6.51L1.04,13.63c.86-2.56,2.23-4.92,4.02-6.92l15.13,13.24L16.13.38h0Zm10.3.68h0l-6.23,18.88L13.74,1.01c-2.61.86-4.95,2.22-6.92,3.95l13.37,14.99L.4,16.03c-.52,2.57-.55,5.29.02,8.03l19.78-4.11-13.28,15.18c2.03,1.76,4.41,3.1,6.98,3.92l6.3-19.1,6.44,18.92c2.58-.9,4.88-2.3,6.81-4.06l-13.26-14.86,19.44,3.85c.49-2.52.5-5.19-.06-7.86h0s-19.38,4.01-19.38,4.01l13.06-14.92c-1.99-1.75-4.31-3.11-6.83-3.96Z"
                    })], -1)), s[1] || (s[1] = po("clipPath", {
                        id: "hud_progress"
                    }, [po("use", {
                        "xlink:href": "#hud_dashed",
                        style: {
                            overflow: "visible"
                        }
                    })], -1)), po("circle", {
                        r: 14,
                        cx: 20,
                        cy: 20,
                        fill: "transparent",
                        "stroke-width": 4,
                        class: "fill-black/50"
                    }, null, 8, nc), po("circle", {
                        r: 14,
                        cx: 20,
                        cy: 20,
                        fill: "transparent",
                        "stroke-width": 4,
                        class: "fill-main/30"
                    }, null, 8, lc), po("circle", {
                        style: {
                            "clip-path": "url(#hud_progress)"
                        },
                        r: l,
                        cx: 20,
                        cy: 20,
                        fill: "transparent",
                        "stroke-width": 4,
                        class: "stroke-black/50"
                    }, null, 8, oc), po("circle", {
                        style: {
                            "clip-path": "url(#hud_progress)"
                        },
                        r: l,
                        cx: 20,
                        cy: 20,
                        fill: "transparent",
                        "stroke-width": 4,
                        class: "stroke-main/30"
                    }, null, 8, rc), po("circle", {
                        style: {
                            "clip-path": "url(#hud_progress)"
                        },
                        r: l,
                        cx: 20,
                        cy: 20,
                        fill: "transparent",
                        "stroke-width": 4,
                        "stroke-dasharray": o,
                        "stroke-dashoffset": o * ((100 - r.value) / 100),
                        class: "transition-all stroke-main"
                    }, null, 8, sc)], 8, tc)), (lo(), ao(Hn(e.icon), {
                        class: "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 drop-shadow-light",
                        style: F({
                            color: `rgb(${xt(t).icons||`var(--hud-${e.color})`}${xt(t).icons?" / 0.8":""})`
                        })
                    }, null, 8, ["style"])), xt(gs).percentage ? (lo(), io("p", ic, W(Math.floor(r.value)) + "%", 1)) : wo("", !0)]),
                    _: 1
                }, 8, ["color"]))
            }
        }),
        cc = ["viewBox"],
        uc = ["r", "cx", "cy"],
        dc = ["r", "cx", "cy"],
        hc = ["r", "cx", "cy", "stroke-dashoffset"],
        fc = {
            key: 0,
            class: "absolute -bottom-6 left-1/2 -translate-x-1/2 text-xs font-semibold drop-shadow-light"
        },
        pc = vn({
            __name: "Mode11",
            props: {
                icon: {},
                color: {},
                percentage: {}
            },
            setup(e) {
                const t = xc(),
                    n = e,
                    l = 2 * Math.PI * 18,
                    o = Oo(() => Math.min(Math.max(n.percentage, 0), 100));
                return (n, r) => (lo(), ao(la, {
                    color: e.color
                }, {
                    default: Xt(() => [(lo(), io("svg", {
                        class: "w-11 h-11 -rotate-90",
                        viewBox: "0 0 40 40"
                    }, [r[0] || (r[0] = po("defs", null, [po("path", {
                        id: "hud_dashed",
                        d: "m16.13.38c2.7-.53,5.39-.5,7.93.03l-3.86,19.53,14.79-13.19c1.72,1.94,3.08,4.24,3.95,6.81l-18.74,6.38,18.83,6.21c-.82,2.53-2.14,4.87-3.87,6.88l-14.96-13.1,4.07,19.59c-.07.01-.13.03-.2.04-2.64.55-5.28.55-7.78.08l3.9-19.71-15.06,13.44c-1.77-1.97-3.17-4.3-4.06-6.92l19.12-6.51L1.04,13.63c.86-2.56,2.23-4.92,4.02-6.92l15.13,13.24L16.13.38h0Zm10.3.68h0l-6.23,18.88L13.74,1.01c-2.61.86-4.95,2.22-6.92,3.95l13.37,14.99L.4,16.03c-.52,2.57-.55,5.29.02,8.03l19.78-4.11-13.28,15.18c2.03,1.76,4.41,3.1,6.98,3.92l6.3-19.1,6.44,18.92c2.58-.9,4.88-2.3,6.81-4.06l-13.26-14.86,19.44,3.85c.49-2.52.5-5.19-.06-7.86h0s-19.38,4.01-19.38,4.01l13.06-14.92c-1.99-1.75-4.31-3.11-6.83-3.96Z"
                    })], -1)), r[1] || (r[1] = po("clipPath", {
                        id: "hud_progress"
                    }, [po("use", {
                        "xlink:href": "#hud_dashed",
                        style: {
                            overflow: "visible"
                        }
                    })], -1)), po("circle", {
                        r: 20,
                        cx: 20,
                        cy: 20,
                        fill: "transparent",
                        "stroke-width": 4,
                        class: "fill-black/50"
                    }, null, 8, uc), po("circle", {
                        style: {
                            "clip-path": "url(#hud_progress)"
                        },
                        r: 17,
                        cx: 20,
                        cy: 20,
                        fill: "transparent",
                        "stroke-width": 4,
                        class: "stroke-white/5"
                    }, null, 8, dc), po("circle", {
                        style: {
                            "clip-path": "url(#hud_progress)"
                        },
                        r: 17,
                        cx: 20,
                        cy: 20,
                        fill: "transparent",
                        "stroke-width": 4,
                        "stroke-dasharray": l,
                        "stroke-dashoffset": l * ((100 - o.value) / 100),
                        class: "transition-all stroke-main"
                    }, null, 8, hc)], 8, cc)), (lo(), ao(Hn(e.icon), {
                        class: "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 drop-shadow-light",
                        style: F({
                            color: `rgb(${xt(t).icons||`var(--hud-${e.color})`}${xt(t).icons?" / 0.8":""})`
                        })
                    }, null, 8, ["style"])), xt(gs).percentage ? (lo(), io("p", fc, W(Math.floor(o.value)) + "%", 1)) : wo("", !0)]),
                    _: 1
                }, 8, ["color"]))
            }
        }),
        mc = ["viewBox"],
        vc = ["cx", "cy"],
        gc = ["cx", "cy", "stroke-dashoffset"],
        Cc = {
            key: 0,
            class: "absolute -bottom-6 left-1/2 -translate-x-1/2 text-xs font-semibold drop-shadow-light"
        },
        wc = vn({
            __name: "Mode12",
            props: {
                icon: {},
                color: {},
                percentage: {}
            },
            setup(e) {
                const t = xc(),
                    n = e,
                    l = 2 * Math.PI * 18,
                    o = Oo(() => Math.min(Math.max(n.percentage, 0), 100));
                return (n, r) => (lo(), ao(la, {
                    color: e.color
                }, {
                    default: Xt(() => [(lo(), io("svg", {
                        class: "w-11 h-11 -rotate-90",
                        viewBox: "0 0 40 40"
                    }, [r[0] || (r[0] = po("defs", null, [po("path", {
                        id: "hud_dashed",
                        d: "m16.13.38c2.7-.53,5.39-.5,7.93.03l-3.86,19.53,14.79-13.19c1.72,1.94,3.08,4.24,3.95,6.81l-18.74,6.38,18.83,6.21c-.82,2.53-2.14,4.87-3.87,6.88l-14.96-13.1,4.07,19.59c-.07.01-.13.03-.2.04-2.64.55-5.28.55-7.78.08l3.9-19.71-15.06,13.44c-1.77-1.97-3.17-4.3-4.06-6.92l19.12-6.51L1.04,13.63c.86-2.56,2.23-4.92,4.02-6.92l15.13,13.24L16.13.38h0Zm10.3.68h0l-6.23,18.88L13.74,1.01c-2.61.86-4.95,2.22-6.92,3.95l13.37,14.99L.4,16.03c-.52,2.57-.55,5.29.02,8.03l19.78-4.11-13.28,15.18c2.03,1.76,4.41,3.1,6.98,3.92l6.3-19.1,6.44,18.92c2.58-.9,4.88-2.3,6.81-4.06l-13.26-14.86,19.44,3.85c.49-2.52.5-5.19-.06-7.86h0s-19.38,4.01-19.38,4.01l13.06-14.92c-1.99-1.75-4.31-3.11-6.83-3.96Z"
                    })], -1)), r[1] || (r[1] = po("clipPath", {
                        id: "hud_progress"
                    }, [po("use", {
                        "xlink:href": "#hud_dashed",
                        style: {
                            overflow: "visible"
                        }
                    })], -1)), po("circle", {
                        style: {
                            "clip-path": "url(#hud_progress)"
                        },
                        r: 18,
                        cx: 20,
                        cy: 20,
                        fill: "transparent",
                        "stroke-width": 4,
                        class: "stroke-black/50"
                    }, null, 8, vc), po("circle", {
                        style: {
                            "clip-path": "url(#hud_progress)"
                        },
                        r: 18,
                        cx: 20,
                        cy: 20,
                        fill: "transparent",
                        "stroke-width": 4,
                        "stroke-dasharray": l,
                        "stroke-dashoffset": l * ((100 - o.value) / 100),
                        class: "transition-all stroke-main"
                    }, null, 8, gc)], 8, mc)), (lo(), ao(Hn(e.icon), {
                        class: "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 drop-shadow-light",
                        style: F({
                            color: `rgb(${xt(t).icons||`var(--hud-${e.color})`}${xt(t).icons?" / 0.8":""})`
                        })
                    }, null, 8, ["style"])), xt(gs).percentage ? (lo(), io("p", Cc, W(Math.floor(o.value)) + "%", 1)) : wo("", !0)]),
                    _: 1
                }, 8, ["color"]))
            }
        }),
        xc = rs("settings", () => {
            const e = Ct(!1),
                t = Ct(!1),
                n = Ct(!1),
                l = Ct({
                    display: !1,
                    option: ""
                }),
                o = Ct({
                    display: !1,
                    max: 0,
                    list: {}
                }),
                r = Ct({
                    display: !1,
                    code: ""
                }),
                s = Ct({
                    info: 1,
                    icon: "fill",
                    status: 1,
                    vehicle: 1
                }),
                i = Oo(() => {
                    if (!gs.value.iconColor) return null;
                    const e = is(gs.value.iconColor);
                    return e ? `${e.r} ${e.g} ${e.b}` : null
                }),
                a = Oo(() => {
                    switch (s.value.info) {
                        case 1:
                        default:
                            return xs;
                        case 2:
                            return Ls;
                        case 3:
                            return Vs
                    }
                }),
                c = Oo(() => {
                    switch (s.value.info) {
                        case 1:
                        default:
                            return Hs;
                        case 2:
                            return Ws
                    }
                }),
                u = Oo(() => {
                    switch (s.value.vehicle) {
                        case 1:
                        default:
                            return ki;
                        case 2:
                            return Hi;
                        case 3:
                            return na
                    }
                }),
                d = Oo(() => {
                    switch (s.value.status) {
                        case 1:
                        default:
                            return da;
                        case 2:
                            return ga;
                        case 3:
                            return ba;
                        case 4:
                            return La;
                        case 5:
                            return Za;
                        case 6:
                            return Ea;
                        case 7:
                            return Na;
                        case 8:
                            return Ka;
                        case 9:
                            return ec;
                        case 10:
                            return ac;
                        case 11:
                            return pc;
                        case 12:
                            return wc
                    }
                });
            return {
                display: e,
                map: t,
                voiceState: n,
                menu: l,
                domination: o,
                video: r,
                modes: s,
                icons: i,
                info: a,
                location: c,
                vehicle: u,
                status: d,
                closeMenu: () => {
                    vs("CloseMenu"), l.value.display = !1, l.value.option = ""
                }
            }
        }),
        yc = {
            key: 0,
            class: "absolute top-10 left-1/2 -translate-x-1/2"
        },
        bc = vn({
            __name: "Logo",
            setup(e) {
                const t = xc();
                return (e, n) => (lo(), ao(Qo, {
                    name: "fade-top"
                }, {
                    default: Xt(() => [
                        xt(t).display
                            ? (lo(), io("div", yc, [
                                po("img", {
                                    src: ss,
                                    style: F({
                                        height: "12rem"
                                    })
                                }, null, 4)
                            ]))
                            : wo("", !0)
                    ]),
                    _: 1
                }))
            }
        }),
        kc = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const _c = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", kc, [...t[0] || (t[0] = [Co('<path d="M9 3V21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M6 7V17" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M12 6V18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M15 9L15 15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M18 7L18 17" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M21 11L21 13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M3 11L3 13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>', 7)])])
            }]
        ]),
        Mc = ["textContent"],
        Lc = vn({
            __name: "Radio",
            setup(e) {
                const t = zs();
                return (e, n) => (lo(), ao(Er, {
                    name: "radio",
                    tag: "div",
                    class: "flex flex-col items-start gap-1",
                    appear: ""
                }, {
                    default: Xt(() => [(lo(!0), io(Xl, null, Rn(xt(t).radioList, e => (lo(), io("div", {
                        class: "flex items-center gap-2 bg-from/80 py-1 px-2 rounded-md",
                        key: e.Source
                    }, [mo(_c, {
                        class: "size-4 min-w-4 text-white/50"
                    }), po("div", {
                        class: "text-sm whitespace-nowrap",
                        textContent: W(e.Name)
                    }, null, 8, Mc)]))), 128))]),
                    _: 1
                }))
            }
        }),
        Sc = {
            key: 0,
            class: "absolute z-[9999] top-1/2 left-1/2 -translate-y-1/2 -translate-x-1/2 w-full h-full min-w-full min-h-full max-w-full max-h-full bg-black rounded-md overflow-hidden"
        },
        Vc = ["src"],
        zc = vn({
            __name: "Video",
            setup(e) {
                const t = xc(),
                    n = Ct(`https://player.vimeo.com/video/${t.video.code}?autoplay=1&controls=0&loop=0`);
                return Fl(() => t.video.code, e => {
                    n.value = `https://player.vimeo.com/video/${e}?autoplay=1&controls=0&loop=0`
                }), (e, l) => (lo(), ao(Qo, {
                    name: "fade"
                }, {
                    default: Xt(() => [xt(t).video.display ? (lo(), io("div", Sc, [po("iframe", {
                        src: n.value,
                        width: "100%",
                        height: "100%",
                        frameborder: "0",
                        allow: "autoplay; fullscreen; picture-in-picture",
                        allowfullscreen: ""
                    }, null, 8, Vc)])) : wo("", !0)]),
                    _: 1
                }))
            }
        }),
        Zc = {
            width: "10",
            height: "11",
            viewBox: "0 0 10 11",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg"
        };
    const jc = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", Zc, [...t[0] || (t[0] = [po("path", {
                    d: "M1.27907 0L0.0048837 3.43419C0.0109302 3.44924 0.0244186 3.46929 0.0548837 3.49687C0.105116 3.54199 0.19907 3.59714 0.322093 3.64227C0.567907 3.73001 0.924419 3.78015 1.27907 3.78015C1.63256 3.78015 1.9907 3.73001 2.23721 3.64227C2.35814 3.59714 2.45349 3.54199 2.50233 3.49687C2.53256 3.46678 2.54651 3.44924 2.55349 3.43419L1.27907 0ZM5 0L3.72558 3.43419C3.73256 3.44924 3.74651 3.46678 3.77674 3.49687C3.82558 3.54199 3.92093 3.59714 4.04186 3.64227C4.28837 3.73001 4.64651 3.78015 5 3.78015C5.35581 3.78015 5.71163 3.73001 5.95814 3.64227C6.07907 3.59714 6.17442 3.54199 6.22326 3.49687C6.25349 3.46678 6.26744 3.44924 6.27442 3.43419L5 0ZM8.72093 0L7.44651 3.43419C7.45349 3.44924 7.46744 3.46678 7.49767 3.49687C7.54651 3.54199 7.64186 3.59714 7.76279 3.64227C8.0093 3.73001 8.36744 3.78015 8.72093 3.78015C9.07442 3.78015 9.43256 3.73001 9.67907 3.64227C9.8 3.59714 9.89535 3.54199 9.94419 3.49687C9.97442 3.46678 9.98837 3.44924 9.99535 3.43419L8.72093 0ZM0 3.98822V4.41439C0 4.43946 0.00465117 4.45951 0.0548837 4.50714C0.105116 4.55227 0.19907 4.60742 0.322093 4.65254C0.567907 4.74029 0.924419 4.79042 1.27907 4.79042C1.63256 4.79042 1.9907 4.74029 2.23721 4.65254C2.35814 4.60742 2.45349 4.55227 2.50233 4.50714C2.55349 4.45951 2.55814 4.43946 2.55814 4.41439V3.98822C2.49767 4.0183 2.43488 4.04588 2.36744 4.06844C2.05581 4.18125 1.66977 4.23139 1.27907 4.23139C0.889535 4.23139 0.50186 4.18125 0.189535 4.06844C0.122791 4.04588 0.0595349 4.0183 0 3.98822ZM3.72093 3.98822V4.41439C3.72093 4.43946 3.72558 4.45951 3.77674 4.50714C3.82558 4.55227 3.92093 4.60742 4.04186 4.65254C4.28837 4.74029 4.64651 4.79042 5 4.79042C5.35581 4.79042 5.71163 4.74029 5.95814 4.65254C6.07907 4.60742 6.17442 4.55227 6.22326 4.50714C6.27442 4.45951 6.27907 4.43946 6.27907 4.41439V3.98822C6.2186 4.0183 6.15581 4.04588 6.08837 4.06844C5.77674 4.18125 5.3907 4.23139 5 4.23139C4.6093 4.23139 4.22326 4.18125 3.91163 4.06844C3.84419 4.04588 3.7814 4.0183 3.72093 3.98822ZM7.44186 3.98822V4.41439C7.44186 4.43946 7.44651 4.45951 7.49767 4.50714C7.54651 4.55227 7.64186 4.60742 7.76279 4.65254C8.0093 4.74029 8.36744 4.79042 8.72093 4.79042C9.07442 4.79042 9.43256 4.74029 9.67907 4.65254C9.8 4.60742 9.89535 4.55227 9.94419 4.50714C9.99535 4.45951 10 4.43946 10 4.41439V3.98822C9.93954 4.0183 9.87674 4.04588 9.8093 4.06844C9.49767 4.18125 9.11163 4.23139 8.72093 4.23139C8.33023 4.23139 7.94419 4.18125 7.63256 4.06844C7.56512 4.04588 7.50233 4.0183 7.44186 3.98822ZM0 4.9985V8.96691L0.396744 9.82176L0.0081395 10.6591C0.0151162 10.6741 0.0283721 10.6917 0.0548837 10.7167C0.105116 10.7618 0.19907 10.817 0.322093 10.8621C0.567907 10.9499 0.924419 11 1.27907 11C1.63256 11 1.9907 10.9499 2.23721 10.8621C2.35814 10.817 2.45349 10.7618 2.50233 10.7167C2.53023 10.6917 2.54186 10.6741 2.55116 10.6591L2.16047 9.82176L2.55814 8.96691V4.9985C2.49767 5.02858 2.43488 5.05615 2.36744 5.07872C2.05581 5.19153 1.66977 5.24166 1.27907 5.24166C0.889535 5.24166 0.50186 5.19153 0.189535 5.07872C0.122791 5.05615 0.0595349 5.02858 0 4.9985ZM3.72093 4.9985V8.96691L4.1186 9.82176L3.72791 10.6591C3.73721 10.6741 3.74884 10.6917 3.77674 10.7167C3.82558 10.7618 3.92093 10.817 4.04186 10.8621C4.28837 10.9499 4.64651 11 5 11C5.35581 11 5.71163 10.9499 5.95814 10.8621C6.07907 10.817 6.17442 10.7618 6.22326 10.7167C6.25116 10.6917 6.26279 10.6741 6.27209 10.6591L5.8814 9.82176L6.27907 8.96691V4.9985C6.2186 5.02858 6.15581 5.05615 6.08837 5.07872C5.77674 5.19153 5.3907 5.24166 5 5.24166C4.6093 5.24166 4.22326 5.19153 3.91163 5.07872C3.84419 5.05615 3.7814 5.02858 3.72093 4.9985ZM7.44186 4.9985V8.96691L7.83953 9.82176L7.44884 10.6591C7.45814 10.6741 7.46977 10.6917 7.49767 10.7167C7.54651 10.7618 7.64186 10.817 7.76279 10.8621C8.0093 10.9499 8.36744 11 8.72093 11C9.07442 11 9.43256 10.9499 9.67907 10.8621C9.8 10.817 9.89535 10.7618 9.94419 10.7167C9.97209 10.6917 9.98372 10.6741 9.99302 10.6591L9.60233 9.82176L10 8.96691V4.9985C9.93954 5.02858 9.87674 5.05615 9.8093 5.07872C9.49767 5.19153 9.11163 5.24166 8.72093 5.24166C8.33023 5.24166 7.94419 5.19153 7.63256 5.07872C7.56512 5.05615 7.50233 5.02858 7.44186 4.9985Z",
                    fill: "currentColor"
                }, null, -1)])])
            }]
        ]),
        $c = {
            width: "24",
            height: "24",
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg"
        };
    const Bc = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", $c, [...t[0] || (t[0] = [po("path", {
                    "fill-rule": "evenodd",
                    "clip-rule": "evenodd",
                    d: "M11.6016 1.96136C11.5243 2.00861 11.4366 2.07709 11.4068 2.11352C11.377 2.14994 10.6963 3.50861 9.89414 5.13283C9.09201 6.75705 8.40975 8.09125 8.37801 8.09772C8.34632 8.10419 6.86985 8.32 5.09704 8.57734C3.32418 8.83464 1.81593 9.07506 1.74534 9.11153C1.39378 9.29336 1.24195 9.76192 1.4219 10.1099C1.46057 10.1846 2.56064 11.2872 3.86653 12.56C5.79421 14.4388 6.23657 14.8926 6.21815 14.9723C6.20564 15.0262 5.94857 16.511 5.64693 18.2718L5.09845 21.4734L5.17842 21.6828C5.28323 21.9573 5.5132 22.1325 5.80532 22.1606C6.07289 22.1863 5.8732 22.2827 9.4162 20.419C10.8181 19.6815 11.982 19.0781 12.0027 19.0781C12.0233 19.0781 13.3654 19.7755 14.985 20.6278C17.9212 22.1731 17.9304 22.1775 18.1777 22.159C18.4865 22.1359 18.645 22.0254 18.7929 21.7303L18.906 21.5044L18.3559 18.2874C18.0533 16.518 17.7954 15.0265 17.7827 14.973C17.7639 14.894 18.2092 14.4373 20.1327 12.5627C21.438 11.2906 22.538 10.1877 22.5772 10.1118C22.6693 9.93367 22.6684 9.6114 22.5752 9.43126C22.494 9.27437 22.3123 9.11528 22.1564 9.06466C22.1004 9.04651 20.5945 8.81889 18.8098 8.55883L15.5649 8.08595L14.1065 5.13283C13.3043 3.50861 12.613 2.14061 12.5702 2.09289C12.3656 1.86442 11.8702 1.79716 11.6016 1.96136Z",
                    fill: "currentColor"
                }, null, -1)])])
            }]
        ]),
        Ec = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const Pc = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", Ec, [...t[0] || (t[0] = [po("path", {
                    "fill-rule": "evenodd",
                    "clip-rule": "evenodd",
                    d: "M12 1.25C7.16751 1.25 3.25 5.16751 3.25 10V20.4C3.25 21.6979 4.30213 22.75 5.6 22.75C6.89787 22.75 7.95 21.6979 7.95 20.4V19.6C7.95 19.1306 8.33056 18.75 8.8 18.75C9.26944 18.75 9.65 19.1306 9.65 19.6V20.4C9.65 21.6979 10.7021 22.75 12 22.75C13.2979 22.75 14.35 21.6979 14.35 20.4V19.6C14.35 19.1306 14.7306 18.75 15.2 18.75C15.6694 18.75 16.05 19.1306 16.05 19.6V20.4C16.05 21.6979 17.1021 22.75 18.4 22.75C19.6979 22.75 20.75 21.6979 20.75 20.4V10C20.75 5.16751 16.8325 1.25 12 1.25ZM9 8.75C8.30964 8.75 7.75 9.30964 7.75 10C7.75 10.6904 8.30964 11.25 9 11.25H9.00896C9.69931 11.25 10.259 10.6904 10.259 10C10.259 9.30964 9.69931 8.75 9.00896 8.75H9ZM14.991 8.75C14.3007 8.75 13.741 9.30964 13.741 10C13.741 10.6904 14.3007 11.25 14.991 11.25H15C15.6904 11.25 16.25 10.6904 16.25 10C16.25 9.30964 15.6904 8.75 15 8.75H14.991Z",
                    fill: "currentColor"
                }, null, -1)])])
            }]
        ]),
        Tc = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const Fc = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", Tc, [...t[0] || (t[0] = [po("path", {
                    d: "M20 10C20 5.58172 16.4183 2 12 2C7.58172 2 4 5.58172 4 10V20.4C4 21.2837 4.71634 22 5.6 22C6.48366 22 7.2 21.2837 7.2 20.4V19.6C7.2 18.7163 7.91634 18 8.8 18C9.68366 18 10.4 18.7163 10.4 19.6V20.4C10.4 21.2837 11.1163 22 12 22C12.8837 22 13.6 21.2837 13.6 20.4V19.6C13.6 18.7163 14.3163 18 15.2 18C16.0837 18 16.8 18.7163 16.8 19.6V20.4C16.8 21.2837 17.5163 22 18.4 22C19.2837 22 20 21.2837 20 20.4V10Z",
                    stroke: "currentColor",
                    "stroke-width": "2"
                }, null, -1), po("path", {
                    d: "M9.00896 10H9M15 10H14.991",
                    stroke: "currentColor",
                    "stroke-width": "2",
                    "stroke-linecap": "round",
                    "stroke-linejoin": "round"
                }, null, -1)])])
            }]
        ]),
        Ac = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const Oc = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", Ac, [...t[0] || (t[0] = [po("path", {
                    "fill-rule": "evenodd",
                    "clip-rule": "evenodd",
                    d: "M11.9999 4.5C11.4477 4.5 10.9999 4.05228 10.9999 3.5V1.5C10.9999 0.947715 11.4477 0.5 11.9999 0.5C12.5522 0.5 12.9999 0.947715 12.9999 1.5V3.5C12.9999 4.05228 12.5522 4.5 11.9999 4.5ZM1.49994 11C0.947654 11 0.499939 11.4477 0.499939 12C0.499939 12.5523 0.947654 13 1.49994 13H3.49994C4.05222 13 4.49994 12.5523 4.49994 12C4.49994 11.4477 4.05222 11 3.49994 11H1.49994ZM20.4999 11C19.9477 11 19.4999 11.4477 19.4999 12C19.4999 12.5523 19.9477 13 20.4999 13H22.4999C23.0522 13 23.4999 12.5523 23.4999 12C23.4999 11.4477 23.0522 11 22.4999 11H20.4999ZM10.9999 22.5C10.9999 23.0523 11.4477 23.5 11.9999 23.5C12.5522 23.5 12.9999 23.0523 12.9999 22.5V20.5C12.9999 19.9477 12.5522 19.5 11.9999 19.5C11.4477 19.5 10.9999 19.9477 10.9999 20.5V22.5Z",
                    fill: "currentColor"
                }, null, -1), po("path", {
                    d: "M8.24994 12C8.24994 9.92893 9.92887 8.25 11.9999 8.25C14.071 8.25 15.7499 9.92893 15.7499 12C15.7499 14.0711 14.071 15.75 11.9999 15.75C9.92887 15.75 8.24994 14.0711 8.24994 12Z",
                    fill: "currentColor"
                }, null, -1), po("path", {
                    "fill-rule": "evenodd",
                    "clip-rule": "evenodd",
                    d: "M12.0136 4.5C7.87148 4.5 4.51361 7.85786 4.51361 12C4.51361 16.1421 7.87148 19.5 12.0136 19.5C16.1557 19.5 19.5136 16.1421 19.5136 12C19.5136 7.85786 16.1557 4.5 12.0136 4.5ZM2.51361 12C2.51361 6.75329 6.76691 2.5 12.0136 2.5C17.2603 2.5 21.5136 6.75329 21.5136 12C21.5136 17.2467 17.2603 21.5 12.0136 21.5C6.76691 21.5 2.51361 17.2467 2.51361 12Z",
                    fill: "currentColor"
                }, null, -1)])])
            }]
        ]),
        Hc = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const Ic = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", Hc, [...t[0] || (t[0] = [Co('<path d="M20.5137 12C20.5137 16.6944 16.7081 20.5 12.0137 20.5C7.31925 20.5 3.51367 16.6944 3.51367 12C3.51367 7.30558 7.31925 3.5 12.0137 3.5C16.7081 3.5 20.5137 7.30558 20.5137 12Z" stroke="currentColor" stroke-width="2"></path><path d="M22.5 12H20.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M3.5 12H1.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M12 1.5L12 3.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M12 20.5V22.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M15 12C15 13.6569 13.6568 15 12 15C10.3431 15 8.99995 13.6569 8.99995 12C8.99995 10.3431 10.3431 9 12 9C13.6568 9 15 10.3431 15 12Z" stroke="currentColor" stroke-width="2"></path>', 6)])])
            }]
        ]),
        Rc = st({
            id: 0,
            toasts: []
        }),
        Nc = Rc.toasts,
        Dc = {
            class: "w-full"
        },
        Uc = {
            class: "text-sm whitespace-nowrap"
        },
        Wc = {
            key: 0,
            class: "text-sm whitespace-nowrap"
        },
        Gc = vn({
            __name: "Killfeed",
            setup(e) {
                const t = xc();
                return (e, n) => (lo(), io("div", Dc, [mo(Er, {
                    name: "top-right",
                    tag: "ul",
                    class: "flex flex-col items-end gap-1 z-[9999] pointer-events-none",
                    appear: ""
                }, {
                    default: Xt(() => [(lo(!0), io(Xl, null, Rn(xt(Nc), e => (lo(), io("li", {
                        class: "flex items-center gap-2 bg-from/80 py-1 px-3 rounded-md",
                        key: e.id
                    }, [po("p", Uc, W(e.killer), 1), (lo(), ao(Hn("fill" === xt(t).modes.icon ? e.victim ? Oc : Pc : e.victim ? Ic : Fc), {
                        class: R(["size-4 min-w-4", xt(gs).grayscale ? "text-white/50" : "text-main"])
                    }, null, 8, ["class"])), e.victim ? (lo(), io("p", Wc, W(e.victim), 1)) : wo("", !0)]))), 128))]),
                    _: 1
                })]))
            }
        }),
        qc = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const Kc = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", qc, [...t[0] || (t[0] = [po("path", {
                    d: "M6.25 7C6.25 3.82436 8.82436 1.25 12 1.25C15.1756 1.25 17.75 3.82436 17.75 7V11C17.75 14.1756 15.1756 16.75 12 16.75C8.82436 16.75 6.25 14.1756 6.25 11V7Z",
                    fill: "currentColor"
                }, null, -1), po("path", {
                    "fill-rule": "evenodd",
                    "clip-rule": "evenodd",
                    d: "M4.22222 10.25C4.75917 10.25 5.19444 10.6805 5.19444 11.2115C5.19444 14.9288 8.2414 17.9423 12 17.9423C15.7586 17.9423 18.8056 14.9288 18.8056 11.2115C18.8056 10.6805 19.2408 10.25 19.7778 10.25C20.3147 10.25 20.75 10.6805 20.75 11.2115C20.75 15.6659 17.3472 19.3343 12.9722 19.8126V20.8269H14.9167C15.4536 20.8269 15.8889 21.2574 15.8889 21.7885C15.8889 22.3195 15.4536 22.75 14.9167 22.75H9.08333C8.54639 22.75 8.11111 22.3195 8.11111 21.7885C8.11111 21.2574 8.54639 20.8269 9.08333 20.8269H11.0278V19.8126C6.65283 19.3343 3.25 15.6659 3.25 11.2115C3.25 10.6805 3.68528 10.25 4.22222 10.25Z",
                    fill: "currentColor"
                }, null, -1)])])
            }]
        ]),
        Jc = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none",
            class: "scale-110"
        };
    const Xc = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", Jc, [...t[0] || (t[0] = [po("path", {
                    "fill-rule": "evenodd",
                    "clip-rule": "evenodd",
                    d: "M17.312 1.93059C15.9686 1.74998 14.2479 1.74999 12.0572 1.75H11.9428C9.75212 1.74999 8.03144 1.74998 6.68802 1.93059C5.31137 2.11568 4.21911 2.50272 3.36091 3.36091C2.50272 4.21911 2.11568 5.31137 1.93059 6.68802C1.74998 8.03144 1.74999 9.75212 1.75 11.9428V12.0572C1.74999 14.2479 1.74998 15.9686 1.93059 17.312C2.11568 18.6886 2.50272 19.7809 3.36091 20.6391C4.21911 21.4973 5.31137 21.8843 6.68802 22.0694C8.03144 22.25 9.7521 22.25 11.9428 22.25H11.9428H12.0572H12.0572C14.2479 22.25 15.9686 22.25 17.312 22.0694C18.6886 21.8843 19.7809 21.4973 20.6391 20.6391C21.4973 19.7809 21.8843 18.6886 22.0694 17.312C22.25 15.9686 22.25 14.2479 22.25 12.0572V12.0572V11.9428V11.9428C22.25 9.7521 22.25 8.03144 22.0694 6.68802C21.8843 5.31137 21.4973 4.21911 20.6391 3.36091C19.7809 2.50272 18.6886 2.11568 17.312 1.93059ZM12.75 8C12.75 7.58579 12.4142 7.25 12 7.25C11.5858 7.25 11.25 7.58579 11.25 8V16C11.25 16.4142 11.5858 16.75 12 16.75C12.4142 16.75 12.75 16.4142 12.75 16V8ZM9.75 10C9.75 9.58579 9.41421 9.25 9 9.25C8.58579 9.25 8.25 9.58579 8.25 10V14C8.25 14.4142 8.58579 14.75 9 14.75C9.41421 14.75 9.75 14.4142 9.75 14V10ZM15.75 10C15.75 9.58579 15.4142 9.25 15 9.25C14.5858 9.25 14.25 9.58579 14.25 10V14C14.25 14.4142 14.5858 14.75 15 14.75C15.4142 14.75 15.75 14.4142 15.75 14V10ZM6.75 11C6.75 10.5858 6.41421 10.25 6 10.25C5.58579 10.25 5.25 10.5858 5.25 11V13C5.25 13.4142 5.58579 13.75 6 13.75C6.41421 13.75 6.75 13.4142 6.75 13V11ZM18.75 11C18.75 10.5858 18.4142 10.25 18 10.25C17.5858 10.25 17.25 10.5858 17.25 11V13C17.25 13.4142 17.5858 13.75 18 13.75C18.4142 13.75 18.75 13.4142 18.75 13V11Z",
                    fill: "currentColor"
                }, null, -1)])])
            }]
        ]),
        Qc = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const Yc = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", Qc, [...t[0] || (t[0] = [po("path", {
                    d: "M4.25 7C4.25 4.37665 6.37665 2.25 9 2.25C11.6234 2.25 13.75 4.37665 13.75 7C13.75 9.62335 11.6234 11.75 9 11.75C6.37665 11.75 4.25 9.62335 4.25 7Z",
                    fill: "currentColor"
                }, null, -1), po("path", {
                    d: "M1.25 19C1.25 15.8244 3.82436 13.25 7 13.25H11C14.1756 13.25 16.75 15.8244 16.75 19C16.75 20.5188 15.5188 21.75 14 21.75H4C2.48122 21.75 1.25 20.5188 1.25 19Z",
                    fill: "currentColor"
                }, null, -1), po("path", {
                    d: "M13.374 11.4644C13.8812 11.6492 14.4288 11.75 15 11.75C17.6233 11.75 19.75 9.62335 19.75 7C19.75 4.37665 17.6233 2.25 15 2.25C14.4288 2.25 13.8812 2.35081 13.374 2.5356C14.5317 3.67 15.25 5.25111 15.25 7C15.25 8.74889 14.5317 10.33 13.374 11.4644Z",
                    fill: "currentColor"
                }, null, -1), po("path", {
                    d: "M17.24 21.75H19.9995C21.5183 21.75 22.7495 20.5188 22.7495 19C22.7495 15.8244 20.1752 13.25 16.9995 13.25H15.416C17.1391 14.5754 18.2495 16.658 18.2495 19C18.2495 20.0488 17.8697 21.0088 17.24 21.75Z",
                    fill: "currentColor"
                }, null, -1)])])
            }]
        ]),
        eu = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const tu = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", eu, [...t[0] || (t[0] = [po("path", {
                    d: "M7.25 7C7.25 4.37665 9.37665 2.25 12 2.25C14.6234 2.25 16.75 4.37665 16.75 7C16.75 9.62335 14.6234 11.75 12 11.75C9.37665 11.75 7.25 9.62335 7.25 7Z",
                    fill: "currentColor"
                }, null, -1), po("path", {
                    d: "M4.25 19C4.25 15.8244 6.82436 13.25 10 13.25H14C17.1756 13.25 19.75 15.8244 19.75 19C19.75 20.5188 18.5188 21.75 17 21.75H7C5.48122 21.75 4.25 20.5188 4.25 19Z",
                    fill: "currentColor"
                }, null, -1)])])
            }]
        ]),
        nu = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const lu = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", nu, [...t[0] || (t[0] = [po("path", {
                    "fill-rule": "evenodd",
                    "clip-rule": "evenodd",
                    d: "M9.32289 2.25003L9.23265 2.25001C8.47304 2.24984 7.96465 2.24972 7.47672 2.36883C7.25578 2.42277 7.03998 2.49476 6.83189 2.58414C6.37 2.78253 5.97535 3.08651 5.39532 3.53329L5.32472 3.58766L5.29273 3.61228C4.24651 4.41768 3.41746 5.0559 2.80797 5.62799C2.1851 6.21262 1.72591 6.7865 1.48506 7.48693C1.28734 8.06193 1.21295 8.66844 1.26722 9.27182C1.33356 10.0094 1.64582 10.6679 2.11451 11.3677C2.57202 12.0509 3.22764 12.8427 4.05236 13.8386L4.05239 13.8387L4.05242 13.8387L8.11023 18.7392L8.11025 18.7392L8.11026 18.7392C8.84673 19.6287 9.45218 20.3599 10.0079 20.8609C10.5914 21.3869 11.2168 21.75 12 21.75C12.7832 21.75 13.4086 21.3869 13.9921 20.8609C14.5478 20.3599 15.1533 19.6287 15.8898 18.7392L19.9476 13.8386C20.7724 12.8427 21.428 12.0509 21.8855 11.3677C22.3542 10.6679 22.6664 10.0094 22.7328 9.27182C22.7871 8.66844 22.7127 8.06193 22.5149 7.48693C22.2741 6.7865 21.8149 6.21262 21.192 5.62799C20.5825 5.05591 19.7535 4.41769 18.7073 3.6123L18.7072 3.61226L18.6753 3.58766L18.6047 3.53329C18.0246 3.08651 17.63 2.78253 17.1681 2.58414C16.96 2.49476 16.7442 2.42277 16.5233 2.36883C16.0353 2.24972 15.527 2.24984 14.7673 2.25001L14.6771 2.25003H9.32289ZM10 7.75C9.58579 7.75 9.25 8.08579 9.25 8.5C9.25 8.91421 9.58579 9.25 10 9.25H14C14.4142 9.25 14.75 8.91421 14.75 8.5C14.75 8.08579 14.4142 7.75 14 7.75H10Z",
                    fill: "currentColor"
                }, null, -1)])])
            }]
        ]),
        ou = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const ru = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", ou, [...t[0] || (t[0] = [po("path", {
                    d: "M17 7V11C17 13.7614 14.7614 16 12 16C9.23858 16 7 13.7614 7 11V7C7 4.23858 9.23858 2 12 2C14.7614 2 17 4.23858 17 7Z",
                    stroke: "currentColor",
                    "stroke-width": "2"
                }, null, -1), po("path", {
                    d: "M20 11C20 15.4183 16.4183 19 12 19M12 19C7.58172 19 4 15.4183 4 11M12 19V22M12 22H15M12 22H9",
                    stroke: "currentColor",
                    "stroke-width": "2",
                    "stroke-linecap": "round"
                }, null, -1)])])
            }]
        ]),
        su = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none",
            class: "scale-110"
        };
    const iu = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", su, [...t[0] || (t[0] = [Co('<path d="M2.5 12C2.5 7.52166 2.5 5.28249 3.89124 3.89124C5.28249 2.5 7.52166 2.5 12 2.5C16.4783 2.5 18.7175 2.5 20.1088 3.89124C21.5 5.28249 21.5 7.52166 21.5 12C21.5 16.4783 21.5 18.7175 20.1088 20.1088C18.7175 21.5 16.4783 21.5 12 21.5C7.52166 21.5 5.28249 21.5 3.89124 20.1088C2.5 18.7175 2.5 16.4783 2.5 12Z" stroke="currentColor" stroke-width="2"></path><path d="M12 8V16" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M9 10V14" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M6 11V13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M15 10V14" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path><path d="M18 11V13" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>', 6)])])
            }]
        ]),
        au = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const cu = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", au, [...t[0] || (t[0] = [po("path", {
                    d: "M13 7C13 9.20914 11.2091 11 9 11C6.79086 11 5 9.20914 5 7C5 4.79086 6.79086 3 9 3C11.2091 3 13 4.79086 13 7Z",
                    stroke: "currentColor",
                    "stroke-width": "2"
                }, null, -1), po("path", {
                    d: "M15 11C17.2091 11 19 9.20914 19 7C19 4.79086 17.2091 3 15 3",
                    stroke: "currentColor",
                    "stroke-width": "2",
                    "stroke-linecap": "round",
                    "stroke-linejoin": "round"
                }, null, -1), po("path", {
                    d: "M11 14H7C4.23858 14 2 16.2386 2 19C2 20.1046 2.89543 21 4 21H14C15.1046 21 16 20.1046 16 19C16 16.2386 13.7614 14 11 14Z",
                    stroke: "currentColor",
                    "stroke-width": "2",
                    "stroke-linejoin": "round"
                }, null, -1), po("path", {
                    d: "M17 14C19.7614 14 22 16.2386 22 19C22 20.1046 21.1046 21 20 21H18.5",
                    stroke: "currentColor",
                    "stroke-width": "2",
                    "stroke-linecap": "round",
                    "stroke-linejoin": "round"
                }, null, -1)])])
            }]
        ]),
        uu = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const du = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", uu, [...t[0] || (t[0] = [po("path", {
                    d: "M16 7C16 9.20914 14.2091 11 12 11C9.79086 11 8 9.20914 8 7C8 4.79086 9.79086 3 12 3C14.2091 3 16 4.79086 16 7Z",
                    stroke: "currentColor",
                    "stroke-width": "2"
                }, null, -1), po("path", {
                    d: "M14 14H10C7.23858 14 5 16.2386 5 19C5 20.1046 5.89543 21 7 21H17C18.1046 21 19 20.1046 19 19C19 16.2386 16.7614 14 14 14Z",
                    stroke: "currentColor",
                    "stroke-width": "2",
                    "stroke-linejoin": "round"
                }, null, -1)])])
            }]
        ]),
        hu = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const fu = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", hu, [...t[0] || (t[0] = [po("path", {
                    d: "M5.78223 4.18192C6.43007 3.68319 6.754 3.43383 7.12788 3.27323C7.29741 3.20041 7.47367 3.14158 7.65459 3.09741C8.0536 3 8.4767 3 9.32289 3H14.6771C15.5233 3 15.9464 3 16.3454 3.09741C16.5263 3.14158 16.7026 3.20041 16.8721 3.27323C17.246 3.43383 17.5699 3.68319 18.2178 4.18192C20.3644 5.83448 21.4378 6.66077 21.8057 7.73078C21.9694 8.20673 22.0305 8.70728 21.9858 9.20461C21.8852 10.3227 21.0379 11.346 19.3433 13.3925L15.3498 18.2153C13.8126 20.0718 13.044 21 12 21C10.956 21 10.1874 20.0718 8.65018 18.2153L4.65671 13.3925C2.96208 11.346 2.11476 10.3227 2.0142 9.20461C1.96947 8.70728 2.03064 8.20673 2.1943 7.73078C2.56224 6.66077 3.63557 5.83448 5.78223 4.18192Z",
                    stroke: "currentColor",
                    "stroke-width": "2"
                }, null, -1), po("path", {
                    d: "M10 8.5H14",
                    stroke: "currentColor",
                    "stroke-width": "2",
                    "stroke-linecap": "round",
                    "stroke-linejoin": "round"
                }, null, -1)])])
            }]
        ]),
        pu = {
            class: "flex items-center justify-end gap-4",
            key: "main"
        },
        mu = {
            class: "font-semibold"
        },
        vu = {
            class: "flex items-center justify-end gap-4",
            key: "voice"
        },
        gu = {
            class: "flex items-center gap-2",
            key: "wanted"
        },
        Cu = {
            class: "flex flex-col items-end text-right gap-2 w-96 min-w-96 max-w-96",
            key: "weapon"
        },
        wu = {
            class: "uppercase text-white/50 text-sm"
        },
        xu = {
            class: "text-right border-r border-white/50 pr-3"
        },
        yu = {
            class: "text-5xl font-semibold"
        },
        bu = {
            class: "text-white/50"
        },
        ku = {
            class: "text-sm rounded-l flex items-center justify-end gap-1 text-white/50"
        },
        _u = vn({
            __name: "index",
            setup(e) {
                const t = zs(),
                    n = xc(),
                    l = Oo(() => {
                        const [e, n] = t.clock, l = e => e.toString().padStart(2, "0");
                        return `${l(e)}:${l(n)}`
                    }),
                    o = Oo(() => t.weapon.ammo.current >= 100 ? "" : t.weapon.ammo.current >= 10 ? "0" : "00"),
                    r = {
                        Microphone: {
                            fill: Kc,
                            line: ru
                        },
                        Radio: {
                            fill: Xc,
                            line: iu
                        },
                        Players: {
                            fill: Yc,
                            line: cu
                        },
                        User: {
                            fill: tu,
                            line: du
                        },
                        Gemstone: {
                            fill: lu,
                            line: fu
                        }
                    },
                    s = e => r[e][
                        ["fill", "line"].includes(n.modes.icon) ? n.modes.icon : "fill"
                    ];
                return (e, r) => (lo(), ao(Er, {
                    name: "top-right",
                    tag: "div",
                    class: "absolute top-10 right-10 flex flex-col items-end gap-6",
                    appear: ""
                }, {
                    default: Xt(() => [po("div", pu, [po("p", mu, W(l.value), 1), (lo(), ao(Hn(xt(n).info), {
                        icon: s("Gemstone"),
                        text: new Intl.NumberFormat("pt-BR").format(xt(t).gemstone)
                    }, null, 8, ["icon", "text"])), xt(t).players > 0 ? (lo(), ao(Hn(xt(n).info), {
                        key: 0,
                        icon: s("Players"),
                        text: xt(t).players
                    }, null, 8, ["icon", "text"])) : wo("", !0), (lo(), ao(Hn(xt(n).info), {
                        icon: s("User"),
                        text: new Intl.NumberFormat("pt-BR").format(xt(t).id)
                    }, null, 8, ["icon", "text"]))]), po("div", vu, [(lo(), ao(Hn(xt(n).info), {
                        icon: s("Microphone"),
                        active: xt(t).voice.isTalking,
                        "icon-lg": "",
                        title: "Microfone",
                        text: xt(t).voice.distance
                    }, null, 8, ["icon", "active", "text"])), mo(Qo, {
                        name: "fade-right",
                        appear: ""
                    }, {
                        default: Xt(() => [null !== xt(t).radio ? (lo(), ao(Hn(xt(n).info), {
                            key: 0,
                            icon: s("Radio"),
                            "icon-lg": "",
                            title: "Rádio",
                            text: xt(t).radio
                        }, null, 8, ["icon", "text"])) : wo("", !0)]),
                        _: 1
                    })]), po("div", gu, [(lo(), io(Xl, null, Rn(5, e => mo(Bc, {
                        key: e,
                        class: R(["size-6", xt(t).wantedLevel <= 0 || xt(t).wantedLevel < 5 - e ? "text-white/20" : ""])
                    }, null, 8, ["class"])), 64))]), xt(t).weapon.display ? (lo(), io("div", Cu, [po("p", wu, W(xt(t).weapon.name), 1), po("div", xu, [po("p", yu, [po("span", bu, W(o.value), 1), po("span", null, W(xt(t).weapon.ammo.current), 1)]), po("div", ku, [go(W(xt(t).weapon.ammo.stored) + " ", 1), mo(jc, {
                        class: "w-3 h-3"
                    })])])])) : wo("", !0), mo(Gc, {
                        key: "killfeed"
                    })]),
                    _: 1
                }))
            }
        }),
        Mu = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const Lu = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", Mu, [...t[0] || (t[0] = [po("path", {
                    d: "M19.4189 15.6602C21.1899 13.624 22.75 11.153 22.75 8.69434C22.7499 5.45202 20.3484 2.75 17 2.75C15.4082 2.75 13.8662 3.26268 12 4.96484C10.1338 3.26268 8.59184 2.75 7 2.75C3.65156 2.75 1.25005 5.45202 1.25 8.69434C1.25 11.153 2.8101 13.624 4.58105 15.6602C6.37954 17.7279 8.5291 19.4969 9.96191 20.5684L10.1943 20.7285C11.3812 21.4741 12.8985 21.4204 14.0381 20.5684L14.6074 20.1348C16.0032 19.05 17.8453 17.4694 19.4189 15.6602Z",
                    fill: "currentColor"
                }, null, -1)])])
            }]
        ]),
        Su = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const Vu = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", Su, [...t[0] || (t[0] = [po("path", {
                    d: "M14.1699 22.1006C16.8466 20.7234 21.7499 17.3739 21.75 11.2373V7.74805C21.75 6.40064 21.7719 5.46059 21.1885 4.51855C20.6144 3.59166 19.9634 3.2822 19.043 2.82422C17.04 1.82765 14.6089 1.25 12 1.25C9.39104 1.25 6.95999 1.82764 4.95702 2.82422C4.03654 3.2822 3.38562 3.59166 2.81151 4.51855C2.22802 5.46059 2.24998 6.40064 2.24999 7.74805V11.2373C2.25012 17.3739 7.15334 20.7234 9.83006 22.1006L9.86676 22.1195C10.5845 22.4889 11.0919 22.75 12 22.75C12.9081 22.75 13.4154 22.4889 14.1332 22.1195L14.1699 22.1006Z",
                    fill: "currentColor"
                }, null, -1)])])
            }]
        ]),
        zu = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const Zu = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", zu, [...t[0] || (t[0] = [po("path", {
                    d: "M12.0063 3.15156C14.6502 0.507672 18.4235 0.726822 20.8482 3.15156C22.7739 5.07725 23.3245 7.87106 22.0971 10.2882C21.9799 10.5189 21.7521 10.6729 21.4944 10.6957C21.2367 10.7185 20.9854 10.6068 20.8296 10.4003C20.198 9.56297 19.1635 9.43156 18.288 9.84027C17.4218 10.2447 16.8633 11.1073 17.1325 12.1721C17.202 12.4474 17.1102 12.7383 16.8953 12.9237C16.6804 13.1092 16.3792 13.1574 16.1171 13.0483C15.6805 12.8666 15.2709 13.0306 15.0143 13.4013C14.7505 13.7822 14.7473 14.2382 15.0378 14.5643C15.1999 14.7462 15.2635 14.9956 15.2083 15.2329C15.1532 15.4702 14.9862 15.666 14.7605 15.7578C13.5339 16.2571 12.2688 16.6297 11.1396 16.7257C10.0343 16.8196 8.89174 16.6603 8.11564 15.8842C7.34649 15.115 7.1833 13.9858 7.27154 12.8916C7.36161 11.7745 7.72483 10.523 8.21442 9.3073C9.18965 6.8857 10.7481 4.40974 12.0063 3.15156Z",
                    fill: "currentColor"
                }, null, -1), po("path", {
                    d: "M6.08798 15.431C6.03426 15.2878 6.00741 15.2162 5.9541 15.2046C5.90079 15.1931 5.84845 15.2454 5.74378 15.3501L4.92977 16.1641C4.87655 16.2173 4.84994 16.2439 4.81715 16.2487C4.78436 16.2535 4.74907 16.2345 4.67849 16.1965C3.81094 15.7286 2.6773 15.8341 1.92789 16.5835C1.02375 17.4877 1.02375 18.9536 1.9279 19.8577C2.28582 20.2156 2.76513 20.459 3.27045 20.5463C3.34867 20.5598 3.38778 20.5665 3.41022 20.5889C3.43265 20.6114 3.4394 20.6505 3.45291 20.7287C3.54013 21.234 3.78351 21.7133 4.14143 22.0713C5.04558 22.9754 6.51149 22.9754 7.41563 22.0713C8.16503 21.3219 8.27058 20.1882 7.8027 19.3207C7.76464 19.2501 7.74561 19.2148 7.75041 19.182C7.75521 19.1492 7.78182 19.1226 7.83505 19.0694L8.64921 18.2552C8.7539 18.1505 8.80624 18.0982 8.7947 18.0449C8.78315 17.9916 8.71153 17.9647 8.56831 17.911C8.03155 17.7097 7.51211 17.4017 7.05455 16.9442C6.5971 16.4867 6.2892 15.9674 6.08798 15.431Z",
                    fill: "currentColor"
                }, null, -1)])])
            }]
        ]),
        ju = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const $u = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", ju, [...t[0] || (t[0] = [po("path", {
                    "fill-rule": "evenodd",
                    "clip-rule": "evenodd",
                    d: "M14.9223 2.42838C13.2679 0.857205 10.7321 0.857205 9.07766 2.42838C7.79766 3.64397 6.22927 5.31956 4.97628 7.24155C3.72892 9.1549 2.75 11.3797 2.75 13.678C2.75 18.1459 6.25744 22.75 12 22.75C17.7426 22.75 21.25 18.1459 21.25 13.678C21.25 11.3797 20.2711 9.15491 19.0237 7.24155C17.7707 5.31956 16.2023 3.64397 14.9223 2.42838ZM15 13.9999C15 15.6568 13.6569 16.9999 12 16.9999C11.4477 16.9999 11 17.4477 11 17.9999C11 18.5522 11.4477 18.9999 12 18.9999C14.7614 18.9999 17 16.7614 17 13.9999C17 13.4477 16.5523 12.9999 16 12.9999C15.4477 12.9999 15 13.4477 15 13.9999Z",
                    fill: "currentColor"
                }, null, -1)])])
            }]
        ]),
        Bu = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const Eu = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", Bu, [...t[0] || (t[0] = [po("path", {
                    d: "M16.0174 2.32514C16.5423 2.40348 17.1136 2.59299 17.4412 3.16038C17.7679 3.72637 17.6485 4.31617 17.4564 4.81136C17.2716 5.2879 16.9439 5.86433 16.5622 6.53565L15.4612 8.47252C15.253 8.8388 15.1189 9.07576 15.0336 9.25737C14.9695 9.39366 14.9577 9.4495 14.9558 9.45874C14.9591 9.56981 15.0177 9.67007 15.109 9.7266C15.1189 9.72978 15.173 9.74649 15.3181 9.75782C15.5168 9.77336 15.8183 9.7739 16.2381 9.7739C16.7269 9.77389 17.137 9.77388 17.4569 9.79838C17.7661 9.82206 18.1304 9.87463 18.4357 10.0776C19.0285 10.4716 19.3368 11.1749 19.2287 11.8773C19.173 12.2386 18.968 12.5434 18.7774 12.7893C18.5804 13.0435 18.3047 13.3484 17.9758 13.7121L12.3841 19.8952C11.8712 20.4625 11.4394 20.94 11.0881 21.2463C10.9095 21.402 10.6984 21.5621 10.463 21.6576C10.2036 21.7629 9.86139 21.8076 9.52149 21.6305C9.18235 21.4538 9.02299 21.1486 8.9596 20.8774C8.90187 20.6304 8.91024 20.3659 8.93387 20.1296C8.98034 19.6648 9.11958 19.035 9.28511 18.2864L9.98337 15.1277C10.1219 14.5012 10.2064 14.1103 10.228 13.8242C10.2577 13.5884 10.052 13.4872 9.94542 13.4662C9.6639 13.4254 9.267 13.4236 8.62816 13.4236L8.1121 13.4236C7.41921 13.4236 6.81605 13.4237 6.34997 13.3543C5.85689 13.2808 5.32903 13.1044 4.99753 12.5916C4.66682 12.0801 4.72084 11.5262 4.85378 11.0454C4.97975 10.5899 5.22449 10.0364 5.50617 9.39944L7.35643 5.21448L7.35643 5.21448C7.617 4.62508 7.83611 4.12946 8.05957 3.74142C8.2964 3.33017 8.57004 2.98046 8.9698 2.71931C9.36982 2.45798 9.79964 2.34835 10.2707 2.2977C10.7147 2.24997 11.2547 2.24998 11.896 2.25L14.0837 2.25C14.8523 2.24995 15.5134 2.24991 16.0174 2.32514Z",
                    fill: "currentColor"
                }, null, -1)])])
            }]
        ]),
        Pu = {
            xmlns: "http://www.w3.org/2000/svg",
            width: "24",
            height: "24",
            viewBox: "0 0 24 24",
            fill: "none",
            "fill-rule": "evenodd"
        };
    const Tu = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", Pu, [...t[0] || (t[0] = [po("path", {
                    fill: "currentColor",
                    d: "m12.707 13.293 3.379 3.379A3.121 3.121 0 0 1 13.879 22h-.201A3.306 3.306 0 0 1 12 21.546a3.306 3.306 0 0 1-1.678.454h-.2a3.121 3.121 0 0 1-2.208-5.328l3.379-3.38a1 1 0 0 1 1.414 0ZM18.88 7a3.121 3.121 0 0 1 3.116 2.944l.005.177v.201c0 .615-.166 1.188-.454 1.678.252.429.41.921.446 1.45l.008.228v.2a3.121 3.121 0 0 1-5.178 2.349l-.15-.141-3.38-3.379a1 1 0 0 1-.082-1.32l.083-.094 3.379-3.379A3.121 3.121 0 0 1 18.879 7ZM5.12 7c.76 0 1.49.276 2.057.773l.15.141 3.38 3.379a1 1 0 0 1 .082 1.32l-.083.094-3.379 3.379a3.122 3.122 0 0 1-5.323-2.03L2 13.879v-.201c0-.615.167-1.188.454-1.678a3.3 3.3 0 0 1-.446-1.45L2 10.323v-.2A3.121 3.121 0 0 1 5.121 7Zm5.201-5c.615 0 1.188.167 1.678.454a3.3 3.3 0 0 1 1.45-.446L13.677 2h.2a3.121 3.121 0 0 1 2.349 5.178l-.141.15-3.379 3.38a1 1 0 0 1-1.32.082l-.094-.083-3.379-3.379a3.121 3.121 0 0 1 2.03-5.323L10.121 2h.201Z"
                }, null, -1)])])
            }]
        ]),
        Fu = {
            width: "14",
            height: "14",
            viewBox: "0 0 14 14",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg"
        };
    const Au = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", Fu, [...t[0] || (t[0] = [po("path", {
                    d: "M12.25 7C12.25 4.10156 9.89844 1.75 7 1.75C4.10156 1.75 1.75 4.10156 1.75 7C1.75 9.89844 4.10156 12.25 7 12.25C9.89844 12.25 12.25 9.89844 12.25 7ZM14 7C14 10.8664 10.8664 14 7 14C3.13359 14 0 10.8664 0 7C0 3.13359 3.13359 0 7 0C10.8664 0 14 3.13359 14 7ZM7 9.1875C8.20859 9.1875 9.1875 8.20859 9.1875 7C9.1875 5.79141 8.20859 4.8125 7 4.8125C5.79141 4.8125 4.8125 5.79141 4.8125 7C4.8125 8.20859 5.79141 9.1875 7 9.1875ZM7 10.9375C4.82617 10.9375 3.0625 9.17383 3.0625 7C3.0625 4.82617 4.82617 3.0625 7 3.0625C9.17383 3.0625 10.9375 4.82617 10.9375 7C10.9375 9.17383 9.17383 10.9375 7 10.9375ZM7.875 7C7.875 7.48398 7.48398 7.875 7 7.875C6.51602 7.875 6.125 7.48398 6.125 7C6.125 6.51602 6.51602 6.125 7 6.125C7.48398 6.125 7.875 6.51602 7.875 7Z",
                    fill: "currentColor"
                }, null, -1)])])
            }]
        ]),
        Ou = {
            width: "14",
            height: "16",
            viewBox: "0 0 14 16",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg"
        };
    const Hu = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", Ou, [...t[0] || (t[0] = [po("path", {
                    d: "M5.56397 1C5.56397 0.446875 5.99179 0 6.52132 0H7.47868C8.00821 0 8.43603 0.446875 8.43603 1V5.40312L12.0859 3.20312C12.5437 2.92812 13.1301 3.09062 13.3933 3.56875L13.872 4.43437C14.1353 4.9125 13.9797 5.525 13.522 5.8L9.87206 8L13.522 10.2C13.9797 10.475 14.1353 11.0875 13.872 11.5656L13.3933 12.4312C13.1301 12.9094 12.5437 13.075 12.0859 12.7969L8.43603 10.5969V15C8.43603 15.5531 8.00821 16 7.47868 16H6.52132C5.99179 16 5.56397 15.5531 5.56397 15V10.5969L1.91406 12.8C1.45633 13.075 0.869946 12.9125 0.606674 12.4344L0.127997 11.5688C-0.135275 11.0906 0.020295 10.4781 0.47803 10.2031L4.12794 8L0.47803 5.8C0.020295 5.525 -0.135275 4.9125 0.127997 4.43437L0.606674 3.56875C0.869946 3.0875 1.45633 2.925 1.91406 3.2L5.56397 5.4V1Z",
                    fill: "currentColor"
                }, null, -1)])])
            }]
        ]),
        Iu = {
            class: "mt-4 flex-1 overflow-hidden effect-at-middle relative"
        },
        Ru = {
            class: "-rotate-3 h-full flex flex-col items-center justify-center gap-4"
        },
        Nu = {
            class: "relative w-full flex items-center gap-[1.45rem] animate-statusbar1"
        },
        Du = {
            class: "relative w-full flex items-center gap-[1.45rem] animate-statusbar2"
        },
        Uu = {
            class: "relative w-full flex items-center gap-[1.45rem] animate-statusbar3"
        },
        Wu = vn({
            __name: "Status",
            setup(e) {
                const t = xc();
                return (e, n) => (lo(), io("div", {
                    class: "border border-white/15 rounded-lg p-6 flex flex-col items-stretch hover:bg-white/5 transition-colors cursor-pointer",
                    onClick: n[0] || (n[0] = e => xt(t).menu.option = "status")
                }, [n[1] || (n[1] = po("h2", {
                    class: "text-2xl font-bold"
                }, "Barra de status", -1)), n[2] || (n[2] = po("p", {
                    class: "text-white/50"
                }, "Selecione o estilo da barra de status", -1)), po("div", Iu, [po("div", Ru, [po("div", Nu, [mo(da, {
                    icon: Lu,
                    color: "health",
                    percentage: 50
                }), mo(da, {
                    icon: Vu,
                    color: "armor",
                    percentage: 50
                }), mo(da, {
                    icon: Zu,
                    color: "hunger",
                    percentage: 50
                }), mo(da, {
                    icon: $u,
                    color: "thirst",
                    percentage: 50
                }), mo(da, {
                    icon: Eu,
                    color: "stress",
                    percentage: 50
                }), mo(da, {
                    icon: Tu,
                    color: "luck",
                    percentage: 50
                }), mo(da, {
                    icon: Au,
                    color: "dexterity",
                    percentage: 50
                }), mo(da, {
                    icon: Hu,
                    color: "repose",
                    percentage: 50
                }), mo(da, {
                    icon: Lu,
                    color: "health",
                    percentage: 50
                }), mo(da, {
                    icon: Vu,
                    color: "armor",
                    percentage: 50
                }), mo(da, {
                    icon: Zu,
                    color: "hunger",
                    percentage: 50
                }), mo(da, {
                    icon: $u,
                    color: "thirst",
                    percentage: 50
                }), mo(da, {
                    icon: Eu,
                    color: "stress",
                    percentage: 50
                }), mo(da, {
                    icon: Tu,
                    color: "luck",
                    percentage: 50
                }), mo(da, {
                    icon: Au,
                    color: "dexterity",
                    percentage: 50
                }), mo(da, {
                    icon: Hu,
                    color: "repose",
                    percentage: 50
                })]), po("div", Du, [mo(La, {
                    icon: Lu,
                    color: "health",
                    percentage: 50
                }), mo(La, {
                    icon: Vu,
                    color: "armor",
                    percentage: 50
                }), mo(La, {
                    icon: Zu,
                    color: "hunger",
                    percentage: 50
                }), mo(La, {
                    icon: $u,
                    color: "thirst",
                    percentage: 50
                }), mo(La, {
                    icon: Eu,
                    color: "stress",
                    percentage: 50
                }), mo(La, {
                    icon: Tu,
                    color: "luck",
                    percentage: 50
                }), mo(La, {
                    icon: Au,
                    color: "dexterity",
                    percentage: 50
                }), mo(La, {
                    icon: Hu,
                    color: "repose",
                    percentage: 50
                }), mo(La, {
                    icon: Lu,
                    color: "health",
                    percentage: 50
                }), mo(La, {
                    icon: Vu,
                    color: "armor",
                    percentage: 50
                }), mo(La, {
                    icon: Zu,
                    color: "hunger",
                    percentage: 50
                }), mo(La, {
                    icon: $u,
                    color: "thirst",
                    percentage: 50
                }), mo(La, {
                    icon: Eu,
                    color: "stress",
                    percentage: 50
                }), mo(La, {
                    icon: Tu,
                    color: "luck",
                    percentage: 50
                }), mo(La, {
                    icon: Au,
                    color: "dexterity",
                    percentage: 50
                }), mo(La, {
                    icon: Hu,
                    color: "repose",
                    percentage: 50
                })]), po("div", Uu, [mo(Na, {
                    icon: Lu,
                    color: "health",
                    percentage: 50
                }), mo(Na, {
                    icon: Vu,
                    color: "armor",
                    percentage: 50
                }), mo(Na, {
                    icon: Zu,
                    color: "hunger",
                    percentage: 50
                }), mo(Na, {
                    icon: $u,
                    color: "thirst",
                    percentage: 50
                }), mo(Na, {
                    icon: Eu,
                    color: "stress",
                    percentage: 50
                }), mo(Na, {
                    icon: Tu,
                    color: "luck",
                    percentage: 50
                }), mo(Na, {
                    icon: Au,
                    color: "dexterity",
                    percentage: 50
                }), mo(Na, {
                    icon: Hu,
                    color: "repose",
                    percentage: 50
                }), mo(Na, {
                    icon: Lu,
                    color: "health",
                    percentage: 50
                }), mo(Na, {
                    icon: Vu,
                    color: "armor",
                    percentage: 50
                }), mo(Na, {
                    icon: Zu,
                    color: "hunger",
                    percentage: 50
                }), mo(Na, {
                    icon: $u,
                    color: "thirst",
                    percentage: 50
                }), mo(Na, {
                    icon: Eu,
                    color: "stress",
                    percentage: 50
                }), mo(Na, {
                    icon: Tu,
                    color: "luck",
                    percentage: 50
                }), mo(Na, {
                    icon: Au,
                    color: "dexterity",
                    percentage: 50
                }), mo(Na, {
                    icon: Hu,
                    color: "repose",
                    percentage: 50
                })])])])]))
            }
        }),
        Gu = {
            class: "mt-4 flex-1 overflow-hidden effect-at-middle relative"
        },
        qu = {
            class: "-rotate-3 h-full flex flex-col items-center justify-center gap-14"
        },
        Ku = {
            class: "relative w-full flex items-center gap-[1.45rem] animate-infobar1"
        },
        Ju = {
            class: "relative w-full flex items-center gap-[1.45rem] animate-infobar2"
        },
        Xu = {
            class: "relative w-full flex items-center gap-[1.45rem] animate-infobar3"
        },
        Qu = vn({
            __name: "Info",
            setup(e) {
                const t = xc();
                return (e, n) => (lo(), io("div", {
                    class: "border border-white/15 rounded-lg p-6 flex flex-col items-stretch hover:bg-white/5 transition-colors cursor-pointer",
                    onClick: n[0] || (n[0] = e => xt(t).menu.option = "info")
                }, [n[1] || (n[1] = po("h2", {
                    class: "text-2xl font-bold"
                }, "Informações", -1)), n[2] || (n[2] = po("p", {
                    class: "text-white/50"
                }, "Selecione o estilo das informações", -1)), po("div", Gu, [po("div", qu, [po("div", Ku, [mo(xs, {
                    icon: lu,
                    text: "123.456"
                }), mo(xs, {
                    icon: Yc,
                    text: "123"
                }), mo(xs, {
                    icon: tu,
                    text: "1234"
                }), mo(xs, {
                    icon: Kc,
                    "icon-lg": "",
                    text: "Normal",
                    title: "Microfone"
                }), mo(xs, {
                    icon: Xc,
                    "icon-lg": "",
                    text: "123 Mhz",
                    title: "Rádio"
                }), mo(xs, {
                    icon: lu,
                    text: "123.456"
                }), mo(xs, {
                    icon: Yc,
                    text: "123"
                }), mo(xs, {
                    icon: tu,
                    text: "1234"
                }), mo(xs, {
                    icon: Kc,
                    "icon-lg": "",
                    text: "Normal",
                    title: "Microfone"
                }), mo(xs, {
                    icon: Xc,
                    "icon-lg": "",
                    text: "123 Mhz",
                    title: "Rádio"
                })]), po("div", Ju, [mo(Ls, {
                    icon: lu,
                    text: "123.456"
                }), mo(Ls, {
                    icon: Yc,
                    text: "123"
                }), mo(Ls, {
                    icon: tu,
                    text: "1234"
                }), mo(Ls, {
                    icon: Kc,
                    "icon-lg": "",
                    text: "Normal",
                    title: "Microfone"
                }), mo(Ls, {
                    icon: Xc,
                    "icon-lg": "",
                    text: "123 Mhz",
                    title: "Rádio"
                }), mo(Ls, {
                    icon: lu,
                    text: "123.456"
                }), mo(Ls, {
                    icon: Yc,
                    text: "123"
                }), mo(Ls, {
                    icon: tu,
                    text: "1234"
                }), mo(Ls, {
                    icon: Kc,
                    "icon-lg": "",
                    text: "Normal",
                    title: "Microfone"
                }), mo(Ls, {
                    icon: Xc,
                    "icon-lg": "",
                    text: "123 Mhz",
                    title: "Rádio"
                })]), po("div", Xu, [mo(Vs, {
                    icon: lu,
                    text: "123.456"
                }), mo(Vs, {
                    icon: Yc,
                    text: "123"
                }), mo(Vs, {
                    icon: tu,
                    text: "1234"
                }), mo(Vs, {
                    icon: Kc,
                    "icon-lg": "",
                    text: "Normal",
                    title: "Microfone"
                }), mo(Vs, {
                    icon: Xc,
                    "icon-lg": "",
                    text: "123 Mhz",
                    title: "Rádio"
                }), mo(Vs, {
                    icon: lu,
                    text: "123.456"
                }), mo(Vs, {
                    icon: Yc,
                    text: "123"
                }), mo(Vs, {
                    icon: tu,
                    text: "1234"
                }), mo(Vs, {
                    icon: Kc,
                    "icon-lg": "",
                    text: "Normal",
                    title: "Microfone"
                }), mo(Vs, {
                    icon: Xc,
                    "icon-lg": "",
                    text: "123 Mhz",
                    title: "Rádio"
                })])])])]))
            }
        }),
        Yu = {
            class: "mt-4 flex-1 overflow-hidden effect-at-middle relative"
        },
        ed = {
            class: "-rotate-3 h-full flex flex-col items-center justify-center gap-4"
        },
        td = {
            class: "relative w-full flex items-center gap-4 animate-vehicle"
        },
        nd = {
            class: "flex items-center gap-4"
        },
        ld = {
            class: "flex flex-col items-end gap-6"
        },
        od = {
            class: "flex items-center gap-4"
        },
        rd = {
            class: "flex flex-col items-end gap-6"
        },
        sd = vn({
            __name: "Vehicle",
            setup(e) {
                const t = xc(),
                    n = {
                        speed: 55,
                        rpm: .45,
                        fuel: 50,
                        nitro: 1e3,
                        engine: 800,
                        doors: !0,
                        seatbelt: !0
                    };
                return (e, l) => (lo(), io("div", {
                    class: "border border-white/15 rounded-lg p-6 flex flex-col items-stretch hover:bg-white/5 transition-colors cursor-pointer",
                    onClick: l[0] || (l[0] = e => xt(t).menu.option = "vehicle")
                }, [l[1] || (l[1] = po("h2", {
                    class: "text-2xl font-bold"
                }, "Velocímetro", -1)), l[2] || (l[2] = po("p", {
                    class: "text-white/50"
                }, "Selecione o estilo do velocímetro", -1)), po("div", Yu, [po("div", ed, [po("div", td, [po("div", nd, [mo(ki, {
                    vehicle: n
                }), po("div", ld, [mo(Hi, {
                    vehicle: n
                }), mo(na, {
                    vehicle: n
                })])]), po("div", od, [mo(ki, {
                    vehicle: n
                }), po("div", rd, [mo(Hi, {
                    vehicle: n
                }), mo(na, {
                    vehicle: n
                })])])])])])]))
            }
        }),
        id = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const ad = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", id, [...t[0] || (t[0] = [po("path", {
                    d: "M10.4107 19.9677C7.58942 17.858 2 13.0348 2 8.69444C2 5.82563 4.10526 3.5 7 3.5C8.5 3.5 10 4 12 6C14 4 15.5 3.5 17 3.5C19.8947 3.5 22 5.82563 22 8.69444C22 13.0348 16.4106 17.858 13.5893 19.9677C12.6399 20.6776 11.3601 20.6776 10.4107 19.9677Z",
                    stroke: "currentColor",
                    "stroke-width": "2",
                    "stroke-linecap": "round",
                    "stroke-linejoin": "round"
                }, null, -1)])])
            }]
        ]),
        cd = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const ud = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", cd, [...t[0] || (t[0] = [po("path", {
                    d: "M18.7088 3.49534C16.8165 2.55382 14.5009 2 12 2C9.4991 2 7.1835 2.55382 5.29116 3.49534C4.36318 3.95706 3.89919 4.18792 3.4496 4.91378C3 5.63965 3 6.34248 3 7.74814V11.2371C3 16.9205 7.54236 20.0804 10.173 21.4338C10.9067 21.8113 11.2735 22 12 22C12.7265 22 13.0933 21.8113 13.8269 21.4338C16.4576 20.0804 21 16.9205 21 11.2371L21 7.74814C21 6.34249 21 5.63966 20.5504 4.91378C20.1008 4.18791 19.6368 3.95706 18.7088 3.49534Z",
                    stroke: "currentColor",
                    "stroke-width": "2",
                    "stroke-linecap": "round",
                    "stroke-linejoin": "round"
                }, null, -1)])])
            }]
        ]),
        dd = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const hd = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", dd, [...t[0] || (t[0] = [po("path", {
                    d: "M10 15.8446L6.68575 19.1589C7.45757 19.7089 7.56154 20.8655 6.88551 21.5416C6.27426 22.1528 5.28323 22.1528 4.67198 21.5416C4.19008 21.0597 4.02512 20.2787 4.30305 19.6969C3.72125 19.9749 2.94033 19.8099 2.45844 19.328C1.84719 18.7168 1.84719 17.7257 2.45844 17.1145C3.13447 16.4385 4.29108 16.5424 4.84114 17.3142L8.15538 14",
                    stroke: "currentColor",
                    "stroke-width": "2",
                    "stroke-linejoin": "round"
                }, null, -1), po("path", {
                    d: "M12.5368 3.68189C14.8712 1.34751 18.1694 1.53315 20.3181 3.68189C22.033 5.39675 22.4975 7.8437 21.4285 9.94858C19.6533 7.59535 15.6579 9.39829 16.4055 12.3559C14.7572 11.6697 13.3426 13.7886 14.478 15.0632C12.0982 16.0318 9.73049 16.4381 8.64618 15.3538C6.49743 13.2051 10.2024 6.01628 12.5368 3.68189Z",
                    stroke: "currentColor",
                    "stroke-width": "2",
                    "stroke-linejoin": "round"
                }, null, -1)])])
            }]
        ]),
        fd = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const pd = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", fd, [...t[0] || (t[0] = [po("path", {
                    d: "M3.5 13.678C3.5 9.49387 7.08079 5.35907 9.59413 2.97222C10.9591 1.67593 13.0409 1.67593 14.4059 2.97222C16.9192 5.35907 20.5 9.49387 20.5 13.678C20.5 17.7804 17.2812 22 12 22C6.71878 22 3.5 17.7804 3.5 13.678Z",
                    stroke: "currentColor",
                    "stroke-width": "2"
                }, null, -1), po("path", {
                    d: "M16 14C16 16.2091 14.2091 18 12 18",
                    stroke: "currentColor",
                    "stroke-width": "2",
                    "stroke-linecap": "round",
                    "stroke-linejoin": "round"
                }, null, -1)])])
            }]
        ]),
        md = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const vd = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", md, [...t[0] || (t[0] = [po("path", {
                    d: "M8.62814 12.6736H8.16918C6.68545 12.6736 5.94358 12.6736 5.62736 12.1844C5.31114 11.6953 5.61244 11.0138 6.21504 9.65083L8.02668 5.55323C8.57457 4.314 8.84852 3.69438 9.37997 3.34719C9.91142 3 10.5859 3 11.935 3H14.0244C15.6632 3 16.4826 3 16.7916 3.53535C17.1007 4.0707 16.6942 4.78588 15.8811 6.21623L14.8092 8.10188C14.405 8.81295 14.2029 9.16849 14.2057 9.45952C14.2094 9.83775 14.4105 10.1862 14.7354 10.377C14.9854 10.5239 15.3927 10.5239 16.2074 10.5239C17.2373 10.5239 17.7523 10.5239 18.0205 10.7022C18.3689 10.9338 18.5513 11.3482 18.4874 11.7632C18.4382 12.0826 18.0918 12.4656 17.399 13.2317L11.8639 19.3523C10.7767 20.5545 10.2331 21.1556 9.86807 20.9654C9.50303 20.7751 9.67833 19.9822 10.0289 18.3962L10.7157 15.2896C10.9826 14.082 11.1161 13.4782 10.7951 13.0759C10.4741 12.6736 9.85877 12.6736 8.62814 12.6736Z",
                    stroke: "currentColor",
                    "stroke-width": "2",
                    "stroke-linejoin": "round"
                }, null, -1)])])
            }]
        ]),
        gd = {
            xmlns: "http://www.w3.org/2000/svg",
            width: "24",
            height: "24",
            viewBox: "0 0 22 22",
            fill: "none",
            "fill-rule": "evenodd",
            class: "scale-110"
        };
    const Cd = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", gd, [...t[0] || (t[0] = [po("path", {
                    fill: "currentColor",
                    d: "m12.88,3c.62,0,1.12.5,1.12,1.12,0,.26-.09.52-.26.72l-.09.1-2.65,2.65-2.67-2.67c-.44-.44-.44-1.15,0-1.59.19-.19.44-.3.71-.33h.11s.17,0,.17,0c.24,0,.46.06.67.18.31.18.66.27,1.01.27s.7-.09,1.01-.27c.17-.1.35-.16.55-.17h.15s.16,0,.16,0h0m5,5c.59,0,1.07.45,1.12,1.04v.11s0,.17,0,.17c0,.24-.06.46-.18.66-.37.63-.37,1.4,0,2.03.1.17.16.35.17.55v.15s0,.17,0,.17c0,.62-.5,1.12-1.12,1.12-.26,0-.52-.09-.72-.26l-.1-.09-2.65-2.65,2.67-2.67c.21-.21.49-.33.79-.33h0m-13.76,0c.26,0,.52.09.72.26l.1.09,2.65,2.65-2.67,2.67c-.21.21-.49.33-.79.33s-.58-.12-.79-.33c-.19-.19-.3-.44-.32-.71v-.09s0-.2,0-.2c0-.24.06-.46.18-.67.37-.62.37-1.4,0-2.02-.1-.17-.16-.36-.17-.55v-.15s0-.17,0-.17c0-.62.5-1.12,1.12-1.12m7.59,5.71h0,0m-.71.71l2.67,2.67c.44.44.44,1.15,0,1.59-.21.21-.49.33-.79.33h-.21c-.23,0-.46-.06-.66-.18-.31-.18-.66-.27-1.01-.27s-.7.09-1.01.27c-.2.12-.43.18-.67.18h-.2c-.62,0-1.12-.5-1.12-1.12,0-.3.12-.58.33-.79l2.67-2.67M12.88,1s0,0,0,0h-.43c-.51.04-1.01.19-1.45.45-.49-.29-1.06-.45-1.68-.45h0-.38c-.77.05-1.49.37-2.03.91-1.22,1.22-1.22,3.2,0,4.41l3.38,3.38.09.08c.18.14.4.21.61.21.26,0,.51-.1.71-.29l3.38-3.38.14-.15c.5-.57.77-1.3.77-2.06,0-1.72-1.4-3.12-3.12-3.12h0Zm5,5h0c-.83,0-1.62.33-2.21.91l-3.38,3.38-.08.09c-.31.4-.27.96.08,1.32l3.38,3.38.15.14c.57.5,1.3.77,2.06.77h0c1.72,0,3.12-1.4,3.12-3.12v-.43c-.04-.53-.2-1.02-.45-1.45.29-.49.45-1.06.45-1.68v-.38c-.1-1.65-1.47-2.94-3.12-2.94h0Zm-13.76,0h0c-1.72,0-3.12,1.4-3.12,3.12v.43c.04.51.19,1.01.45,1.45-.29.49-.45,1.06-.45,1.68v.38c.05.76.37,1.49.91,2.03.61.61,1.41.92,2.21.92s1.6-.3,2.21-.91l3.38-3.38.08-.09c.31-.4.27-.96-.08-1.32l-3.38-3.38-.15-.14c-.57-.5-1.3-.77-2.06-.77h0Zm6.88,6c-.26,0-.51.1-.71.29l-3.38,3.38c-.59.59-.91,1.38-.91,2.21,0,1.72,1.4,3.12,3.12,3.12h.2s0,0,0,0c.59,0,1.16-.16,1.67-.45.51.3,1.08.45,1.67.45,0,0,0,0,0,0h.2c.83,0,1.62-.33,2.21-.91,1.22-1.22,1.22-3.19,0-4.41l-3.38-3.38h0c-.2-.2-.45-.29-.71-.29h0Z"
                }, null, -1)])])
            }]
        ]),
        wd = {
            width: "14",
            height: "14",
            viewBox: "0 0 14 14",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg"
        };
    const xd = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", wd, [...t[0] || (t[0] = [po("path", {
                    d: "M12.25 7C12.25 4.10156 9.89844 1.75 7 1.75C4.10156 1.75 1.75 4.10156 1.75 7C1.75 9.89844 4.10156 12.25 7 12.25C9.89844 12.25 12.25 9.89844 12.25 7ZM14 7C14 10.8664 10.8664 14 7 14C3.13359 14 0 10.8664 0 7C0 3.13359 3.13359 0 7 0C10.8664 0 14 3.13359 14 7ZM7 9.1875C8.20859 9.1875 9.1875 8.20859 9.1875 7C9.1875 5.79141 8.20859 4.8125 7 4.8125C5.79141 4.8125 4.8125 5.79141 4.8125 7C4.8125 8.20859 5.79141 9.1875 7 9.1875ZM7 10.9375C4.82617 10.9375 3.0625 9.17383 3.0625 7C3.0625 4.82617 4.82617 3.0625 7 3.0625C9.17383 3.0625 10.9375 4.82617 10.9375 7C10.9375 9.17383 9.17383 10.9375 7 10.9375ZM7.875 7C7.875 7.48398 7.48398 7.875 7 7.875C6.51602 7.875 6.125 7.48398 6.125 7C6.125 6.51602 6.51602 6.125 7 6.125C7.48398 6.125 7.875 6.51602 7.875 7Z",
                    fill: "currentColor"
                }, null, -1)])])
            }]
        ]),
        yd = {
            width: "14",
            height: "16",
            viewBox: "0 0 14 16",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg"
        };
    const bd = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", yd, [...t[0] || (t[0] = [po("path", {
                    d: "M5.56397 1C5.56397 0.446875 5.99179 0 6.52132 0H7.47868C8.00821 0 8.43603 0.446875 8.43603 1V5.40312L12.0859 3.20312C12.5437 2.92812 13.1301 3.09062 13.3933 3.56875L13.872 4.43437C14.1353 4.9125 13.9797 5.525 13.522 5.8L9.87206 8L13.522 10.2C13.9797 10.475 14.1353 11.0875 13.872 11.5656L13.3933 12.4312C13.1301 12.9094 12.5437 13.075 12.0859 12.7969L8.43603 10.5969V15C8.43603 15.5531 8.00821 16 7.47868 16H6.52132C5.99179 16 5.56397 15.5531 5.56397 15V10.5969L1.91406 12.8C1.45633 13.075 0.869946 12.9125 0.606674 12.4344L0.127997 11.5688C-0.135275 11.0906 0.020295 10.4781 0.47803 10.2031L4.12794 8L0.47803 5.8C0.020295 5.525 -0.135275 4.9125 0.127997 4.43437L0.606674 3.56875C0.869946 3.0875 1.45633 2.925 1.91406 3.2L5.56397 5.4V1Z",
                    fill: "currentColor"
                }, null, -1)])])
            }]
        ]),
        kd = {
            class: "mt-4 flex-1 overflow-hidden effect-at-middle relative"
        },
        _d = {
            class: "-rotate-3 h-full flex flex-col items-center justify-center gap-16"
        },
        Md = {
            class: "relative w-full flex items-center gap-[1.45rem] animate-iconbar1"
        },
        Ld = {
            class: "relative size-11"
        },
        Sd = {
            class: "relative size-11"
        },
        Vd = {
            class: "relative size-11"
        },
        zd = {
            class: "relative size-11"
        },
        Zd = {
            class: "relative size-11"
        },
        jd = {
            class: "relative size-11"
        },
        $d = {
            class: "relative size-11"
        },
        Bd = {
            class: "relative size-11"
        },
        Ed = {
            class: "relative size-11"
        },
        Pd = {
            class: "relative size-11"
        },
        Td = {
            class: "relative size-11"
        },
        Fd = {
            class: "relative size-11"
        },
        Ad = {
            class: "relative size-11"
        },
        Od = {
            class: "relative size-11"
        },
        Hd = {
            class: "relative size-11"
        },
        Id = {
            class: "relative size-11"
        },
        Rd = {
            class: "relative size-11"
        },
        Nd = {
            class: "relative size-11"
        },
        Dd = {
            class: "relative size-11"
        },
        Ud = {
            class: "relative size-11"
        },
        Wd = {
            class: "relative w-full flex items-center gap-[1.45rem] animate-iconbar2"
        },
        Gd = {
            class: "relative size-11"
        },
        qd = {
            class: "relative size-11"
        },
        Kd = {
            class: "relative size-11"
        },
        Jd = {
            class: "relative size-11"
        },
        Xd = {
            class: "relative size-11"
        },
        Qd = {
            class: "relative size-11"
        },
        Yd = {
            class: "relative size-11"
        },
        eh = {
            class: "relative size-11"
        },
        th = {
            class: "relative size-11"
        },
        nh = {
            class: "relative size-11"
        },
        lh = {
            class: "relative size-11"
        },
        oh = {
            class: "relative size-11"
        },
        rh = {
            class: "relative size-11"
        },
        sh = {
            class: "relative size-11"
        },
        ih = {
            class: "relative size-11"
        },
        ah = {
            class: "relative size-11"
        },
        ch = {
            class: "relative size-11"
        },
        uh = {
            class: "relative size-11"
        },
        dh = {
            class: "relative size-11"
        },
        hh = {
            class: "relative size-11"
        },
        fh = vn({
            __name: "Icons",
            setup(e) {
                const t = xc();
                return (e, n) => (lo(), io("div", {
                    class: "border border-white/15 rounded-lg p-6 flex flex-col items-stretch hover:bg-white/5 transition-colors cursor-pointer",
                    onClick: n[0] || (n[0] = e => xt(t).menu.option = "icons")
                }, [n[1] || (n[1] = po("h2", {
                    class: "text-2xl font-bold"
                }, "Tipo de Ícones", -1)), n[2] || (n[2] = po("p", {
                    class: "text-white/50"
                }, "Selecione o estilo dos ícones", -1)), po("div", kd, [po("div", _d, [po("div", Md, [po("div", Ld, [mo(Lu, {
                    class: "size-8"
                })]), po("div", Sd, [mo(Vu, {
                    class: "size-8"
                })]), po("div", Vd, [mo(Zu, {
                    class: "size-8"
                })]), po("div", zd, [mo($u, {
                    class: "size-8"
                })]), po("div", Zd, [mo(Eu, {
                    class: "size-8"
                })]), po("div", jd, [mo(Tu, {
                    class: "size-8"
                })]), po("div", $d, [mo(Au, {
                    class: "size-8"
                })]), po("div", Bd, [mo(Hu, {
                    class: "size-8"
                })]), po("div", Ed, [mo(Lu, {
                    class: "size-8"
                })]), po("div", Pd, [mo(Vu, {
                    class: "size-8"
                })]), po("div", Td, [mo(Zu, {
                    class: "size-8"
                })]), po("div", Fd, [mo($u, {
                    class: "size-8"
                })]), po("div", Ad, [mo(Eu, {
                    class: "size-8"
                })]), po("div", Od, [mo(Tu, {
                    class: "size-8"
                })]), po("div", Hd, [mo(Au, {
                    class: "size-8"
                })]), po("div", Id, [mo(Hu, {
                    class: "size-8"
                })]), po("div", Rd, [mo(Lu, {
                    class: "size-8"
                })]), po("div", Nd, [mo(Vu, {
                    class: "size-8"
                })]), po("div", Dd, [mo(Zu, {
                    class: "size-8"
                })]), po("div", Ud, [mo($u, {
                    class: "size-8"
                })])]), po("div", Wd, [po("div", Gd, [mo(ad, {
                    class: "size-8"
                })]), po("div", qd, [mo(ud, {
                    class: "size-8"
                })]), po("div", Kd, [mo(hd, {
                    class: "size-8"
                })]), po("div", Jd, [mo(pd, {
                    class: "size-8"
                })]), po("div", Xd, [mo(vd, {
                    class: "size-8"
                })]), po("div", Qd, [mo(Cd, {
                    class: "size-8"
                })]), po("div", Yd, [mo(xd, {
                    class: "size-8"
                })]), po("div", eh, [mo(bd, {
                    class: "size-8"
                })]), po("div", th, [mo(ad, {
                    class: "size-8"
                })]), po("div", nh, [mo(ud, {
                    class: "size-8"
                })]), po("div", lh, [mo(hd, {
                    class: "size-8"
                })]), po("div", oh, [mo(pd, {
                    class: "size-8"
                })]), po("div", rh, [mo(vd, {
                    class: "size-8"
                })]), po("div", sh, [mo(Cd, {
                    class: "size-8"
                })]), po("div", ih, [mo(xd, {
                    class: "size-8"
                })]), po("div", ah, [mo(bd, {
                    class: "size-8"
                })]), po("div", ch, [mo(ad, {
                    class: "size-8"
                })]), po("div", uh, [mo(ud, {
                    class: "size-8"
                })]), po("div", dh, [mo(hd, {
                    class: "size-8"
                })]), po("div", hh, [mo(pd, {
                    class: "size-8"
                })])])])])]))
            }
        }),
        ph = {
            width: "100%",
            height: "100%",
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg"
        };
    const mh = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", ph, [...t[0] || (t[0] = [po("path", {
                    d: "M15 18L9 12L15 6",
                    stroke: "currentColor",
                    "stroke-width": "2",
                    "stroke-linecap": "round",
                    "stroke-linejoin": "round"
                }, null, -1)])])
            }]
        ]),
        vh = {
            class: "flex items-center gap-4"
        },
        gh = ["onClick"],
        Ch = {
            class: "text-xl font-bold"
        },
        wh = {
            class: "flex items-center gap-4"
        },
        xh = vn({
            __name: "Info",
            setup(e) {
                const t = xc(),
                    n = [xs, Ls, Vs],
                    l = e => n[e],
                    o = {
                        Gemstone: {
                            fill: lu,
                            line: fu
                        },
                        Players: {
                            fill: Yc,
                            line: cu
                        },
                        User: {
                            fill: tu,
                            line: du
                        },
                        Microphone: {
                            fill: Kc,
                            line: ru
                        },
                        Radio: {
                            fill: Xc,
                            line: iu
                        }
                    },
                    r = e => o[e][
                        ["fill", "line"].includes(t.modes.icon) ? t.modes.icon : "fill"
                    ];
                return (e, o) => (lo(), io("div", {
                    class: R(["size-full overflow-hidden overflow-y-auto space-y-4", xt(gs).grayscale ? "scrollbar-custom-grayscale" : "scrollbar-custom"])
                }, [po("div", vh, [po("button", {
                    class: "size-8 text-white/50 hover:text-white transition-colors",
                    onClick: o[0] || (o[0] = e => xt(t).menu.option = "")
                }, [mo(mh, {
                    class: "size-7"
                })]), o[1] || (o[1] = po("div", null, [po("h2", {
                    class: "text-2xl font-bold"
                }, "Informações"), po("p", {
                    class: "text-white/50"
                }, "Selecione o estilo das informações")], -1))]), (lo(), io(Xl, null, Rn(n, (e, n) => po("div", {
                    class: R(["mt-2 rounded-md py-4 px-8 border transition-colors flex items-center justify-between gap-4", xt(t).modes.info == n + 1 ? "border-main bg-main/10" : "border-white/15 hover:bg-white/5 hover:border-white/30 cursor-pointer"]),
                    onClick: e => {
                        return l = n + 1, void(t.modes.info !== l && (localStorage.setItem("hud-info-mode", l.toString()), t.modes.info = l));
                        var l
                    },
                    key: n
                }, [po("div", null, [po("h3", Ch, "Estilo " + W(n + 1), 1), o[2] || (o[2] = po("p", {
                    class: "text-white/50"
                }, "Clique para selecionar esse estilo", -1))]), po("div", wh, [(lo(), ao(Hn(l(n)), {
                    icon: r("Gemstone"),
                    text: "123.456"
                }, null, 8, ["icon"])), (lo(), ao(Hn(l(n)), {
                    icon: r("Players"),
                    text: "123"
                }, null, 8, ["icon"])), (lo(), ao(Hn(l(n)), {
                    icon: r("User"),
                    text: "1234"
                }, null, 8, ["icon"])), (lo(), ao(Hn(l(n)), {
                    icon: r("Microphone"),
                    "icon-lg": "",
                    title: "Microfone",
                    text: "Normal"
                }, null, 8, ["icon"])), (lo(), ao(Hn(l(n)), {
                    icon: r("Radio"),
                    "icon-lg": "",
                    title: "Rádio",
                    text: "123 Mhz"
                }, null, 8, ["icon"]))])], 10, gh)), 64))], 2))
            }
        }),
        yh = {
            class: "flex items-center gap-4"
        },
        bh = ["onClick"],
        kh = {
            class: "text-xl font-bold"
        },
        _h = {
            class: "flex items-center gap-6"
        },
        Mh = vn({
            __name: "Icons",
            setup(e) {
                const t = xc(),
                    n = ["fill", "line"],
                    l = {
                        Health: {
                            fill: Lu,
                            line: ad
                        },
                        Armor: {
                            fill: Vu,
                            line: ud
                        },
                        Hunger: {
                            fill: Zu,
                            line: hd
                        },
                        Thirst: {
                            fill: $u,
                            line: pd
                        },
                        Stress: {
                            fill: Eu,
                            line: vd
                        },
                        Luck: {
                            fill: Tu,
                            line: Cd
                        },
                        Dexterity: {
                            fill: Au,
                            line: xd
                        },
                        Repose: {
                            fill: Hu,
                            line: bd
                        }
                    };
                return (e, o) => (lo(), io("div", {
                    class: R(["size-full overflow-hidden overflow-y-auto space-y-4", xt(gs).grayscale ? "scrollbar-custom-grayscale" : "scrollbar-custom"])
                }, [po("div", yh, [po("button", {
                    class: "size-8 text-white/50 hover:text-white transition-colors",
                    onClick: o[0] || (o[0] = e => xt(t).menu.option = "")
                }, [mo(mh, {
                    class: "size-7"
                })]), o[1] || (o[1] = po("div", null, [po("h2", {
                    class: "text-2xl font-bold"
                }, "Tipo de Ícones"), po("p", {
                    class: "text-white/50"
                }, "Selecione o estilo dos ícones")], -1))]), (lo(), io(Xl, null, Rn(n, (e, n) => po("div", {
                    class: R(["mt-2 rounded-md py-4 px-8 border transition-colors flex items-center justify-between gap-4", xt(t).modes.icon == e ? "border-main bg-main/10" : "border-white/15 hover:bg-white/5 hover:border-white/30 cursor-pointer"]),
                    onClick: n => {
                        return l = e, void(t.modes.icon !== l && (localStorage.setItem("hud-icon-mode", l), t.modes.icon = l));
                        var l
                    },
                    key: n
                }, [po("div", null, [po("h3", kh, "Estilo " + W(n + 1), 1), o[2] || (o[2] = po("p", {
                    class: "text-white/50"
                }, "Clique para selecionar esse estilo", -1))]), po("div", _h, [(lo(), ao(Hn(l.Health[e]), {
                    class: "size-7"
                })), (lo(), ao(Hn(l.Armor[e]), {
                    class: "size-7"
                })), (lo(), ao(Hn(l.Hunger[e]), {
                    class: "size-7"
                })), (lo(), ao(Hn(l.Thirst[e]), {
                    class: "size-7"
                })), (lo(), ao(Hn(l.Stress[e]), {
                    class: "size-7"
                })), (lo(), ao(Hn(l.Luck[e]), {
                    class: "size-7"
                })), (lo(), ao(Hn(l.Dexterity[e]), {
                    class: "size-7"
                })), (lo(), ao(Hn(l.Repose[e]), {
                    class: "size-7"
                }))])], 10, bh)), 64))], 2))
            }
        }),
        Lh = {
            class: "flex items-center gap-4"
        },
        Sh = ["onClick"],
        Vh = {
            class: "text-xl font-bold"
        },
        zh = {
            class: "flex items-center gap-4"
        },
        Zh = vn({
            __name: "Status",
            setup(e) {
                const t = xc(),
                    n = [da, ga, ba, La, Za, Ea, Na, Ka, ec, ac, pc, wc],
                    l = e => n[e],
                    o = {
                        Health: {
                            fill: Lu,
                            line: ad
                        },
                        Armor: {
                            fill: Vu,
                            line: ud
                        },
                        Hunger: {
                            fill: Zu,
                            line: hd
                        },
                        Thirst: {
                            fill: $u,
                            line: pd
                        },
                        Stress: {
                            fill: Eu,
                            line: vd
                        },
                        Luck: {
                            fill: Tu,
                            line: Cd
                        },
                        Dexterity: {
                            fill: Au,
                            line: xd
                        },
                        Repose: {
                            fill: Hu,
                            line: bd
                        }
                    },
                    r = e => o[e][
                        ["fill", "line"].includes(t.modes.icon) ? t.modes.icon : "fill"
                    ];
                return (e, o) => (lo(), io("div", {
                    class: R(["size-full overflow-hidden overflow-y-auto space-y-4", xt(gs).grayscale ? "scrollbar-custom-grayscale" : "scrollbar-custom"])
                }, [po("div", Lh, [po("button", {
                    class: "size-8 text-white/50 hover:text-white transition-colors",
                    onClick: o[0] || (o[0] = e => xt(t).menu.option = "")
                }, [mo(mh, {
                    class: "size-7"
                })]), o[1] || (o[1] = po("div", null, [po("h2", {
                    class: "text-2xl font-bold"
                }, "Status"), po("p", {
                    class: "text-white/50"
                }, "Selecione o estilo do status")], -1))]), (lo(), io(Xl, null, Rn(n, (e, n) => po("div", {
                    class: R(["mt-2 rounded-md py-4 px-8 border transition-colors flex items-center justify-between gap-4", xt(t).modes.status == n + 1 ? "border-main bg-main/10" : "border-white/15 hover:bg-white/5 hover:border-white/30 cursor-pointer"]),
                    onClick: e => {
                        return l = n + 1, void(t.modes.status !== l && (localStorage.setItem("hud-status-mode", l.toString()), t.modes.status = l));
                        var l
                    },
                    key: n
                }, [po("div", null, [po("h3", Vh, "Estilo " + W(n + 1), 1), o[2] || (o[2] = po("p", {
                    class: "text-white/50"
                }, "Clique para selecionar esse estilo", -1))]), po("div", zh, [(lo(), ao(Hn(l(n)), {
                    icon: r("Health"),
                    color: "health",
                    percentage: 50
                }, null, 8, ["icon"])), (lo(), ao(Hn(l(n)), {
                    icon: r("Armor"),
                    color: "armor",
                    percentage: 50
                }, null, 8, ["icon"])), (lo(), ao(Hn(l(n)), {
                    icon: r("Hunger"),
                    color: "hunger",
                    percentage: 50
                }, null, 8, ["icon"])), (lo(), ao(Hn(l(n)), {
                    icon: r("Thirst"),
                    color: "thirst",
                    percentage: 50
                }, null, 8, ["icon"])), (lo(), ao(Hn(l(n)), {
                    icon: r("Stress"),
                    color: "stress",
                    percentage: 50
                }, null, 8, ["icon"])), (lo(), ao(Hn(l(n)), {
                    icon: r("Luck"),
                    color: "luck",
                    percentage: 50
                }, null, 8, ["icon"])), (lo(), ao(Hn(l(n)), {
                    icon: r("Dexterity"),
                    color: "dexterity",
                    percentage: 50
                }, null, 8, ["icon"])), (lo(), ao(Hn(l(n)), {
                    icon: r("Repose"),
                    color: "repose",
                    percentage: 50
                }, null, 8, ["icon"]))])], 10, Sh)), 64))], 2))
            }
        }),
        jh = {
            class: "flex items-center gap-4"
        },
        $h = ["onClick"],
        Bh = {
            class: "text-xl font-bold"
        },
        Eh = {
            class: "flex items-center gap-4"
        },
        Ph = vn({
            __name: "Vehicle",
            setup(e) {
                const t = {
                        speed: 55,
                        rpm: .45,
                        fuel: 50,
                        nitro: 1e3,
                        seatbelt: !0,
                        doors: !0,
                        engine: 800
                    },
                    n = xc(),
                    l = [ki, Hi, na];
                return (e, o) => (lo(), io("div", {
                    class: R(["size-full overflow-hidden overflow-y-auto space-y-4", xt(gs).grayscale ? "scrollbar-custom-grayscale" : "scrollbar-custom"])
                }, [po("div", jh, [po("button", {
                    class: "size-8 text-white/50 hover:text-white transition-colors",
                    onClick: o[0] || (o[0] = e => xt(n).menu.option = "")
                }, [mo(mh, {
                    class: "size-7"
                })]), o[1] || (o[1] = po("div", null, [po("h2", {
                    class: "text-2xl font-bold"
                }, "Velocímetro"), po("p", {
                    class: "text-white/50"
                }, "Selecione o estilo do velocímetro")], -1))]), (lo(), io(Xl, null, Rn(l, (e, r) => {
                    return po("div", {
                        class: R(["mt-2 rounded-md py-4 px-8 border transition-colors flex items-center justify-between gap-4", xt(n).modes.vehicle == r + 1 ? "border-main bg-main/10" : "border-white/15 hover:bg-white/5 hover:border-white/30 cursor-pointer"]),
                        onClick: e => {
                            return t = r + 1, void(n.modes.vehicle !== t && (localStorage.setItem("hud-vehicle-mode", t.toString()), n.modes.vehicle = t));
                            var t
                        },
                        key: r
                    }, [po("div", null, [po("h3", Bh, "Estilo " + W(r + 1), 1), o[2] || (o[2] = po("p", {
                        class: "text-white/50"
                    }, "Clique para selecionar esse estilo", -1))]), po("div", Eh, [(lo(), ao(Hn((s = r, l[s])), {
                        vehicle: t
                    }))])], 10, $h);
                    var s
                }), 64))], 2))
            }
        }),
        Th = {
            width: "100%",
            height: "100%",
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg"
        };
    const Fh = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", Th, [...t[0] || (t[0] = [po("path", {
                    d: "M18 6L6 18M6 6L18 18",
                    stroke: "currentColor",
                    "stroke-width": "2",
                    "stroke-linecap": "round",
                    "stroke-linejoin": "round"
                }, null, -1)])])
            }]
        ]),
        Ah = {
            class: "size-full relative z-[9998] flex items-center justify-center"
        },
        Oh = {
            key: 0,
            class: "absolute z-0 top-0 left-0 size-full bg-default opacity-65"
        },
        Hh = {
            key: 0,
            class: "relative z-10 w-[75rem] h-[50rem] bg-default rounded-2xl p-6"
        },
        Ih = {
            class: "absolute top-0 left-0 size-full z-0 pointer-events-none opacity-50 overflow-hidden rounded-2xl"
        },
        Rh = {
            class: "relative z-10 size-full grid grid-cols-2 grid-rows-2 gap-6",
            key: "main"
        },
        Nh = vn({
            __name: "index",
            setup(e) {
                const t = xc();
                return (e, n) => (lo(), io("div", Ah, [mo(Qo, {
                    name: "fade",
                    appear: ""
                }, {
                    default: Xt(() => [xt(t).menu.display ? (lo(), io("div", Oh)) : wo("", !0)]),
                    _: 1
                }), mo(Qo, {
                    name: "zoom",
                    appear: ""
                }, {
                    default: Xt(() => [xt(t).menu.display ? (lo(), io("div", Hh, [po("button", {
                        class: "absolute z-20 -top-3 -right-3 size-6 rounded-md flex items-center justify-center bg-white text-from/65 hover:bg-neutral-300 transition-colors",
                        onClick: n[0] || (n[0] = (...e) => xt(t).closeMenu && xt(t).closeMenu(...e))
                    }, [mo(Fh, {
                        class: "size-5"
                    })]), po("div", Ih, [po("div", {
                        class: R(["absolute -top-[34.5rem] -left-[30rem] w-[60rem] h-[60rem] opacity-40", xt(gs).grayscale ? "bg-shadow-circle-grayscale" : "bg-shadow-circle"])
                    }, null, 2), po("div", {
                        class: R(["absolute -top-[17.5rem] -left-[15.5rem] w-[60rem] h-[60rem] opacity-20", xt(gs).grayscale ? "bg-shadow-circle-grayscale" : "bg-shadow-circle"])
                    }, null, 2), po("div", {
                        class: R(["absolute -bottom-[15rem] -right-[8.25rem] w-[46rem] h-[45rem] opacity-40", xt(gs).grayscale ? "bg-shadow-circle-grayscale" : "bg-shadow-circle"])
                    }, null, 2), po("div", {
                        class: R(["absolute -bottom-[20.5rem] -right-[17.5rem] w-[60rem] h-[60rem] opacity-20", xt(gs).grayscale ? "bg-shadow-circle-grayscale" : "bg-shadow-circle"])
                    }, null, 2)]), mo(Qo, {
                        name: "fade",
                        mode: "out-in",
                        appear: ""
                    }, {
                        default: Xt(() => ["status" === xt(t).menu.option ? (lo(), ao(Zh, {
                            key: "status"
                        })) : "info" === xt(t).menu.option ? (lo(), ao(xh, {
                            key: "info"
                        })) : "icons" === xt(t).menu.option ? (lo(), ao(Mh, {
                            key: "icons"
                        })) : "vehicle" === xt(t).menu.option ? (lo(), ao(Ph, {
                            key: "vehicle"
                        })) : (lo(), io("div", Rh, [mo(Wu), mo(Qu), mo(sd), mo(fh)]))]),
                        _: 1
                    })])) : wo("", !0)]),
                    _: 1
                })]))
            }
        }),
        Dh = rs("progress", () => {
            const e = Ct(!1),
                t = Ct(101),
                n = Ct(5e3),
                l = Ct(0),
                o = Ct(""),
                r = () => {
                    clearInterval(l.value), l.value = null
                };
            return {
                display: e,
                percentage: t,
                timeout: n,
                interval: l,
                transition: o,
                reset: r,
                start: () => {
                    r(), o.value = "none", o.value = `transform ${n.value/100}ms linear`, l.value = setInterval(() => {
                        if (t.value > 100) return e.value = !1, void r();
                        t.value++
                    }, n.value / 100)
                }
            }
        }),
        Uh = ["viewBox"],
        Wh = ["cx", "cy"],
        Gh = ["cx", "cy", "stroke-dasharray", "stroke-dashoffset"],
        qh = {
            class: "absolute top-1/2 left-1/2 -translate-y-1/2 -translate-x-1/2 font-bold text-xs text-hud-progress-letter"
        },
        Kh = vn({
            __name: "Progress",
            setup(e) {
                const t = zs(),
                    n = Dh(),
                    l = 2 * Math.PI * 21;
                return (e, o) => (lo(), io("div", {
                    class: R(["absolute left-1/2 -translate-x-1/2 transition-all duration-300", xt(t).safezone ? "bottom-20" : "bottom-12"])
                }, [(lo(), io("svg", {
                    class: "w-16 h-16",
                    viewBox: "0 0 45 45",
                    style: {
                        transform: "rotate(90deg)"
                    }
                }, [po("circle", {
                    class: "stroke-hud-progress-background/50",
                    r: 21,
                    cx: 22.5,
                    cy: 22.5,
                    fill: "transparent",
                    "stroke-width": 3
                }, null, 8, Wh), po("circle", {
                    class: "stroke-hud-progress-circle",
                    r: 21,
                    cx: 22.5,
                    cy: 22.5,
                    fill: "transparent",
                    "stroke-width": 3,
                    "stroke-dasharray": `${l}px`,
                    "stroke-dashoffset": l * ((100 - xt(n).percentage) / 100) + "px",
                    style: F({
                        transition: xt(n).transition
                    })
                }, null, 12, Gh)], 8, Uh)), po("span", qh, W(xt(n).percentage) + "% ", 1)], 2))
            }
        }),
        Jh = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const Xh = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", Jh, [...t[0] || (t[0] = [po("path", {
                    d: "M11.9999 1.25C14.6088 1.25 17.0399 1.82767 19.0428 2.82422C19.9633 3.28219 20.6143 3.5917 21.1884 4.51855C21.7718 5.46059 21.7499 6.40064 21.7499 7.74805V11.2373C21.7497 17.3739 16.8465 20.7234 14.1698 22.1006L14.1337 22.1191C13.4159 22.4886 12.908 22.75 11.9999 22.75C11.0919 22.75 10.5848 22.4885 9.86707 22.1191L9.82996 22.1006C7.15321 20.7234 2.25001 17.3738 2.24988 11.2373V7.74805C2.24988 6.40066 2.22794 5.46057 2.8114 4.51855C3.38549 3.59169 4.03648 3.28217 4.95691 2.82422C6.95985 1.82766 9.39097 1.25002 11.9999 1.25ZM15.9286 9.12891C15.7234 8.61644 15.1414 8.36647 14.6288 8.57129C13.1417 9.16612 12.0092 10.324 11.2762 11.2568C11.1856 11.3722 11.0989 11.4856 11.0184 11.5957C10.7921 11.3533 10.5562 11.1599 10.329 11.0098C10.0396 10.8186 9.77131 10.6992 9.56824 10.626C9.46648 10.5893 9.3183 10.5411 9.17566 10.5156C8.63229 10.4187 8.11288 10.7809 8.0155 11.3242C7.91845 11.8677 8.28065 12.3861 8.8241 12.4834C8.96002 12.5077 9.09019 12.5887 9.22644 12.6787C9.48798 12.8515 9.83546 13.1804 10.0526 13.8213C10.1822 14.2033 10.5291 14.4704 10.9315 14.498C11.3341 14.5256 11.7139 14.3072 11.8944 13.9463C11.9341 13.8737 12.0474 13.6676 12.1288 13.5332C12.2923 13.2631 12.5353 12.8918 12.8485 12.4932C13.4905 11.6762 14.3585 10.8338 15.371 10.4287C15.8836 10.2236 16.1335 9.6416 15.9286 9.12891Z",
                    fill: "currentColor"
                }, null, -1)])])
            }]
        ]),
        Qh = {
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 24 24",
            width: "24",
            height: "24",
            fill: "none"
        };
    const Yh = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", Qh, [...t[0] || (t[0] = [po("path", {
                    d: "M18.7088 3.49534C16.8165 2.55382 14.5009 2 12 2C9.4991 2 7.1835 2.55382 5.29116 3.49534C4.36318 3.95706 3.89919 4.18792 3.4496 4.91378C3 5.63965 3 6.34248 3 7.74814V11.2371C3 16.9205 7.54236 20.0804 10.173 21.4338C10.9067 21.8113 11.2735 22 12 22C12.7265 22 13.0933 21.8113 13.8269 21.4338C16.4576 20.0804 21 16.9205 21 11.2371L21 7.74814C21 6.34249 21 5.63966 20.5504 4.91378C20.1008 4.18791 19.6368 3.95706 18.7088 3.49534Z",
                    stroke: "currentColor",
                    "stroke-width": "2",
                    "stroke-linecap": "round",
                    "stroke-linejoin": "round"
                }, null, -1), po("path", {
                    d: "M9 11.5C9 11.5 10.4079 11.7519 11 13.5C11 13.5 12.5 10.5 15 9.5",
                    stroke: "currentColor",
                    "stroke-width": "2",
                    "stroke-linecap": "round",
                    "stroke-linejoin": "round"
                }, null, -1)])])
            }]
        ]),
        ef = {
            class: "absolute bottom-10 left-1/2 -translate-x-1/2 flex gap-2 text-white/50 drop-shadow-light"
        },
        tf = vn({
            __name: "Safezone",
            setup(e) {
                const t = xc();
                return (e, n) => (lo(), io("div", ef, [(lo(), ao(Hn("fill" == xt(t).modes.icon ? Xh : Yh), {
                    class: "w-6 h-6 min-w-6"
                })), n[0] || (n[0] = po("p", null, "Safezone", -1))]))
            }
        }),
        nf = {
            viewBox: "0 0 24 24",
            xmlns: "http://www.w3.org/2000/svg",
            class: "scale-125"
        };
    const lf = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", nf, [...t[0] || (t[0] = [po("path", {
                    fill: "currentColor",
                    d: "M15.8 7.4c-0.6-1.1-1.4-2-2.5-2.7c-1.1-0.6-2.3-1-3.6-1S7.1 4 6.1 4.7C5 5.3 4.2 6.2 3.6 7.4C3 8.5 2.7 9.8 2.7 11.2S3 13.9 3.6 15s1.4 2 2.5 2.7c1.1 0.6 2.3 1 3.6 1s2.6-0.3 3.6-1c1.1-0.6 1.9-1.6 2.5-2.7l0 0c0.6-1.1 0.9-2.4 0.9-3.8C16.7 9.8 16.4 8.5 15.8 7.4z M14.7 11.2c0 1.1-0.2 2.1-0.6 2.9c-0.4 0.8-1 1.5-1.8 2c-0.7 0.5-1.6 0.7-2.6 0.7s-1.8-0.2-2.6-0.7c-0.7-0.5-1.3-1.1-1.8-2c-0.4-0.8-0.6-1.8-0.6-2.9s0.2-2.1 0.6-2.9c0.4-0.8 1-1.5 1.8-2c0.7-0.5 1.6-0.7 2.6-0.7s1.8 0.2 2.6 0.7s1.3 1.1 1.8 2C14.5 9.2 14.7 10.1 14.7 11.2z"
                }, null, -1), po("path", {
                    fill: "currentColor",
                    d: "M21.1 18.8c-0.2-0.2-0.4-0.2-0.6-0.2h-0.9l0.5-0.5c0.3-0.4 0.6-0.7 0.8-1.1c0.2-0.4 0.3-0.8 0.3-1.2c0-0.4-0.1-0.8-0.3-1.1c-0.2-0.3-0.5-0.6-0.8-0.8c-0.6-0.3-1.4-0.4-2.2-0.1c-0.3 0.2-0.6 0.4-0.9 0.6c-0.1 0.1-0.2 0.3-0.3 0.4c-0.1 0.2-0.1 0.3-0.1 0.5s0 0.4 0.3 0.6c0.4 0.4 1 0.3 1.3-0.1c0.1-0.1 0.2-0.3 0.4-0.4c0.3-0.2 0.5-0.1 0.7 0.1c0.1 0.1 0.2 0.2 0.2 0.4c0 0.1 0 0.3-0.1 0.5S19.1 16.8 19 17l-1.9 2c-0.2 0.2-0.3 0.4-0.3 0.6s0.1 0.4 0.2 0.6c0.1 0.1 0.3 0.3 0.6 0.3h2.9c0.2 0 0.4-0.1 0.6-0.2c0.2-0.2 0.2-0.4 0.2-0.6C21.3 19.2 21.3 19 21.1 18.8z"
                }, null, -1)])])
            }]
        ]),
        of = {
            viewBox: "0 0 24 24",
            xmlns: "http://www.w3.org/2000/svg",
            class: "scale-125"
        };
    const rf = Zs({}, [
            ["render", function(e, t) {
                return lo(), io("svg", of, [...t[0] || (t[0] = [po("path", {
                    fill: "currentColor",
                    d: "M15.8 7.4c-0.6-1.1-1.4-2-2.5-2.7c-1.1-0.6-2.3-1-3.6-1S7.1 4 6.1 4.7C5 5.3 4.2 6.2 3.6 7.4C3 8.5 2.7 9.8 2.7 11.2S3 13.9 3.6 15s1.4 2 2.5 2.7c1.1 0.6 2.3 1 3.6 1s2.6-0.3 3.6-1c1.1-0.6 1.9-1.6 2.5-2.7l0 0c0.6-1.1 0.9-2.4 0.9-3.8C16.7 9.8 16.4 8.5 15.8 7.4z M14.7 11.2c0 1.1-0.2 2.1-0.6 2.9c-0.4 0.8-1 1.5-1.8 2c-0.7 0.5-1.6 0.7-2.6 0.7s-1.8-0.2-2.6-0.7c-0.7-0.5-1.3-1.1-1.8-2c-0.4-0.8-0.6-1.8-0.6-2.9s0.2-2.1 0.6-2.9c0.4-0.8 1-1.5 1.8-2c0.7-0.5 1.6-0.7 2.6-0.7s1.8 0.2 2.6 0.7s1.3 1.1 1.8 2C14.5 9.2 14.7 10.1 14.7 11.2z"
                }, null, -1), po("path", {
                    fill: "currentColor",
                    d: "M21.1 18.8c-0.2-0.2-0.4-0.2-0.6-0.2h-0.9l0.5-0.5c0.3-0.4 0.6-0.7 0.8-1.1c0.2-0.4 0.3-0.8 0.3-1.2c0-0.4-0.1-0.8-0.3-1.1c-0.2-0.3-0.5-0.6-0.8-0.8c-0.6-0.3-1.4-0.4-2.2-0.1c-0.3 0.2-0.6 0.4-0.9 0.6c-0.1 0.1-0.2 0.3-0.3 0.4c-0.1 0.2-0.1 0.3-0.1 0.5s0 0.4 0.3 0.6c0.4 0.4 1 0.3 1.3-0.1c0.1-0.1 0.2-0.3 0.4-0.4c0.3-0.2 0.5-0.1 0.7 0.1c0.1 0.1 0.2 0.2 0.2 0.4c0 0.1 0 0.3-0.1 0.5S19.1 16.8 19 17l-1.9 2c-0.2 0.2-0.3 0.4-0.3 0.6s0.1 0.4 0.2 0.6c0.1 0.1 0.3 0.3 0.6 0.3h2.9c0.2 0 0.4-0.1 0.6-0.2c0.2-0.2 0.2-0.4 0.2-0.6C21.3 19.2 21.3 19 21.1 18.8z"
                }, null, -1)])])
            }]
        ]),
        sf = {
            class: "flex items-center gap-3"
        },
        af = vn({
            __name: "Statusbar",
            setup(e) {
                const t = zs(),
                    n = xc(),
                    l = {
                        Health: {
                            fill: Lu,
                            line: ad
                        },
                        Armor: {
                            fill: Vu,
                            line: ud
                        },
                        Hunger: {
                            fill: Zu,
                            line: hd
                        },
                        Thirst: {
                            fill: $u,
                            line: pd
                        },
                        Oxygen: {
                            fill: lf,
                            line: rf
                        },
                        Stress: {
                            fill: Eu,
                            line: vd
                        },
                        Luck: {
                            fill: Tu,
                            line: Cd
                        },
                        Dexterity: {
                            fill: Au,
                            line: xd
                        },
                        Repose: {
                            fill: Hu,
                            line: bd
                        }
                    },
                    o = e => l[e][
                        ["fill", "line"].includes(n.modes.icon) ? n.modes.icon : "fill"
                    ];
                return (e, l) => (lo(), io("div", sf, [(lo(), ao(Hn(xt(n).status), {
                    icon: o("Health"),
                    color: "health",
                    percentage: xt(t).health
                }, null, 8, ["icon", "percentage"])), xt(t).armor > 0 ? (lo(), ao(Hn(xt(n).status), {
                    key: 0,
                    icon: o("Armor"),
                    color: "armor",
                    percentage: xt(t).armor
                }, null, 8, ["icon", "percentage"])) : wo("", !0), (lo(), ao(Hn(xt(n).status), {
                    icon: o("Hunger"),
                    color: "hunger",
                    percentage: xt(t).hunger
                }, null, 8, ["icon", "percentage"])), (lo(), ao(Hn(xt(n).status), {
                    icon: o("Thirst"),
                    color: "thirst",
                    percentage: xt(t).thirst
                }, null, 8, ["icon", "percentage"])), xt(t).oxygen.display ? (lo(), ao(Hn(xt(n).status), {
                    key: 1,
                    icon: o("Oxygen"),
                    color: "oxygen",
                    percentage: xt(t).oxygen.value
                }, null, 8, ["icon", "percentage"])) : wo("", !0), xt(t).stress > 0 ? (lo(), ao(Hn(xt(n).status), {
                    key: 2,
                    icon: o("Stress"),
                    color: "stress",
                    percentage: xt(t).stress
                }, null, 8, ["icon", "percentage"])) : wo("", !0), xt(t).luckPercentage > 0 ? (lo(), ao(Hn(xt(n).status), {
                    key: 3,
                    icon: o("Luck"),
                    color: "luck",
                    percentage: xt(t).luckPercentage
                }, null, 8, ["icon", "percentage"])) : wo("", !0), xt(t).dexterityPercentage > 0 ? (lo(), ao(Hn(xt(n).status), {
                    key: 4,
                    icon: o("Dexterity"),
                    color: "dexterity",
                    percentage: xt(t).dexterityPercentage
                }, null, 8, ["icon", "percentage"])) : wo("", !0), xt(t).reposePercentage > 0 ? (lo(), ao(Hn(xt(n).status), {
                    key: 5,
                    icon: o("Repose"),
                    color: "repose",
                    percentage: xt(t).reposePercentage
                }, null, 8, ["icon", "percentage"])) : wo("", !0)]))
            }
        }),
        cf = rs("vehicle", () => ({
            display: Ct(!1),
            speed: Ct(0),
            rpm: Ct(0),
            fuel: Ct(0),
            nitro: Ct(0),
            engine: Ct(1e3),
            doors: Ct(!1),
            seatbelt: Ct(!1)
        })),
        uf = {
            class: "space-y-1.5"
        },
        df = {
            class: "flex-1 relative z-10 text-sm font-medium truncate"
        },
        hf = {
            class: "relative z-10 text-sm font-medium"
        },
        ff = vn({
            __name: "Domination",
            setup(e) {
                const t = xc(),
                    n = e => gs.value.groups[e]?.Name ?? e,
                    l = e => {
                        const t = is(function(e) {
                            let t = 0;
                            for (let l = 0; l < e.length; l++) t = e.charCodeAt(l) + ((t << 5) - t);
                            let n = "#";
                            for (let l = 0; l < 3; l++) n += (t >> 8 * l & 255).toString(16).padStart(2, "0");
                            return n
                        }(e));
                        return t ? [t.r, t.g, t.b] : [255, 255, 255]
                    },
                    o = e => {
                        const t = l(e),
                            n = ds(...t) < 125 ? function(e, t, n, l) {
                                const o = l / 100,
                                    r = e => Math.max(0, Math.min(255, Math.floor(e + (255 - e) * o)));
                                return {
                                    r: r(e),
                                    g: r(t),
                                    b: r(n)
                                }
                            }(...t, 20) : us(...t, 20);
                        return [n.r, n.g, n.b]
                    },
                    r = e => t.domination.max <= 0 ? 0 : Math.min(100, Math.max(0, e / t.domination.max * 100));
                return (e, s) => (lo(), io("div", uf, [(lo(!0), io(Xl, null, Rn(xt(t).domination.list, (e, t) => (lo(), io("div", {
                    class: "bg-main w-52 rounded overflow-hidden",
                    key: t,
                    style: F({
                        "--main": l(t).join(" ")
                    })
                }, [po("div", {
                    class: "relative flex items-center justify-between gap-4 h-full py-2 px-3",
                    style: F({
                        color: xt(ds)(...l(t)) > 128 ? "#000" : "#fff"
                    })
                }, [po("div", {
                    class: "absolute top-0 left-0 h-full z-0",
                    style: F({
                        width: r(e) + "%",
                        backgroundColor: `rgb(${o(t)})`
                    })
                }, null, 4), po("span", df, W(n(t)), 1), po("span", hf, W(e) + " Pts", 1)], 4)], 4))), 128))]))
            }
        }),
        pf = {
            class: "absolute z-[9999] top-0 left-0 size-full flex flex-col items-center justify-center bg-from"
        },
        mf = {
            class: "absolute z-0 top-0 left-0 size-full bg-default pointer-events-none opacity-50"
        },
        vf = vn({
            __name: "VoiceState",
            setup: e => (e, t) => (lo(), io("div", pf, [po("div", mf, [po("div", {
                class: R(["absolute -top-[34.5rem] -left-[30rem] w-[60rem] h-[60rem] opacity-40", xt(gs).grayscale ? "bg-shadow-circle-grayscale" : "bg-shadow-circle"])
            }, null, 2), po("div", {
                class: R(["absolute -top-[17.5rem] -left-[15.5rem] w-[60rem] h-[60rem] opacity-20", xt(gs).grayscale ? "bg-shadow-circle-grayscale" : "bg-shadow-circle"])
            }, null, 2), po("div", {
                class: R(["absolute -bottom-[15rem] -right-[8.25rem] w-[46rem] h-[45rem] opacity-40", xt(gs).grayscale ? "bg-shadow-circle-grayscale" : "bg-shadow-circle"])
            }, null, 2), po("div", {
                class: R(["absolute -bottom-[20.5rem] -right-[17.5rem] w-[60rem] h-[60rem] opacity-20", xt(gs).grayscale ? "bg-shadow-circle-grayscale" : "bg-shadow-circle"])
            }, null, 2)]), t[0] || (t[0] = po("div", {
                class: "relative text-white text-xl font-bold w-96 text-center"
            }, "Você precisa estar conectado em uma sala do discord.", -1))]))
        }),
        gf = new Map,
        Cf = new Map;
    let wf = 0,
        xf = 0;

    function yf(e) {
        const t = gf.get(e.key.toLowerCase());
        t && t.forEach(t => t(e))
    }

    function bf(e) {
        const t = Cf.get(e.key.toLowerCase());
        t && t.forEach(t => t(e))
    }
    const kf = {
            class: "size-full flex items-center justify-center"
        },
        _f = {
            key: 0,
            tag: "div",
            class: "absolute bottom-10 right-10 flex flex-col items-end gap-8"
        },
        Mf = ((...e) => {
            const t = (Or || (Or = zl(Ar))).createApp(...e),
                {
                    mount: n
                } = t;
            return t.mount = e => {
                const l = function(e) {
                    if (m(e)) {
                        return document.querySelector(e)
                    }
                    return e
                }(e);
                if (!l) return;
                const o = t._component;
                p(o) || o.render || o.template || (o.template = l.innerHTML), 1 === l.nodeType && (l.textContent = "");
                const r = n(l, !1, function(e) {
                    if (e instanceof SVGElement) return "svg";
                    if ("function" == typeof MathMLElement && e instanceof MathMLElement) return "mathml"
                }(l));
                return l instanceof Element && (l.removeAttribute("v-cloak"), l.setAttribute("data-v-app", "")), r
            }, t
        })(vn({
            __name: "App",
            setup(e) {
                const t = zs(),
                    n = cf(),
                    l = Dh(),
                    o = xc();
                return ms("Body", e => "boolean" == typeof e ? o.display = e : null), ms("VoiceState", e => "boolean" == typeof e ? o.voiceState = e : null), ms("Health", e => "number" == typeof e ? t.health = e : null), ms("Armour", e => "number" == typeof e ? t.armor = e : null), ms("Hunger", e => "number" == typeof e ? t.hunger = e : null), ms("Thirst", e => "number" == typeof e ? t.thirst = e : null), ms("Oxygen", e => {
                        "number" == typeof e ? (t.oxygen.value = e, t.oxygen.display = !0) : t.oxygen.display = !1
                    }), ms("Stress", e => "number" == typeof e ? t.stress = e : null), ms("Luck", e => "number" == typeof e ? t.luck = e : null), ms("Dexterity", e => "number" == typeof e ? t.dexterity = e : null), ms("Repose", e => "object" == typeof e && 2 == e.length ? t.repose = e : null), ms("Road", e => "string" == typeof e ? t.location.top = e : null), ms("Crossing", e => "string" == typeof e ? t.location.bottom = e : null), ms("Clock", e => "object" == typeof e && 2 == e.length ? t.clock = e : null), ms("Wanted", e => "object" == typeof e && 2 == e.length ? t.wanted = e : null), ms("Passport", e => "number" == typeof e ? t.id = e : null), ms("Safezone", e => "boolean" == typeof e ? t.safezone = e : null), ms("Players", e => "number" == typeof e ? t.players = e : null), ms("Voip", e => "string" == typeof e ? t.voice.distance = e : null), ms("Voice", e => "boolean" == typeof e ? t.voice.isTalking = e : null), ms("Progress", e => {
                        "number" == typeof e && (l.percentage = 0, l.timeout = e, l.display = !0, l.reset(), l.start())
                    }), ms("Gemstone", e => "number" == typeof e ? t.gemstone = e : null), ms("Frequency", e => "string" == typeof e || "number" == typeof e ? t.radio = e : null), ms("Gemstone", e => "number" == typeof e ? t.gemstone = e : null), ms("Frequency", e => t.radio = "string" == typeof e || "number" == typeof e ? e : null), ms("Radio", e => {
                        if (!e || "object" != typeof e || !e.Source) return;
                        const n = t.radioList.findIndex(t => t.Source === e.Source);
                        e.Name ? -1 === n && t.radioList.push({
                            Source: e.Source,
                            Name: e.Name
                        }) : -1 !== n && t.radioList.splice(n, 1)
                    }), ms("Vehicle", e => "boolean" == typeof e ? n.display = e : null), ms("EngineHealth", e => "number" == typeof e ? n.engine = e : null), ms("Locked", e => "number" == typeof e ? n.doors = 2 === e : null), ms("Nitro", e => "number" == typeof e ? n.nitro = e : null), ms("Fuel", e => "number" == typeof e ? n.fuel = e : null), ms("Speed", e => "number" == typeof e ? n.speed = e : null), ms("Rpm", e => "number" == typeof e ? n.rpm = e : null), ms("Seatbelt", e => "boolean" == typeof e ? n.seatbelt = e : null), ms("Map", e => "boolean" == typeof e ? o.map = e : null), ms("Weapons", e => {
                        if (!e || "object" != typeof e || !e.Name || void 0 === e.Current || void 0 === e.Stored) return void(t.weapon.display = !1);
                        const {
                            Name: n,
                            Current: l,
                            Stored: o
                        } = e;
                        t.weapon.display = !0, t.weapon.name = n, t.weapon.ammo.current = l, t.weapon.ammo.stored = o
                    }), ms("Video", e => {
                        e && "string" == typeof e ? (o.video.code = e, o.video.display = !0) : o.video.display = !1
                    }), ms("Domination", e => {
                        if (!e || "object" != typeof e || !e.Max || !e.Data) return o.domination.display = !1, void(o.domination.list = {});
                        const {
                            Max: t,
                            Data: n
                        } = e;
                        o.domination.max = t, o.domination.list = n, o.domination.display || (o.domination.display = !0)
                    }), ms("Menu", e => {
                        "boolean" == typeof e && e ? (o.menu.option = "", o.menu.display = !0) : o.closeMenu()
                    }), ms("Killfeed", e => {
                        const {
                            Killer: t,
                            Victim: n
                        } = e;
                        (e => {
                            const {
                                killer: t,
                                victim: n
                            } = e, l = {
                                killer: t,
                                victim: n,
                                timeout: 5050,
                                id: Rc.id++
                            };
                            Rc.toasts.unshift(l), setTimeout(() => {
                                const e = Rc.toasts.indexOf(l);
                                e > -1 && Rc.toasts.splice(e, 1)
                            }, l.timeout)
                        })({
                            killer: t,
                            victim: n
                        })
                    }),
                    function(e, t, n = !1) {
                        const l = n ? Cf : gf,
                            o = n ? "keyup" : "keydown",
                            r = n ? bf : yf;
                        let s = !1;
                        Zn(() => {
                            l.has(e.toLowerCase()) || l.set(e.toLowerCase(), []), l.get(e.toLowerCase()).push(t), s = !0, n ? (xf++, 1 === xf && window.addEventListener(o, r)) : (wf++, 1 === wf && window.addEventListener(o, r))
                        }), Bn(() => {
                            if (!s) return;
                            const i = l.get(e.toLowerCase());
                            if (!i) return;
                            const a = i.indexOf(t); - 1 !== a && i.splice(a, 1), 0 === i.length && l.delete(e.toLowerCase()), n ? (xf--, xf <= 0 && (window.removeEventListener(o, r), xf = 0)) : (wf--, wf <= 0 && (window.removeEventListener(o, r), wf = 0)), s = !1
                        })
                    }("Escape", () => {
                        o.menu.display && o.closeMenu()
                    }), Zn(() => {
                        !async function(e) {
                            let t = await vs("Theme", {}, "vrp");
                            t || (t = {
                                main: "#5865f2",
                                mainText: "#ffffff",
                                ...Object.fromEntries(Object.entries(e).map(([e, t]) => [e, t.default]))
                            });
                            const n = as(31, 6, 3),
                                l = as(18, 4, 2),
                                o = "function" == typeof GetParentResourceName ? GetParentResourceName() : "nui-fallback",
                                r = (e, t) => t.reduce((e, t) => e && void 0 !== e[t] ? e[t] : void 0, e);
                            for (const s in e) {
                                const i = e[s];
                                if (!i) continue;
                                const a = s.split("-");
                                let c = r(t, a);
                                if (i.rgb && a[0] && t.scripts?.[o]?.[a[0]]) {
                                    const e = r(t.scripts[o], a);
                                    "string" == typeof e && (c = e)
                                }
                                if (null != c && "" !== c || (c = i.default), i.variable && (gs.value[i.variable] = c), "string" == typeof c) {
                                    const e = is(c);
                                    if (!e) continue;
                                    const t = as(e.r, e.g, e.b);
                                    if (i.rgb && document.documentElement.style.setProperty(`--${s}`, `${e.r} ${e.g} ${e.b}`), i.fromTo) {
                                        const e = cs(t.h, 0 === t.s ? t.s : l.s, l.l),
                                            o = cs(t.h, 0 === t.s ? t.s : n.s, n.l);
                                        document.documentElement.style.setProperty("--from", `${e.r} ${e.g} ${e.b}`), document.documentElement.style.setProperty("--to", `${o.r} ${o.g} ${o.b}`)
                                    }
                                    if (i.grayscaleCheck && 0 === t.s && (gs.value.grayscale = !0), i.hover) {
                                        const t = us(e.r, e.g, e.b, 20);
                                        t && document.documentElement.style.setProperty(`--${s}Hover`, `${t.r} ${t.g} ${t.b}`)
                                    }
                                }
                            }
                        }({
                            main: {
                                rgb: !0,
                                fromTo: !0,
                                grayscaleCheck: !0,
                                default: "#5865f2"
                            },
                            mainText: {
                                rgb: !0,
                                default: "#ffffff"
                            },
                            groups: {
                                variable: "groups",
                                default: {}
                            },
                            "hud-modes": {
                                variable: "modes",
                                default: {
                                    info: 3,
                                    icon: "fill",
                                    status: 10,
                                    vehicle: 3
                                }
                            },
                            "hud-percentage": {
                                variable: "percentage",
                                default: !0
                            },
                            "hud-icons": {
                                variable: "iconColor",
                                default: "#ffffff"
                            },
                            "hud-logo": {
                                variable: "logo",
                                default: 80
                            },
                            "hud-nitro": {
                                rgb: !0,
                                default: "#f69d2a"
                            },
                            "hud-rpm": {
                                rgb: !0,
                                default: "#FFFFFF"
                            },
                            "hud-fuel": {
                                rgb: !0,
                                default: "#f94c54"
                            },
                            "hud-engine": {
                                rgb: !0,
                                default: "#ff4c55"
                            },
                            "hud-health": {
                                rgb: !0,
                                default: "#76B984"
                            },
                            "hud-armor": {
                                rgb: !0,
                                default: "#A66FED"
                            },
                            "hud-hunger": {
                                rgb: !0,
                                default: "#F4B266"
                            },
                            "hud-thirst": {
                                rgb: !0,
                                default: "#7FC8F8"
                            },
                            "hud-oxygen": {
                                rgb: !0,
                                default: "#38F8F8"
                            },
                            "hud-stress": {
                                rgb: !0,
                                default: "#E287C9"
                            },
                            "hud-luck": {
                                rgb: !0,
                                default: "#F18A7C"
                            },
                            "hud-dexterity": {
                                rgb: !0,
                                default: "#E4E76E"
                            },
                            "hud-repose": {
                                rgb: !0,
                                default: "#7FCCC7"
                            },
                            "hud-pointer": {
                                rgb: !0,
                                default: "#ef4444"
                            },
                            "hud-progress-background": {
                                rgb: !0,
                                default: "#FFFFFF"
                            },
                            "hud-progress-circle": {
                                rgb: !0,
                                default: "#5865f2"
                            },
                            "hud-progress-letter": {
                                rgb: !0,
                                default: "#FFFFFF"
                            }
                        });
                        const e = localStorage.getItem("hud-info-mode"),
                            t = localStorage.getItem("hud-icon-mode"),
                            n = localStorage.getItem("hud-status-mode"),
                            l = localStorage.getItem("hud-vehicle-mode");
                        e && (o.modes.info = ["1", "2", "3"].includes(e) ? parseInt(e) : 1), t && (o.modes.icon = ["fill", "line"].includes(t) ? t : "fill"), n && (o.modes.status = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"].includes(n) ? parseInt(n) : 1), l && (o.modes.vehicle = ["1", "2", "3"].includes(l) ? parseInt(l) : 1)
                    }), (e, r) => (lo(), io("div", kf, [mo(Qo, {
                        name: "fade"
                    }, {
                        default: Xt(() => [xt(o).voiceState ? (lo(), ao(vf, {
                            key: 0
                        })) : wo("", !0)]),
                        _: 1
                    }), mo(bc), mo(Qo, {
                        name: "fade-right",
                        appear: ""
                    }, {
                        default: Xt(() => [xt(o).display ? (lo(), io("div", _f, [mo(Qo, {
                            name: "fade-right",
                            mode: "out-in",
                            appear: ""
                        }, {
                            default: Xt(() => [xt(n).display ? (lo(), ao(Hn(xt(o).vehicle), {
                                key: 0,
                                vehicle: xt(n)
                            }, null, 8, ["vehicle"])) : wo("", !0)]),
                            _: 1
                        }), mo(af)])) : wo("", !0)]),
                        _: 1
                    }), mo(Nh), mo(Qo, {
                        name: "fade-right",
                        appear: ""
                    }, {
                        default: Xt(() => [xt(o).display ? (lo(), ao(_u, {
                            key: 0
                        })) : wo("", !0)]),
                        _: 1
                    }), mo(Qo, {
                        name: "fade-left",
                        appear: ""
                    }, {
                        default: Xt(() => [xt(o).display ? (lo(), io("div", {
                            key: 0,
                            class: "absolute flex flex-col items-start gap-4 transition-all",
                            style: F({
                                left: "55px",
                                bottom: (xt(n).display || xt(o).map ? 285 : 55) + "px"
                            })
                        }, [mo(Qo, {
                            name: "fade-left",
                            appear: ""
                        }, {
                            default: Xt(() => [xt(t).radioList.length > 0 ? (lo(), ao(Lc, {
                                key: 0
                            })) : wo("", !0)]),
                            _: 1
                        }), mo(Qo, {
                            name: "fade-left",
                            appear: ""
                        }, {
                            default: Xt(() => [xt(o).domination.display ? (lo(), ao(ff, {
                                key: 0
                            })) : wo("", !0)]),
                            _: 1
                        }), (lo(), ao(Hn(xt(o).location), {
                            class: "drop-shadow-light"
                        }))], 4)) : wo("", !0)]),
                        _: 1
                    }), mo(Qo, {
                        name: "fade-bottom",
                        appear: ""
                    }, {
                        default: Xt(() => [xt(o).display && xt(l).display && xt(l).percentage <= 100 ? (lo(), ao(Kh, {
                            key: 0
                        })) : wo("", !0)]),
                        _: 1
                    }), mo(Qo, {
                        name: "fade-bottom",
                        appear: ""
                    }, {
                        default: Xt(() => [xt(o).display && xt(t).safezone ? (lo(), ao(tf, {
                            key: 0
                        })) : wo("", !0)]),
                        _: 1
                    }), mo(zc)]))
            }
        })),
        Lf = function() {
            const e = Q(!0),
                t = e.run(() => Ct({}));
            let n = [],
                l = [];
            const o = pt({
                install(e) {
                    Ir(o), o._a = e, e.provide(Rr, o), e.config.globalProperties.$pinia = o, l.forEach(e => n.push(e)), l = []
                },
                use(e) {
                    return this._a ? n.push(e) : l.push(e), this
                },
                _p: n,
                _a: null,
                _e: e,
                _s: new Map,
                state: t
            });
            return o
        }();
    Mf.use(Lf).mount("#app")
}();